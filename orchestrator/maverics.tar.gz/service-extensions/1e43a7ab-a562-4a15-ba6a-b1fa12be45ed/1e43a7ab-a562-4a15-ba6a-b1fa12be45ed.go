package main

import (
	"fmt"
	"net/http"
	"strings"

	"github.com/strata-io/service-extension/orchestrator"
)

const (
	// IDP identifiers
	entraID = "Mavs5"
	oktaID  = "Okta-mavs5-fastpass"

	// Domain constants
	telusDomain       = "@strata.io"
	telusHealthDomain = "@strata-eval.io"
)

// extractDomain extracts the domain part from an email address
func extractDomain(email string) string {
	parts := strings.Split(email, "@")
	if len(parts) != 2 {
		return ""
	}
	return "@" + parts[1]
}

// IsAuthenticated determines if the user is authenticated
func IsAuthenticated(
	api orchestrator.Orchestrator,
	_ http.ResponseWriter,
	_ *http.Request,
) bool {
	return checkIsAuthenticated(api)
}

func checkIsAuthenticated(api orchestrator.Orchestrator) bool {
	logger := api.Logger()
	sess, _ := api.Session()
	logger.Debug("msg", "determining if user is authenticated")

	oldcoAuthenticated, _ := sess.GetString(fmt.Sprintf("%s.authenticated", entraID))
	if oldcoAuthenticated == "true" {
		logger.Debug("msg", "user is authenticated by entraID")
		mapClaim(api, entraID+".sub", "generic.SM_USER")
		mapClaim(api, entraID+".given_name", "generic.firstname")
		mapClaim(api, entraID+".family_name", "generic.lastname")
		mapClaim(api, entraID+".email", "generic.email")
		return true
	}

	newcoAuthenticated, _ := sess.GetString(fmt.Sprintf("%s.authenticated", oktaID))
	if newcoAuthenticated == "true" {
		logger.Debug("msg", "user is authenticated by Okta")
		mapClaim(api, oktaID+".email", "generic.SM_USER")
		mapClaim(api, oktaID+".name", "generic.firstname")
		mapClaim(api, oktaID+".name", "generic.lastname")
		mapClaim(api, oktaID+".email", "generic.email")
		return true
	}

	return false
}

func mapClaim(api orchestrator.Orchestrator, oldClaim, newClaim string) {
	logger := api.Logger()
	sess, _ := api.Session()
	claimValue, _ := sess.GetString(oldClaim)
	if claimValue == "" {
		logger.Info(fmt.Sprintf("cannot map claim for %s", oldClaim))
		return
	}
	logger.Info(fmt.Sprintf("mapping new claim %s:%s", newClaim, claimValue))
	_ = sess.SetString(newClaim, claimValue)
	sess.Save()
}

// Authenticate authenticates the user against the appropriate IDP based on their email domain
func Authenticate(
	api orchestrator.Orchestrator,
	rw http.ResponseWriter,
	req *http.Request,
) {
	logger := api.Logger()
	logger.Info("msg", "authenticating user")

	hasIDPBeenPicked := req.FormValue("email")
	if !checkIsAuthenticated(api) && len(hasIDPBeenPicked) == 0 {
		logger.Debug("msg", "rendering idp picker")
		_, _ = rw.Write([]byte(fmt.Sprintf(idpForm, req.FormValue("SAMLRequest"))))
		return
	}

	if req.Method != http.MethodPost {
		http.Error(
			rw,
			http.StatusText(http.StatusInternalServerError),
			http.StatusInternalServerError,
		)
		logger.Error(fmt.Sprintf(
			"received unexpected request type '%s', expected POST",
			req.Method,
		))
		return
	}

	logger.Info("msg", "parsing form from request")
	err := req.ParseForm()
	if err != nil {
		http.Error(
			rw,
			http.StatusText(http.StatusInternalServerError),
			http.StatusInternalServerError,
		)
		logger.Error(fmt.Sprintf(
			"failed to parse form from request: %s",
			err,
		))
		return
	}

	email := req.Form.Get("email")
	domain := extractDomain(email)

	var idp string
	switch domain {
	case telusHealthDomain:
		idp = entraID
	case telusDomain:
		idp = oktaID
	default:
		http.Error(
			rw,
			"Invalid email domain",
			http.StatusBadRequest,
		)
		logger.Error(fmt.Sprintf("invalid email domain: %s", domain))
		return
	}

	logger.Info(
		"msg", fmt.Sprintf("authenticating user with email '%s'", email),
		"domain", domain,
		"idp", idp,
	)

	provider, err := api.IdentityProvider(idp)
	if err != nil {
		http.Error(
			rw,
			http.StatusText(http.StatusInternalServerError),
			http.StatusInternalServerError,
		)
		logger.Error(fmt.Sprintf("selected IDP '%s' was not found on AuthProvider", idp))
		return
	}

	logger.Info(fmt.Sprintf("Selected IDP '%s' was FOUND", idp))
	provider.Login(rw, req)
}

// idpForm is the HTML form for email input
const idpForm = `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TELUS Identity Hub</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen flex flex-col gap-y-6 items-center justify-center">
    <div class="w-full max-w-md">
        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/6/63/Telus-Logo.svg/1280px-Telus-Logo.svg.png" 
             alt="TELUS Logo" 
             class="w-auto h-13 mx-auto mb-8" />
        
        <div class="bg-white rounded-xl shadow-lg p-8">
            <h1 class="text-2xl font-bold text-center mb-6 text-gray-800">Welcome to TELUS Identity Hub</h1>
            <p class="text-gray-600 text-center mb-6">Please enter your email address to continue</p>
            
            <form method="POST" class="space-y-4">
                <input type="hidden" name="SAMLRequest" id="SAMLRequest" value="%s">
                
                <div class="space-y-2">
                    <label for="email" class="block text-sm font-medium text-gray-700">Email Address</label>
                    <input type="email" 
                           name="email" 
                           id="email" 
                           required 
                           placeholder="Enter your email address"
                           class="w-full px-4 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                </div>
                
                <button type="submit" 
                        class="w-full bg-purple-900 hover:bg-purple-800 text-white font-semibold py-3 px-4 rounded-md transition-colors duration-200">
                    Continue
                </button>
            </form>
        </div>
    </div>
</body>
</html>
`
