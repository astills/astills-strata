package main

import (
	"crypto/tls"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"

	"github.com/strata-io/service-extension/orchestrator"
)

// Microsoft Entra authentication response
type EntraAuthResponse struct {
	AccessToken string `json:"access_token"`
	TokenType   string `json:"token_type"`
	ExpiresIn   int    `json:"expires_in"`
}

// Login page HTML template with embedded JavaScript for Microsoft Entra authentication
const loginPageHTML = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Microsoft Entra Login - Maverics6</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #0078d4 0%, #40e0d0 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .container {
            background: white;
            padding: 2.5rem;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
            width: 100%;
            max-width: 420px;
        }

        .login-form {
            display: block;
        }

        .dashboard {
            display: none;
            text-align: center;
        }

        .logo-section {
            text-align: center;
            margin-bottom: 1.5rem;
        }

        .microsoft-logo {
            width: 120px;
            margin-bottom: 0.5rem;
        }

        h1 {
            color: #1a1a1a;
            margin-bottom: 0.5rem;
            text-align: center;
            font-size: 1.8rem;
        }

        .subtitle {
            color: #666;
            text-align: center;
            margin-bottom: 1.5rem;
            font-size: 0.95rem;
        }

        .form-group {
            margin-bottom: 1.2rem;
        }

        label {
            display: block;
            margin-bottom: 0.5rem;
            color: #333;
            font-weight: 500;
            font-size: 0.95rem;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 0.8rem;
            border: 1px solid #d1d1d1;
            border-radius: 4px;
            font-size: 1rem;
            transition: border-color 0.3s;
        }

        input[type="text"]:focus,
        input[type="password"]:focus {
            outline: none;
            border-color: #0078d4;
            box-shadow: 0 0 0 2px rgba(0, 120, 212, 0.1);
        }

        .btn {
            width: 100%;
            padding: 0.8rem;
            background-color: #0078d4;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 1rem;
            font-weight: 500;
            cursor: pointer;
            margin-top: 1rem;
            transition: background-color 0.3s;
        }

        .btn:hover {
            background-color: #106ebe;
        }

        .btn-logout {
            background-color: #d83b01;
            width: auto;
            padding: 0.6rem 1.2rem;
            margin-top: 1rem;
        }

        .btn-logout:hover {
            background-color: #b92b00;
        }

        .error {
            color: #d83b01;
            margin-top: 0.5rem;
            font-size: 0.9rem;
            padding: 0.5rem;
            background-color: #fdf2f0;
            border-radius: 4px;
            display: none;
        }

        .error.show {
            display: block;
        }

        .success {
            color: #107c10;
            margin-top: 0.5rem;
            font-size: 0.9rem;
            padding: 0.5rem;
            background-color: #f1faf1;
            border-radius: 4px;
            display: none;
        }

        .success.show {
            display: block;
        }

        .app-info {
            background-color: #f6f6f6;
            padding: 1rem;
            border-radius: 6px;
            margin-bottom: 1.5rem;
            font-size: 0.9rem;
            color: #333;
            border-left: 3px solid #0078d4;
        }

        .app-info strong {
            color: #0078d4;
        }

        .welcome-message {
            color: #0078d4;
            font-size: 1.3rem;
            margin-bottom: 1rem;
            font-weight: 500;
        }

        .dashboard-content {
            margin: 2rem 0;
        }

        .feature-box {
            background: linear-gradient(135deg, #f8f9fa 0%, #ffffff 100%);
            padding: 1.2rem;
            margin: 1rem 0;
            border-radius: 8px;
            text-align: left;
            border: 1px solid #e1e1e1;
            transition: transform 0.2s, box-shadow 0.2s;
            cursor: pointer;
        }

        .feature-box:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .feature-box h3 {
            color: #0078d4;
            margin-bottom: 0.5rem;
            font-size: 1.1rem;
        }

        .user-info {
            background: linear-gradient(135deg, #e8f4fd 0%, #ffffff 100%);
            padding: 1.2rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
            border: 1px solid #cde6f7;
            text-align: left;
        }

        .user-info strong {
            color: #0078d4;
        }

        .info-row {
            margin: 0.5rem 0;
            font-size: 0.95rem;
        }

        .info-label {
            display: inline-block;
            min-width: 120px;
            font-weight: 500;
            color: #333;
        }

        .info-value {
            color: #666;
        }

        .current-time {
            font-size: 0.9rem;
            color: #666;
            margin-top: 1rem;
        }

        .loading {
            display: none;
            text-align: center;
            margin-top: 1rem;
        }

        .spinner {
            border: 3px solid #f3f3f3;
            border-top: 3px solid #0078d4;
            border-radius: 50%;
            width: 30px;
            height: 30px;
            animation: spin 1s linear infinite;
            margin: 0 auto;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .tenant-info {
            font-size: 0.85rem;
            color: #666;
            text-align: center;
            margin-top: 1rem;
            padding-top: 1rem;
            border-top: 1px solid #e1e1e1;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Login Form -->
        <div id="loginForm" class="login-form">
            <div class="logo-section">
                <h1>Maverics6</h1>
                <div class="subtitle">Microsoft Entra Authentication</div>
            </div>
            
            <div class="app-info">
                <strong>Application Details:</strong><br>
                App Name: Maverics6<br>
                Authentication: Microsoft Entra ID<br>
                Tenant: Your Organization<br>
                Powered by Strata Identity
            </div>

            <form id="loginFormElement">
                <div class="form-group">
                    <label for="username">Email Address:</label>
                    <input type="text" id="username" name="username" placeholder="user@yourdomain.com" required>
                </div>

                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" id="password" name="password" placeholder="Enter your password" required>
                </div>

                <button type="submit" class="btn">Sign in with Microsoft</button>
                
                <div class="loading" id="loading">
                    <div class="spinner"></div>
                    <p>Authenticating with Microsoft Entra...</p>
                </div>
                
                <div id="errorMessage" class="error"></div>
                <div id="successMessage" class="success"></div>
            </form>

            <div class="tenant-info">
                Secured by Microsoft Entra ID<br>
                Application ID: Maverics6
            </div>
        </div>

        <!-- Dashboard (Hidden initially) -->
        <div id="dashboard" class="dashboard">
            <h1>Maverics6 Dashboard</h1>
            
            <div class="welcome-message">
                Welcome, <span id="welcomeUser"></span>!
            </div>

            <div class="user-info">
                <strong>Session Information</strong>
                <div class="info-row">
                    <span class="info-label">User:</span>
                    <span class="info-value" id="userInfoName"></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Login Time:</span>
                    <span class="info-value" id="loginTime"></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Session ID:</span>
                    <span class="info-value" id="sessionId"></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Provider:</span>
                    <span class="info-value">Microsoft Entra ID</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Application:</span>
                    <span class="info-value">Maverics6</span>
                </div>
            </div>

            <div class="dashboard-content">
                <div class="feature-box">
                    <h3>🔐 Identity Management</h3>
                    <p>Manage user identities and access controls through Strata Identity orchestration.</p>
                </div>

                <div class="feature-box">
                    <h3>📊 Analytics & Reports</h3>
                    <p>View authentication analytics, access logs, and security reports.</p>
                </div>

                <div class="feature-box">
                    <h3>⚙️ Application Settings</h3>
                    <p>Configure application settings, permissions, and integration options.</p>
                </div>

                <div class="feature-box">
                    <h3>🔒 Security Center</h3>
                    <p>Review security policies, MFA settings, and compliance status.</p>
                </div>
            </div>

            <div class="current-time">
                Current Time: <span id="currentTime"></span>
            </div>

            <button id="logoutBtn" class="btn btn-logout">Sign Out</button>
        </div>
    </div>

    <script>
        // DOM elements
        const loginForm = document.getElementById('loginForm');
        const dashboard = document.getElementById('dashboard');
        const loginFormElement = document.getElementById('loginFormElement');
        const usernameInput = document.getElementById('username');
        const passwordInput = document.getElementById('password');
        const errorMessage = document.getElementById('errorMessage');
        const successMessage = document.getElementById('successMessage');
        const loading = document.getElementById('loading');
        const logoutBtn = document.getElementById('logoutBtn');
        const welcomeUser = document.getElementById('welcomeUser');
        const userInfoName = document.getElementById('userInfoName');
        const loginTime = document.getElementById('loginTime');
        const sessionId = document.getElementById('sessionId');
        const currentTime = document.getElementById('currentTime');

        // Current user session
        let currentUser = null;
        let currentSessionId = null;

        // Check if user is already logged in (from server session)
        async function checkExistingSession() {
            try {
                const response = await fetch('/session', {
                    method: 'GET',
                    credentials: 'include'
                });
                
                const data = await response.json();
                
                if (data.valid) {
                    currentUser = data.username;
                    currentSessionId = data.sessionId;
                    showDashboard(data.username, data.sessionId, data.loginTime);
                }
            } catch (error) {
                console.log('No existing session found');
            }
        }

        // Show error message
        function showError(message) {
            errorMessage.textContent = message;
            errorMessage.classList.add('show');
            successMessage.classList.remove('show');
            loading.style.display = 'none';
            setTimeout(() => {
                errorMessage.classList.remove('show');
            }, 5000);
        }

        // Show success message
        function showSuccess(message) {
            successMessage.textContent = message;
            successMessage.classList.add('show');
            errorMessage.classList.remove('show');
            loading.style.display = 'none';
        }

        // Show loading
        function showLoading() {
            loading.style.display = 'block';
            errorMessage.classList.remove('show');
            successMessage.classList.remove('show');
        }

        // Show dashboard
        function showDashboard(username, sessionId, loginTimeStr) {
            loginForm.style.display = 'none';
            dashboard.style.display = 'block';
            
            welcomeUser.textContent = username;
            userInfoName.textContent = username;
            loginTime.textContent = new Date(loginTimeStr).toLocaleString();
            sessionId.textContent = sessionId;
            
            updateCurrentTime();
            // Update time every second
            setInterval(updateCurrentTime, 1000);
        }

        // Show login form
        function showLoginForm() {
            loginForm.style.display = 'block';
            dashboard.style.display = 'none';
            
            // Clear form
            usernameInput.value = '';
            passwordInput.value = '';
            errorMessage.classList.remove('show');
            successMessage.classList.remove('show');
            loading.style.display = 'none';
        }

        // Update current time display
        function updateCurrentTime() {
            const now = new Date();
            currentTime.textContent = now.toLocaleString();
        }

        // Handle login form submission
        loginFormElement.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const username = usernameInput.value.trim();
            const password = passwordInput.value;

            // Validate credentials
            if (!username || !password) {
                showError('Please enter both email and password');
                return;
            }

            // Basic email validation
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(username)) {
                showError('Please enter a valid email address');
                return;
            }

            showLoading();

            try {
                // Send login request to service extension
                const response = await fetch('/auth', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    credentials: 'include',
                    body: JSON.stringify({
                        username: username,
                        password: password
                    })
                });

                const data = await response.json();

                if (data.success) {
                    // Successful login
                    currentUser = data.username;
                    currentSessionId = data.session_id;
                    
                    showSuccess(data.message || 'Authentication successful!');
                    
                    setTimeout(() => {
                        showDashboard(data.username, data.session_id, data.login_time);
                    }, 1000);
                } else {
                    showError(data.error || 'Authentication failed. Please check your credentials.');
                }
            } catch (error) {
                showError('Network error. Please check your connection and try again.');
                console.error('Login error:', error);
            }
        });

        // Handle logout
        logoutBtn.addEventListener('click', async function() {
            if (confirm('Are you sure you want to sign out?')) {
                try {
                    const response = await fetch('/logout', {
                        method: 'POST',
                        credentials: 'include'
                    });
                    
                    const data = await response.json();
                    
                    if (data.success) {
                        currentUser = null;
                        currentSessionId = null;
                        showLoginForm();
                        showSuccess('You have been signed out successfully.');
                    }
                } catch (error) {
                    console.error('Logout error:', error);
                    // Still show login form even if logout fails
                    currentUser = null;
                    currentSessionId = null;
                    showLoginForm();
                }
            }
        });

        // Auto-focus username field
        usernameInput.focus();

        // Check for existing session on page load
        checkExistingSession();

        // Handle Enter key on password field
        passwordInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                loginFormElement.dispatchEvent(new Event('submit'));
            }
        });

        // Add some interactivity to feature boxes
        document.addEventListener('click', function(e) {
            if (e.target.closest('.feature-box')) {
                const featureBox = e.target.closest('.feature-box');
                const title = featureBox.querySelector('h3').textContent;
                alert('Feature: ' + title + '\n\nThis feature would be available in the full Maverics6 application.');
            }
        });
    </script>
</body>
</html>`

// IsAuthenticated checks if the current session is marked as authenticated by Microsoft Entra.
func IsAuthenticated(api orchestrator.Orchestrator, _ http.ResponseWriter, _ *http.Request) bool {
	logger := api.Logger()
	logger.Debug("se", "determining if user is authenticated via Microsoft Entra")

	// Retrieve the current session
	session, err := api.Session()
	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		return false
	}

	// Check if the session has the Microsoft Entra authentication flag
	isEntraAuth := session.GetString("entra.authenticated")

	// Return true if authenticated
	if isEntraAuth == "true" {
		logger.Debug("se", "user is authenticated via Microsoft Entra")
		return true
	}

	logger.Debug("se", "user is not authenticated via Microsoft Entra")
	return false
}

// Authenticate serves the login page and handles Microsoft Entra authentication.
func Authenticate(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	logger.Debug("se", "serving Microsoft Entra login page for Maverics6")

	// Check if this is a POST request for authentication
	if req.Method == "POST" {
		handleEntraAuthentication(api, rw, req)
		return
	}

	// Check for bypass header - if present, redirect to application
	if req.Header.Get("X-Entra-Authenticated") == "true" {
		logger.Debug("se", "bypass header detected, redirecting to application")
		// Add authentication header to bypass original form
		rw.Header().Set("X-Entra-Authenticated", "true")
		rw.Header().Set("X-User-Email", req.Header.Get("X-User-Email"))
		http.Redirect(rw, req, "/", http.StatusFound)
		return
	}

	// Serve the login page
	rw.Header().Set("Content-Type", "text/html; charset=utf-8")
	rw.WriteHeader(http.StatusOK)
	rw.Write([]byte(loginPageHTML))
}

// handleEntraAuthentication processes the authentication request
func handleEntraAuthentication(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	logger.Debug("se", "processing Microsoft Entra authentication for Maverics6")

	// Parse the request body
	var authRequest struct {
		Username string `json:"username"`
		Password string `json:"password"`
	}

	if err := json.NewDecoder(req.Body).Decode(&authRequest); err != nil {
		logger.Error("se", "failed to decode request body", "error", err.Error())
		respondWithJSON(rw, http.StatusBadRequest, map[string]interface{}{
			"success": false,
			"error":   "Invalid request format",
		})
		return
	}

	// Validate input
	if authRequest.Username == "" || authRequest.Password == "" {
		logger.Error("se", "missing username or password")
		respondWithJSON(rw, http.StatusBadRequest, map[string]interface{}{
			"success": false,
			"error":   "Username and password are required",
		})
		return
	}

	// Authenticate with Microsoft Entra
	accessToken, err := authenticateWithMicrosoftEntra(api, authRequest.Username, authRequest.Password)
	if err != nil {
		logger.Error("se", "Microsoft Entra authentication failed", "username", authRequest.Username, "error", err.Error())
		respondWithJSON(rw, http.StatusUnauthorized, map[string]interface{}{
			"success": false,
			"error":   "Authentication failed. Please check your credentials and try again.",
		})
		return
	}

	// Get session and store authentication data
	session, err := api.Session()
	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		respondWithJSON(rw, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"error":   "Session error occurred",
		})
		return
	}

	// Store authentication data in session
	session.SetString("entra.authenticated", "true")
	session.SetString("entra.username", authRequest.Username)
	session.SetString("entra.access_token", accessToken)
	session.SetString("entra.login_time", time.Now().Format(time.RFC3339))
	sessionID := generateSessionID()
	session.SetString("entra.session_id", sessionID)
	session.SetString("entra.app_name", "Maverics6")
	session.SetString("entra.tenant_id", "13b7feb2-c2de-455a-a5df-1f7fd82fc51d")

	// Save session
	if err := session.Save(); err != nil {
		logger.Error("se", "unable to save session", "error", err.Error())
		respondWithJSON(rw, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"error":   "Failed to save session",
		})
		return
	}

	logger.Debug("se", "user authenticated successfully via Maverics6", "username", authRequest.Username)

	// Return success response
	respondWithJSON(rw, http.StatusOK, map[string]interface{}{
		"success":    true,
		"username":   authRequest.Username,
		"session_id": sessionID,
		"login_time": time.Now().Format(time.RFC3339),
		"message":    "Authentication successful!",
	})
}

// authenticateWithMicrosoftEntra performs OAuth2 Resource Owner Password Credentials flow
func authenticateWithMicrosoftEntra(api orchestrator.Orchestrator, username, password string) (string, error) {
	logger := api.Logger()
	logger.Debug("se", "authenticating with Microsoft Entra for Maverics6", "username", username)

	// Configuration with your provided credentials
	// NOTE: In production, these should be stored in secrets/environment variables
	clientID := "04553b7b-c1ec-42b4-af87-23ad73f8b452"        // Your Application (client) ID
	clientSecret := "415d7fb1-e2f9-4f9e-b3de-065207e20275"    // Your client secret
	tenantID := "13b7feb2-c2de-455a-a5df-1f7fd82fc51d"        // Your Directory (tenant) ID

	// Try to get from secret provider first (for production use)
	secretProvider, err := api.SecretProvider()
	if err == nil {
		// Override with secrets if they exist
		if secret := secretProvider.GetString("AZURE_CLIENT_ID"); secret != "" {
			clientID = secret
		}
		if secret := secretProvider.GetString("AZURE_CLIENT_SECRET"); secret != "" {
			clientSecret = secret
		}
		if secret := secretProvider.GetString("AZURE_TENANT_ID"); secret != "" {
			tenantID = secret
		}
	}

	// Microsoft Entra OAuth2 token endpoint
	tokenURL := fmt.Sprintf("https://login.microsoftonline.com/%s/oauth2/v2.0/token", tenantID)

	// Prepare the request data
	data := url.Values{}
	data.Set("grant_type", "password")
	data.Set("client_id", clientID)
	data.Set("client_secret", clientSecret)
	data.Set("username", username)
	data.Set("password", password)
	data.Set("scope", "https://graph.microsoft.com/.default offline_access")

	// Create the HTTP request
	req, err := http.NewRequest("POST", tokenURL, strings.NewReader(data.Encode()))
	if err != nil {
		return "", fmt.Errorf("failed to create request: %w", err)
	}

	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")

	// Create HTTP client with timeout
	client := &http.Client{
		Timeout: 30 * time.Second,
		Transport: &http.Transport{
			TLSClientConfig: &tls.Config{
				InsecureSkipVerify: false, // Keep this false in production
			},
		},
	}

	// Execute the request
	resp, err := client.Do(req)
	if err != nil {
		return "", fmt.Errorf("request failed: %w", err)
	}
	defer resp.Body.Close()

	// Read the response body
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", fmt.Errorf("failed to read response: %w", err)
	}

	// Check for successful response
	if resp.StatusCode != http.StatusOK {
		logger.Error("se", "authentication failed", "status", resp.StatusCode, "response", string(body))
		
		// Parse error response for better error messages
		var errorResp map[string]interface{}
		if err := json.Unmarshal(body, &errorResp); err == nil {
			if errorDesc, ok := errorResp["error_description"].(string); ok {
				return "", fmt.Errorf("authentication failed: %s", errorDesc)
			}
		}
		return "", fmt.Errorf("authentication failed with status %d", resp.StatusCode)
	}

	// Parse the successful response
	var tokenResponse EntraAuthResponse
	if err := json.Unmarshal(body, &tokenResponse); err != nil {
		return "", fmt.Errorf("failed to parse response: %w", err)
	}

	logger.Debug("se", "Microsoft Entra authentication successful", "username", username)
	return tokenResponse.AccessToken, nil
}

// generateSessionID creates a unique session identifier
func generateSessionID() string {
	return fmt.Sprintf("maverics6_sess_%d_%s", time.Now().UnixNano(), generateRandomString(8))
}

// generateRandomString generates a random string of specified length
func generateRandomString(length int) string {
	const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
	result := make([]byte, length)
	for i := range result {
		result[i] = charset[time.Now().UnixNano()%int64(len(charset))]
	}
	return string(result)
}

// respondWithJSON sends a JSON response
func respondWithJSON(w http.ResponseWriter, statusCode int, response interface{}) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(statusCode)
	json.NewEncoder(w).Encode(response)
}

// LoadAttributes loads user attributes from Microsoft Entra and stores them in session
func LoadAttributes(api orchestrator.Orchestrator, _ http.ResponseWriter, _ *http.Request) error {
	logger := api.Logger()
	logger.Debug("se", "loading attributes from Microsoft Entra for Maverics6")

	session, err := api.Session()
	if err != nil {
		return fmt.Errorf("unable to retrieve session: %w", err)
	}

	// Get user information from session
	username := session.GetString("entra.username")
	accessToken := session.GetString("entra.access_token")

	if username == "" || accessToken == "" {
		return fmt.Errorf("missing authentication data in session")
	}

	// Store additional attributes in session
	session.SetString("entra.email", username)
	session.SetString("entra.provider", "microsoft-entra")
	session.SetString("entra.tenant_id", "13b7feb2-c2de-455a-a5df-1f7fd82fc51d")
	session.SetString("entra.client_id", "04553b7b-c1ec-42b4-af87-23ad73f8b452")
	session.SetString("entra.app_name", "Maverics6")
	session.SetString("entra.object_id", "1990dc0b-1365-4ee0-a929-e0753fb469b7")

	// Save session
	if err := session.Save(); err != nil {
		return fmt.Errorf("unable to save session: %w", err)
	}

	logger.Debug("se", "attributes loaded successfully for Maverics6", "username", username)
	return nil
}

// BuildAccessTokenClaims creates claims for access tokens
func BuildAccessTokenClaims(api orchestrator.Orchestrator, _ *http.Request) (map[string]any, error) {
	logger := api.Logger()
	logger.Debug("se", "building access token claims for Maverics6")

	session, err := api.Session()
	if err != nil {
		return nil, fmt.Errorf("unable to retrieve session: %w", err)
	}

	username := session.GetString("entra.username")
	email := session.GetString("entra.email")
	tenantID := session.GetString("entra.tenant_id")
	clientID := session.GetString("entra.client_id")

	return map[string]any{
		"sub":       username,
		"email":     email,
		"iss":       fmt.Sprintf("https://login.microsoftonline.com/%s/v2.0", tenantID),
		"aud":       clientID,
		"appid":     clientID,
		"app_name":  "Maverics6",
		"tenant_id": tenantID,
		"iat":       time.Now().Unix(),
		"exp":       time.Now().Add(time.Hour).Unix(),
	}, nil
}

// BuildIDTokenClaims creates claims for ID tokens
func BuildIDTokenClaims(api orchestrator.Orchestrator, _ *http.Request) (map[string]any, error) {
	logger := api.Logger()
	logger.Debug("se", "building ID token claims for Maverics6")

	session, err := api.Session()
	if err != nil {
		return nil, fmt.Errorf("unable to retrieve session: %w", err)
	}

	username := session.GetString("entra.username")
	email := session.GetString("entra.email")
	provider := session.GetString("entra.provider")
	tenantID := session.GetString("entra.tenant_id")
	clientID := session.GetString("entra.client_id")
	objectID := session.GetString("entra.object_id")

	return map[string]any{
		"sub":          username,
		"email":        email,
		"provider":     provider,
		"iss":          fmt.Sprintf("https://login.microsoftonline.com/%s/v2.0", tenantID),
		"aud":          clientID,
		"oid":          objectID,
		"tid":          tenantID,
		"app_name":     "Maverics6",
		"nonce":        generateRandomString(16),
		"iat":          time.Now().Unix(),
		"exp":          time.Now().Add(time.Hour).Unix(),
		"auth_time":    time.Now().Unix(),
		"amr":          []string{"pwd"},
		"idp":          "https://login.microsoftonline.com",
	}, nil
}

// Additional helper functions for session management

// HandleSessionCheck handles GET /session requests to check existing sessions
func HandleSessionCheck(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	if req.Method != "GET" {
		http.Error(rw, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	session, err := api.Session()
	if err != nil {
		respondWithJSON(rw, http.StatusOK, map[string]interface{}{
			"valid": false,
		})
		return
	}

	isAuthenticated := session.GetString("entra.authenticated") == "true"
	if !isAuthenticated {
		respondWithJSON(rw, http.StatusOK, map[string]interface{}{
			"valid": false,
		})
		return
	}

	username := session.GetString("entra.username")
	sessionID := session.GetString("entra.session_id")
	loginTime := session.GetString("entra.login_time")

	respondWithJSON(rw, http.StatusOK, map[string]interface{}{
		"valid":     true,
		"username":  username,
		"sessionId": sessionID,
		"loginTime": loginTime,
	})
}

// HandleLogout handles POST /logout requests
func HandleLogout(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	if req.Method != "POST" {
		http.Error(rw, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	logger := api.Logger()
	session, err := api.Session()
	if err != nil {
		logger.Error("se", "unable to retrieve session for logout", "error", err.Error())
		respondWithJSON(rw, http.StatusOK, map[string]interface{}{
			"success": true,
			"message": "Logged out",
		})
		return
	}

	// Clear session data
	session.SetString("entra.authenticated", "false")
	session.SetString("entra.username", "")
	session.SetString("entra.access_token", "")
	session.SetString("entra.session_id", "")
	
	// Save the cleared session
	if err := session.Save(); err != nil {
		logger.Error("se", "unable to save cleared session", "error", err.Error())
	}

	respondWithJSON(rw, http.StatusOK, map[string]interface{}{
		"success": true,
		"message": "Successfully logged out",
	})
}