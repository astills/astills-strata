package main

import (
	"crypto/tls"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"

	"github.com/strata-io/service-extension/orchestrator"
)

// Microsoft Entra authentication response
type EntraAuthResponse struct {
	AccessToken string `json:"access_token"`
	TokenType   string `json:"token_type"`
	ExpiresIn   int    `json:"expires_in"`
}

// Login page HTML template with embedded JavaScript for Microsoft Entra authentication
const loginPageHTML = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Microsoft Entra Login</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f0f2f5;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .container {
            background: white;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
        }

        .login-form {
            display: block;
        }

        .dashboard {
            display: none;
            text-align: center;
        }

        h1 {
            color: #333;
            margin-bottom: 1.5rem;
            text-align: center;
        }

        .form-group {
            margin-bottom: 1rem;
        }

        label {
            display: block;
            margin-bottom: 0.5rem;
            color: #555;
            font-weight: bold;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 0.75rem;
            border: 2px solid #ddd;
            border-radius: 4px;
            font-size: 1rem;
        }

        input[type="text"]:focus,
        input[type="password"]:focus {
            outline: none;
            border-color: #4CAF50;
        }

        .btn {
            width: 100%;
            padding: 0.75rem;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 1rem;
            cursor: pointer;
            margin-top: 1rem;
        }

        .btn:hover {
            background-color: #45a049;
        }

        .btn-logout {
            background-color: #f44336;
            width: auto;
            padding: 0.5rem 1rem;
            margin-top: 1rem;
        }

        .btn-logout:hover {
            background-color: #da190b;
        }

        .error {
            color: #f44336;
            margin-top: 0.5rem;
            font-size: 0.9rem;
        }

        .success {
            color: #4CAF50;
            margin-top: 0.5rem;
            font-size: 0.9rem;
        }

        .demo-info {
            background-color: #e7f3ff;
            padding: 1rem;
            border-radius: 4px;
            margin-bottom: 1rem;
            font-size: 0.9rem;
            color: #333;
        }

        .welcome-message {
            color: #4CAF50;
            font-size: 1.2rem;
            margin-bottom: 1rem;
        }

        .dashboard-content {
            margin: 2rem 0;
        }

        .feature-box {
            background-color: #f9f9f9;
            padding: 1rem;
            margin: 1rem 0;
            border-radius: 4px;
            text-align: left;
        }

        .feature-box h3 {
            color: #333;
            margin-bottom: 0.5rem;
        }

        .user-info {
            background-color: #e8f5e8;
            padding: 1rem;
            border-radius: 4px;
            margin-bottom: 1rem;
        }

        .current-time {
            font-size: 0.9rem;
            color: #666;
            margin-top: 1rem;
        }

        .loading {
            display: none;
            text-align: center;
            margin-top: 1rem;
        }

        .spinner {
            border: 4px solid #f3f3f3;
            border-top: 4px solid #4CAF50;
            border-radius: 50%;
            width: 30px;
            height: 30px;
            animation: spin 1s linear infinite;
            margin: 0 auto;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Login Form -->
        <div id="loginForm" class="login-form">
            <h1>Microsoft Entra Login</h1>
            
            <div class="demo-info">
                <strong>Microsoft Entra Authentication:</strong><br>
                Use your Microsoft Entra (Azure AD) credentials to login.<br>
                This service is integrated with Strata Identity.
            </div>

            <form id="loginFormElement">
                <div class="form-group">
                    <label for="username">Username (Email):</label>
                    <input type="text" id="username" name="username" required>
                </div>

                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" id="password" name="password" required>
                </div>

                <button type="submit" class="btn">Login with Microsoft Entra</button>
                
                <div class="loading" id="loading">
                    <div class="spinner"></div>
                    <p>Authenticating with Microsoft Entra...</p>
                </div>
                
                <div id="errorMessage" class="error"></div>
                <div id="successMessage" class="success"></div>
            </form>
        </div>

        <!-- Dashboard (Hidden initially) -->
        <div id="dashboard" class="dashboard">
            <h1>Strata Identity Dashboard</h1>
            
            <div class="welcome-message">
                Welcome back, <span id="welcomeUser"></span>!
            </div>

            <div class="user-info">
                <strong>User Information:</strong><br>
                Username: <span id="userInfoName"></span><br>
                Login Time: <span id="loginTime"></span><br>
                Session ID: <span id="sessionId"></span><br>
                Authentication: Microsoft Entra
            </div>

            <div class="dashboard-content">
                <div class="feature-box">
                    <h3>🔐 Identity Management</h3>
                    <p>Manage your identity and access controls through Strata Identity.</p>
                </div>

                <div class="feature-box">
                    <h3>📊 Analytics</h3>
                    <p>View your application analytics and access reports.</p>
                </div>

                <div class="feature-box">
                    <h3>⚙️ Settings</h3>
                    <p>Manage your account settings and preferences.</p>
                </div>

                <div class="feature-box">
                    <h3>🔒 Security</h3>
                    <p>Review security settings and access logs.</p>
                </div>
            </div>

            <div class="current-time">
                Current Time: <span id="currentTime"></span>
            </div>

            <button id="logoutBtn" class="btn btn-logout">Logout</button>
        </div>
    </div>

    <script>
        // DOM elements
        const loginForm = document.getElementById('loginForm');
        const dashboard = document.getElementById('dashboard');
        const loginFormElement = document.getElementById('loginFormElement');
        const usernameInput = document.getElementById('username');
        const passwordInput = document.getElementById('password');
        const errorMessage = document.getElementById('errorMessage');
        const successMessage = document.getElementById('successMessage');
        const loading = document.getElementById('loading');
        const logoutBtn = document.getElementById('logoutBtn');
        const welcomeUser = document.getElementById('welcomeUser');
        const userInfoName = document.getElementById('userInfoName');
        const loginTime = document.getElementById('loginTime');
        const sessionId = document.getElementById('sessionId');
        const currentTime = document.getElementById('currentTime');

        // Current user session
        let currentUser = null;
        let currentSessionId = null;

        // Check if user is already logged in (from server session)
        async function checkExistingSession() {
            try {
                const response = await fetch('/session', {
                    method: 'GET',
                    credentials: 'include'
                });
                
                const data = await response.json();
                
                if (data.valid) {
                    currentUser = data.username;
                    currentSessionId = data.sessionId;
                    showDashboard(data.username, data.sessionId, data.loginTime);
                }
            } catch (error) {
                console.log('No existing session found');
            }
        }

        // Show error message
        function showError(message) {
            errorMessage.textContent = message;
            successMessage.textContent = '';
            loading.style.display = 'none';
            setTimeout(() => {
                errorMessage.textContent = '';
            }, 5000);
        }

        // Show success message
        function showSuccess(message) {
            successMessage.textContent = message;
            errorMessage.textContent = '';
            loading.style.display = 'none';
        }

        // Show loading
        function showLoading() {
            loading.style.display = 'block';
            errorMessage.textContent = '';
            successMessage.textContent = '';
        }

        // Show dashboard
        function showDashboard(username, sessionId, loginTime) {
            loginForm.style.display = 'none';
            dashboard.style.display = 'block';
            
            welcomeUser.textContent = username;
            userInfoName.textContent = username;
            loginTime.textContent = loginTime;
            sessionId.textContent = sessionId;
            
            updateCurrentTime();
            // Update time every second
            setInterval(updateCurrentTime, 1000);
        }

        // Show login form
        function showLoginForm() {
            loginForm.style.display = 'block';
            dashboard.style.display = 'none';
            
            // Clear form
            usernameInput.value = '';
            passwordInput.value = '';
            errorMessage.textContent = '';
            successMessage.textContent = '';
            loading.style.display = 'none';
        }

        // Update current time display
        function updateCurrentTime() {
            const now = new Date();
            currentTime.textContent = now.toLocaleString();
        }

        // Handle login form submission
        loginFormElement.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const username = usernameInput.value.trim();
            const password = passwordInput.value;

            // Validate credentials
            if (!username || !password) {
                showError('Please enter both username and password');
                return;
            }

            showLoading();

            try {
                // Send login request to service extension
                const response = await fetch('/auth', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    credentials: 'include',
                    body: JSON.stringify({
                        username: username,
                        password: password
                    })
                });

                const data = await response.json();

                if (data.success) {
                    // Successful login
                    currentUser = data.username;
                    currentSessionId = data.session_id;
                    
                    showSuccess(data.message || 'Login successful!');
                    
                    setTimeout(() => {
                        showDashboard(data.username, data.session_id, data.login_time);
                    }, 1000);
                } else {
                    showError(data.error || 'Authentication failed');
                }
            } catch (error) {
                showError('Network error. Please try again.');
                console.error('Login error:', error);
            }
        });

        // Handle logout
        logoutBtn.addEventListener('click', async function() {
            try {
                const response = await fetch('/logout', {
                    method: 'POST',
                    credentials: 'include'
                });
                
                const data = await response.json();
                
                if (data.success) {
                    currentUser = null;
                    currentSessionId = null;
                    showLoginForm();
                }
            } catch (error) {
                console.error('Logout error:', error);
                // Still show login form even if logout fails
                currentUser = null;
                currentSessionId = null;
                showLoginForm();
            }
        });

        // Auto-focus username field
        usernameInput.focus();

        // Check for existing session on page load
        checkExistingSession();

        // Handle Enter key on password field
        passwordInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                loginFormElement.dispatchEvent(new Event('submit'));
            }
        });

        // Add some interactivity to feature boxes
        document.addEventListener('click', function(e) {
            if (e.target.closest('.feature-box')) {
                const featureBox = e.target.closest('.feature-box');
                const title = featureBox.querySelector('h3').textContent;
                alert('You clicked on: ' + title + '\\n\\nThis would normally navigate to that feature in Strata Identity.');
            }
        });
    </script>
</body>
</html>`

// IsAuthenticated checks if the current session is marked as authenticated by Microsoft Entra.
func IsAuthenticated(api orchestrator.Orchestrator, _ http.ResponseWriter, _ *http.Request) bool {
	logger := api.Logger()
	logger.Debug("se", "determining if user is authenticated via Microsoft Entra")

	// Retrieve the current session
	session, err := api.Session()
	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		return false
	}

	// Check if the session has the Microsoft Entra authentication flag
	isEntraAuth := session.GetString("entra.authenticated")

	// Return true if authenticated
	if isEntraAuth == "true" {
		logger.Debug("se", "user is authenticated via Microsoft Entra")
		return true
	}

	logger.Debug("se", "user is not authenticated via Microsoft Entra")
	return false
}

// Authenticate serves the login page and handles Microsoft Entra authentication.
func Authenticate(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	logger.Debug("se", "serving Microsoft Entra login page")

	// Check if this is a POST request for authentication
	if req.Method == "POST" {
		handleEntraAuthentication(api, rw, req)
		return
	}

	// Check for bypass header - if present, redirect to application
	if req.Header.Get("X-Entra-Authenticated") == "true" {
		logger.Debug("se", "bypass header detected, redirecting to application")
		// Add authentication header to bypass original form
		rw.Header().Set("X-Entra-Authenticated", "true")
		rw.Header().Set("X-User-Email", req.Header.Get("X-User-Email"))
		http.Redirect(rw, req, "/", http.StatusFound)
		return
	}

	// Serve the login page
	rw.Header().Set("Content-Type", "text/html; charset=utf-8")
	rw.WriteHeader(http.StatusOK)
	rw.Write([]byte(loginPageHTML))
}

// handleEntraAuthentication processes the authentication request
func handleEntraAuthentication(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	logger.Debug("se", "processing Microsoft Entra authentication")

	// Parse the request body
	var authRequest struct {
		Username string `json:"username"`
		Password string `json:"password"`
	}

	if err := json.NewDecoder(req.Body).Decode(&authRequest); err != nil {
		logger.Error("se", "failed to decode request body", "error", err.Error())
		http.Error(rw, "Invalid request format", http.StatusBadRequest)
		return
	}

	// Validate input
	if authRequest.Username == "" || authRequest.Password == "" {
		logger.Error("se", "missing username or password")
		respondWithJSON(rw, http.StatusBadRequest, map[string]interface{}{
			"success": false,
			"error":   "Username and password are required",
		})
		return
	}

	// Authenticate with Microsoft Entra
	accessToken, err := authenticateWithMicrosoftEntra(api, authRequest.Username, authRequest.Password)
	if err != nil {
		logger.Error("se", "Microsoft Entra authentication failed", "username", authRequest.Username, "error", err.Error())
		respondWithJSON(rw, http.StatusUnauthorized, map[string]interface{}{
			"success": false,
			"error":   "Invalid username or password",
		})
		return
	}

	// Get session and store authentication data
	session, err := api.Session()
	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		http.Error(rw, "Session error", http.StatusInternalServerError)
		return
	}

	// Store authentication data in session
	session.SetString("entra.authenticated", "true")
	session.SetString("entra.username", authRequest.Username)
	session.SetString("entra.access_token", accessToken)
	session.SetString("entra.login_time", time.Now().Format(time.RFC3339))
	sessionID := generateSessionID()
	session.SetString("entra.session_id", sessionID)

	// Save session
	if err := session.Save(); err != nil {
		logger.Error("se", "unable to save session", "error", err.Error())
		http.Error(rw, "Session save error", http.StatusInternalServerError)
		return
	}

	logger.Debug("se", "user authenticated successfully", "username", authRequest.Username)

	// Return success response
	respondWithJSON(rw, http.StatusOK, map[string]interface{}{
		"success":    true,
		"username":   authRequest.Username,
		"session_id": sessionID,
		"login_time": time.Now().Format(time.RFC3339),
		"message":    "Login successful!",
	})
}

// authenticateWithMicrosoftEntra performs OAuth2 Resource Owner Password Credentials flow
func authenticateWithMicrosoftEntra(api orchestrator.Orchestrator, username, password string) (string, error) {
	logger := api.Logger()
	logger.Debug("se", "authenticating with Microsoft Entra", "username", username)

	// Get configuration from secrets
	secretProvider, err := api.SecretProvider()
	if err != nil {
		logger.Error("se", "failed to get secret provider", "error", err.Error())
		return "", fmt.Errorf("failed to retrieve secret provider: %w", err)
	}

	clientID := secretProvider.GetString("AZURE_CLIENT_ID")
	if clientID == "" {
		return "", fmt.Errorf("AZURE_CLIENT_ID not found or empty")
	}
	
	clientSecret := secretProvider.GetString("AZURE_CLIENT_SECRET")
	if clientSecret == "" {
		return "", fmt.Errorf("AZURE_CLIENT_SECRET not found or empty")
	}
	
	tenantID := secretProvider.GetString("AZURE_TENANT_ID")
	if tenantID == "" {
		return "", fmt.Errorf("AZURE_TENANT_ID not found or empty")
	}

	if clientID == "" || clientSecret == "" || tenantID == "" {
		return "", fmt.Errorf("missing Microsoft Entra configuration")
	}

	// Microsoft Entra OAuth2 token endpoint
	tokenURL := fmt.Sprintf("https://login.microsoftonline.com/%s/oauth2/v2.0/token", tenantID)

	data := url.Values{}
	data.Set("grant_type", "password")
	data.Set("client_id", clientID)
	data.Set("client_secret", clientSecret)
	data.Set("username", username)
	data.Set("password", password)
	data.Set("scope", "https://graph.microsoft.com/.default")

	req, err := http.NewRequest("POST", tokenURL, strings.NewReader(data.Encode()))
	if err != nil {
		return "", fmt.Errorf("failed to create request: %w", err)
	}

	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")

	client := &http.Client{
		Timeout: 30 * time.Second,
		Transport: &http.Transport{
			TLSClientConfig: &tls.Config{InsecureSkipVerify: false},
		},
	}

	resp, err := client.Do(req)
	if err != nil {
		return "", fmt.Errorf("request failed: %w", err)
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", fmt.Errorf("failed to read response: %w", err)
	}

	if resp.StatusCode != http.StatusOK {
		return "", fmt.Errorf("authentication failed: %s", string(body))
	}

	var tokenResponse EntraAuthResponse
	if err := json.Unmarshal(body, &tokenResponse); err != nil {
		return "", fmt.Errorf("failed to parse response: %w", err)
	}

	return tokenResponse.AccessToken, nil
}

// generateSessionID creates a unique session identifier
func generateSessionID() string {
	return fmt.Sprintf("entra_sess_%d", time.Now().UnixNano())
}

// respondWithJSON sends a JSON response
func respondWithJSON(w http.ResponseWriter, statusCode int, response interface{}) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(statusCode)
	json.NewEncoder(w).Encode(response)
}

// LoadAttributes loads user attributes from Microsoft Entra and stores them in session
func LoadAttributes(api orchestrator.Orchestrator, _ http.ResponseWriter, _ *http.Request) error {
	logger := api.Logger()
	logger.Debug("se", "loading attributes from Microsoft Entra")

	session, err := api.Session()
	if err != nil {
		return fmt.Errorf("unable to retrieve session: %w", err)
	}

	// Get user information from session
	username := session.GetString("entra.username")
	accessToken := session.GetString("entra.access_token")

	if username == "" || accessToken == "" {
		return fmt.Errorf("missing authentication data in session")
	}

	// Store additional attributes in session
	session.SetString("entra.email", username)
	session.SetString("entra.provider", "EEID")
	session.SetString("entra.tenant_id", "13b7feb2-c2de-455a-a5df-1f7fd82fc51d")

	// Save session
	if err := session.Save(); err != nil {
		return fmt.Errorf("unable to save session: %w", err)
	}

	logger.Debug("se", "attributes loaded successfully", "username", username)
	return nil
}

// BuildAccessTokenClaims creates claims for access tokens
func BuildAccessTokenClaims(api orchestrator.Orchestrator, _ *http.Request) (map[string]any, error) {
	logger := api.Logger()
	logger.Debug("se", "building access token claims")

	session, err := api.Session()
	if err != nil {
		return nil, fmt.Errorf("unable to retrieve session: %w", err)
	}

	username, err := session.GetString("entra.username")
	email, err := session.GetString("entra.email")

	return map[string]any{
		"sub":   username,
		"email": email,
		"iss":   "strata-entra-auth",
		"aud":   "application",
	}, nil
}

// BuildIDTokenClaims creates claims for ID tokens
func BuildIDTokenClaims(api orchestrator.Orchestrator, _ *http.Request) (map[string]any, error) {
	logger := api.Logger()
	logger.Debug("se", "building ID token claims")

	session, err := api.Session()
	if err != nil {
		return nil, fmt.Errorf("unable to retrieve session: %w", err)
	}

	username, err := session.GetString("entra.username")
	email, err := session.GetString("entra.email")
	provider, err := session.GetString("entra.provider")

	return map[string]any{
		"sub":      username,
		"email":    email,
		"provider": provider,
		"iss":      "strata-entra-auth",
		"aud":      "application",
	}, nil
}