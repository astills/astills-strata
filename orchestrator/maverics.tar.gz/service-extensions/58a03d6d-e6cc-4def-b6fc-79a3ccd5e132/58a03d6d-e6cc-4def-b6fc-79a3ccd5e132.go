package main

import (
	"crypto/rand"
	"crypto/tls"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"

	"github.com/strata-io/service-extension/orchestrator"
)

// Microsoft Entra authentication response
type EntraAuthResponse struct {
	AccessToken string `json:"access_token"`
	TokenType   string `json:"token_type"`
	ExpiresIn   int    `json:"expires_in"`
}

// Login page HTML template with embedded JavaScript for Microsoft Entra authentication
const loginPageHTML = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Microsoft Entra Login</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f0f2f5;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .container {
            background: white;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
        }

        .login-form {
            display: block;
        }

        .mfa-form {
            display: none;
        }

        .dashboard {
            display: none;
            text-align: center;
        }

        h1 {
            color: #333;
            margin-bottom: 1.5rem;
            text-align: center;
        }

        .form-group {
            margin-bottom: 1rem;
        }

        label {
            display: block;
            margin-bottom: 0.5rem;
            color: #555;
            font-weight: bold;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 0.75rem;
            border: 2px solid #ddd;
            border-radius: 4px;
            font-size: 1rem;
        }

        input[type="text"]:focus,
        input[type="password"]:focus {
            outline: none;
            border-color: #4CAF50;
        }

        .btn {
            width: 100%;
            padding: 0.75rem;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 1rem;
            cursor: pointer;
            margin-top: 1rem;
        }

        .btn:hover {
            background-color: #45a049;
        }

        .btn-logout {
            background-color: #f44336;
            width: auto;
            padding: 0.5rem 1rem;
            margin-top: 1rem;
        }

        .btn-logout:hover {
            background-color: #da190b;
        }

        .error {
            color: #f44336;
            margin-top: 0.5rem;
            font-size: 0.9rem;
        }

        .success {
            color: #4CAF50;
            margin-top: 0.5rem;
            font-size: 0.9rem;
        }

        .demo-info {
            background-color: #e7f3ff;
            padding: 1rem;
            border-radius: 4px;
            margin-bottom: 1rem;
            font-size: 0.9rem;
            color: #333;
        }

        .welcome-message {
            color: #4CAF50;
            font-size: 1.2rem;
            margin-bottom: 1rem;
        }

        .dashboard-content {
            margin: 2rem 0;
        }

        .feature-box {
            background-color: #f9f9f9;
            padding: 1rem;
            margin: 1rem 0;
            border-radius: 4px;
            text-align: left;
        }

        .feature-box h3 {
            color: #333;
            margin-bottom: 0.5rem;
        }

        .user-info {
            background-color: #e8f5e8;
            padding: 1rem;
            border-radius: 4px;
            margin-bottom: 1rem;
        }

        .current-time {
            font-size: 0.9rem;
            color: #666;
            margin-top: 1rem;
        }

        .loading {
            display: none;
            text-align: center;
            margin-top: 1rem;
        }

        .spinner {
            border: 4px solid #f3f3f3;
            border-top: 4px solid #4CAF50;
            border-radius: 50%;
            width: 30px;
            height: 30px;
            animation: spin 1s linear infinite;
            margin: 0 auto;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Login Form -->
        <div id="loginForm" class="login-form">
            <h1>Microsoft Entra Login</h1>
            
            <div class="demo-info">
                <strong>Microsoft Entra Authentication:</strong><br>
                Use your Microsoft Entra (Azure AD) credentials to login.<br>
                This service is integrated with Strata Identity.
            </div>

            <form id="loginFormElement">
                <div class="form-group">
                    <label for="username">Username (Email):</label>
                    <input type="text" id="username" name="username" required>
                </div>

                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" id="password" name="password" required>
                </div>

                <button type="submit" class="btn">Login with Microsoft Entra</button>
                
                <div class="loading" id="loading">
                    <div class="spinner"></div>
                    <p>Authenticating with Microsoft Entra...</p>
                </div>
                
                <div id="errorMessage" class="error"></div>
                <div id="successMessage" class="success"></div>
            </form>
        </div>

        <!-- MFA Form (Initially Hidden) -->
        <div id="mfaForm" class="mfa-form">
            <h1>Multi-Factor Authentication</h1>
            
            <div class="demo-info">
                <strong>WebAuthn Passkey Required:</strong><br>
                Use your registered passkey to complete authentication.
            </div>

            <div class="form-group">
                <label>Authenticated User:</label>
                <input type="text" id="mfaUser" readonly style="background-color: #f0f0f0;">
            </div>

            <button id="mfaAuthBtn" class="btn">🔑 Authenticate with Passkey</button>
            
            <div class="loading" id="mfaLoading">
                <div class="spinner"></div>
                <p>Verifying passkey...</p>
            </div>
            
            <div id="mfaErrorMessage" class="error"></div>
            <div id="mfaSuccessMessage" class="success"></div>
        </div>

        <!-- Dashboard (Hidden initially) -->
        <div id="dashboard" class="dashboard">
            <h1>Strata Identity Dashboard</h1>
            
            <div class="welcome-message">
                Welcome back, <span id="welcomeUser"></span>!
            </div>

            <div class="user-info">
                <strong>User Information:</strong><br>
                Username: <span id="userInfoName"></span><br>
                Login Time: <span id="loginTime"></span><br>
                Session ID: <span id="sessionId"></span><br>
                Authentication: Microsoft Entra + WebAuthn MFA
            </div>

            <div class="dashboard-content">
                <div class="feature-box">
                    <h3>🔐 Identity Management</h3>
                    <p>Manage your identity and access controls through Strata Identity.</p>
                </div>

                <div class="feature-box">
                    <h3>📊 Analytics</h3>
                    <p>View your application analytics and access reports.</p>
                </div>

                <div class="feature-box">
                    <h3>⚙️ Settings</h3>
                    <p>Manage your account settings and preferences.</p>
                </div>

                <div class="feature-box">
                    <h3>🔒 Security</h3>
                    <p>Review security settings and access logs.</p>
                </div>
            </div>

            <div class="current-time">
                Current Time: <span id="currentTime"></span>
            </div>

            <button id="logoutBtn" class="btn btn-logout">Logout</button>
        </div>
    </div>

    <script>
        // DOM elements
        const loginForm = document.getElementById('loginForm');
        const mfaForm = document.getElementById('mfaForm');
        const dashboard = document.getElementById('dashboard');
        const loginFormElement = document.getElementById('loginFormElement');
        const usernameInput = document.getElementById('username');
        const passwordInput = document.getElementById('password');
        const errorMessage = document.getElementById('errorMessage');
        const successMessage = document.getElementById('successMessage');
        const loading = document.getElementById('loading');
        const mfaUser = document.getElementById('mfaUser');
        const mfaAuthBtn = document.getElementById('mfaAuthBtn');
        const mfaLoading = document.getElementById('mfaLoading');
        const mfaErrorMessage = document.getElementById('mfaErrorMessage');
        const mfaSuccessMessage = document.getElementById('mfaSuccessMessage');
        const logoutBtn = document.getElementById('logoutBtn');
        const welcomeUser = document.getElementById('welcomeUser');
        const userInfoName = document.getElementById('userInfoName');
        const loginTime = document.getElementById('loginTime');
        const sessionId = document.getElementById('sessionId');
        const currentTime = document.getElementById('currentTime');

        // Current user session
        let currentUser = null;
        let currentSessionId = null;
        let tempSession = null;

        // Check if user is already logged in (from server session)
        async function checkExistingSession() {
            try {
                const response = await fetch('/session', {
                    method: 'GET',
                    credentials: 'include'
                });
                
                const data = await response.json();
                
                if (data.valid && data.mfa_complete) {
                    currentUser = data.username;
                    currentSessionId = data.sessionId;
                    showDashboard(data.username, data.sessionId, data.loginTime);
                }
            } catch (error) {
                console.log('No existing session found');
            }
        }

        // Show error message
        function showError(message, isMfa = false) {
            const errorEl = isMfa ? mfaErrorMessage : errorMessage;
            const successEl = isMfa ? mfaSuccessMessage : successMessage;
            const loadingEl = isMfa ? mfaLoading : loading;
            
            errorEl.textContent = message;
            successEl.textContent = '';
            loadingEl.style.display = 'none';
            setTimeout(() => {
                errorEl.textContent = '';
            }, 5000);
        }

        // Show success message
        function showSuccess(message, isMfa = false) {
            const errorEl = isMfa ? mfaErrorMessage : errorMessage;
            const successEl = isMfa ? mfaSuccessMessage : successMessage;
            const loadingEl = isMfa ? mfaLoading : loading;
            
            successEl.textContent = message;
            errorEl.textContent = '';
            loadingEl.style.display = 'none';
        }

        // Show loading
        function showLoading(isMfa = false) {
            const loadingEl = isMfa ? mfaLoading : loading;
            const errorEl = isMfa ? mfaErrorMessage : errorMessage;
            const successEl = isMfa ? mfaSuccessMessage : successMessage;
            
            loadingEl.style.display = 'block';
            errorEl.textContent = '';
            successEl.textContent = '';
        }

        // Show MFA form
        function showMfaForm(username) {
            loginForm.style.display = 'none';
            mfaForm.style.display = 'block';
            dashboard.style.display = 'none';
            mfaUser.value = username;
        }

        // Show dashboard
        function showDashboard(username, sessionId, loginTime) {
            loginForm.style.display = 'none';
            mfaForm.style.display = 'none';
            dashboard.style.display = 'block';
            
            welcomeUser.textContent = username;
            userInfoName.textContent = username;
            loginTime.textContent = loginTime;
            sessionId.textContent = sessionId;
            
            updateCurrentTime();
            // Update time every second
            setInterval(updateCurrentTime, 1000);
        }

        // Show login form
        function showLoginForm() {
            loginForm.style.display = 'block';
            mfaForm.style.display = 'none';
            dashboard.style.display = 'none';
            
            // Clear form
            usernameInput.value = '';
            passwordInput.value = '';
            errorMessage.textContent = '';
            successMessage.textContent = '';
            loading.style.display = 'none';
        }

        // Update current time display
        function updateCurrentTime() {
            const now = new Date();
            currentTime.textContent = now.toLocaleString();
        }

        // Handle login form submission
        loginFormElement.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const username = usernameInput.value.trim();
            const password = passwordInput.value;

            // Validate credentials
            if (!username || !password) {
                showError('Please enter both username and password');
                return;
            }

            showLoading();

            try {
                // Send login request to service extension
                const response = await fetch('/auth', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    credentials: 'include',
                    body: JSON.stringify({
                        username: username,
                        password: password
                    })
                });

                const data = await response.json();

                if (data.success) {
                    if (data.requires_mfa) {
                        // Need MFA
                        tempSession = data.temp_session;
                        showSuccess('Login successful! Please complete MFA.');
                        setTimeout(() => {
                            showMfaForm(username);
                        }, 1000);
                    } else {
                        // Direct login (shouldn't happen with MFA enabled)
                        currentUser = data.username;
                        currentSessionId = data.session_id;
                        showSuccess(data.message || 'Login successful!');
                        setTimeout(() => {
                            showDashboard(data.username, data.session_id, data.login_time);
                        }, 1000);
                    }
                } else {
                    showError(data.error || 'Authentication failed');
                }
            } catch (error) {
                showError('Network error. Please try again.');
                console.error('Login error:', error);
            }
        });

        // Handle MFA authentication
        mfaAuthBtn.addEventListener('click', async function() {
            if (!window.PublicKeyCredential) {
                showError('WebAuthn is not supported in this browser', true);
                return;
            }

            showLoading(true);

            try {
                // Get WebAuthn challenge
                const challengeResp = await fetch('/mfa/challenge', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    credentials: 'include',
                    body: JSON.stringify({
                        temp_session: tempSession
                    })
                });

                const challengeData = await challengeResp.json();

                if (!challengeData.success) {
                    showError(challengeData.error || 'Failed to get challenge', true);
                    return;
                }

                // Perform WebAuthn authentication
                const credential = await navigator.credentials.create({
                    publicKey: {
                        challenge: Uint8Array.from(challengeData.challenge, c => c.charCodeAt(0)),
                        rp: { 
                            name: "Strata Identity",
                            id: window.location.hostname 
                        },
                        user: {
                            id: Uint8Array.from(mfaUser.value, c => c.charCodeAt(0)),
                            name: mfaUser.value,
                            displayName: mfaUser.value
                        },
                        pubKeyCredParams: [
                            { type: "public-key", alg: -7 },  // ES256
                            { type: "public-key", alg: -257 } // RS256
                        ],
                        authenticatorSelection: {
                            authenticatorAttachment: "platform",
                            userVerification: "preferred"
                        },
                        timeout: 60000,
                        attestation: "direct"
                    }
                });

                // Verify MFA
                const verifyResp = await fetch('/mfa/verify', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    credentials: 'include',
                    body: JSON.stringify({
                        temp_session: tempSession,
                        credential_id: credential.id,
                        challenge: challengeData.challenge
                    })
                });

                const verifyData = await verifyResp.json();

                if (verifyData.success) {
                    currentUser = verifyData.username;
                    currentSessionId = verifyData.session_id;
                    showSuccess('MFA verification successful!', true);
                    setTimeout(() => {
                        showDashboard(verifyData.username, verifyData.session_id, verifyData.login_time);
                    }, 1000);
                } else {
                    showError(verifyData.error || 'MFA verification failed', true);
                }
            } catch (error) {
                console.error('MFA error:', error);
                if (error.name === 'NotAllowedError') {
                    showError('MFA was cancelled or timed out', true);
                } else {
                    showError('MFA error: ' + error.message, true);
                }
            }
        });

        // Handle logout
        logoutBtn.addEventListener('click', async function() {
            try {
                const response = await fetch('/logout', {
                    method: 'POST',
                    credentials: 'include'
                });
                
                const data = await response.json();
                
                if (data.success) {
                    currentUser = null;
                    currentSessionId = null;
                    tempSession = null;
                    showLoginForm();
                }
            } catch (error) {
                console.error('Logout error:', error);
                // Still show login form even if logout fails
                currentUser = null;
                currentSessionId = null;
                tempSession = null;
                showLoginForm();
            }
        });

        // Auto-focus username field
        usernameInput.focus();

        // Check for existing session on page load
        checkExistingSession();

        // Handle Enter key on password field
        passwordInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                loginFormElement.dispatchEvent(new Event('submit'));
            }
        });

        // Add some interactivity to feature boxes
        document.addEventListener('click', function(e) {
            if (e.target.closest('.feature-box')) {
                const featureBox = e.target.closest('.feature-box');
                const title = featureBox.querySelector('h3').textContent;
                alert('You clicked on: ' + title + '\\n\\nThis would normally navigate to that feature in Strata Identity.');
            }
        });
    </script>
</body>
</html>`

// IsAuthenticated checks if the current session is marked as authenticated by Microsoft Entra with MFA.
func IsAuthenticated(api orchestrator.Orchestrator, _ http.ResponseWriter, _ *http.Request) bool {
	logger := api.Logger()
	logger.Debug("se", "determining if user is authenticated via Microsoft Entra with MFA")

	// Retrieve the current session
	session, err := api.Session()
	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		return false
	}

	// Check if the session has both Entra authentication and MFA completion
	isEntraAuth, err := session.GetString("entra.authenticated")
	if err != nil {
		logger.Error("se", "unable to get entra.authenticated from session", "error", err.Error())
		return false
	}
	
	isMfaComplete, err := session.GetString("mfa.complete")
	if err != nil {
		logger.Error("se", "unable to get mfa.complete from session", "error", err.Error())
		return false
	}

	// Return true if both authenticated and MFA complete
	if isEntraAuth == "true" && isMfaComplete == "true" {
		logger.Debug("se", "user is fully authenticated via Microsoft Entra with MFA")
		return true
	}

	logger.Debug("se", "user is not fully authenticated")
	return false
}

// Authenticate serves the login page and handles Microsoft Entra authentication with MFA.
func Authenticate(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	
	// Route based on path
	path := req.URL.Path
	
	// Handle API endpoints
	switch {
	case strings.HasSuffix(path, "/auth") && req.Method == "POST":
		handleEntraAuthentication(api, rw, req)
		return
	case strings.HasSuffix(path, "/mfa/challenge") && req.Method == "POST":
		handleMfaChallenge(api, rw, req)
		return
	case strings.HasSuffix(path, "/mfa/verify") && req.Method == "POST":
		handleMfaVerify(api, rw, req)
		return
	case strings.HasSuffix(path, "/session") && req.Method == "GET":
		handleSessionCheck(api, rw, req)
		return
	case strings.HasSuffix(path, "/logout") && req.Method == "POST":
		handleLogout(api, rw, req)
		return
	}

	logger.Debug("se", "serving Microsoft Entra login page with MFA")

	// Serve the login page
	rw.Header().Set("Content-Type", "text/html; charset=utf-8")
	rw.WriteHeader(http.StatusOK)
	rw.Write([]byte(loginPageHTML))
}

// handleEntraAuthentication processes the authentication request
func handleEntraAuthentication(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	logger.Debug("se", "processing Microsoft Entra authentication")

	// Parse the request body
	var authRequest struct {
		Username string `json:"username"`
		Password string `json:"password"`
	}

	if err := json.NewDecoder(req.Body).Decode(&authRequest); err != nil {
		logger.Error("se", "failed to decode request body", "error", err.Error())
		respondWithJSON(rw, http.StatusBadRequest, map[string]interface{}{
			"success": false,
			"error":   "Invalid request format",
		})
		return
	}

	// Validate input
	if authRequest.Username == "" || authRequest.Password == "" {
		logger.Error("se", "missing username or password")
		respondWithJSON(rw, http.StatusBadRequest, map[string]interface{}{
			"success": false,
			"error":   "Username and password are required",
		})
		return
	}

	// Authenticate with Microsoft Entra
	accessToken, err := authenticateWithMicrosoftEntra(api, authRequest.Username, authRequest.Password)
	if err != nil {
		logger.Error("se", "Microsoft Entra authentication failed", "username", authRequest.Username, "error", err.Error())
		respondWithJSON(rw, http.StatusUnauthorized, map[string]interface{}{
			"success": false,
			"error":   "Invalid username or password",
		})
		return
	}

	// Get session and store authentication data
	session, err := api.Session()
	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		respondWithJSON(rw, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"error":   "Session error",
		})
		return
	}

	// Store authentication data in session (but not complete until MFA)
	session.SetString("entra.authenticated", "true")
	session.SetString("entra.username", authRequest.Username)
	session.SetString("entra.access_token", accessToken)
	session.SetString("entra.login_time", time.Now().Format(time.RFC3339))
	
	// Generate temporary session for MFA
	tempSession := generateSessionID()
	session.SetString("temp.session", tempSession)
	session.SetString("mfa.complete", "false")

	// Save session
	if err := session.Save(); err != nil {
		logger.Error("se", "unable to save session", "error", err.Error())
		respondWithJSON(rw, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"error":   "Session save error",
		})
		return
	}

	logger.Debug("se", "Entra authentication successful, MFA required", "username", authRequest.Username)

	// Return success response requiring MFA
	respondWithJSON(rw, http.StatusOK, map[string]interface{}{
		"success":      true,
		"requires_mfa": true,
		"temp_session": tempSession,
		"message":      "Login successful! Please complete MFA.",
	})
}

// handleMfaChallenge generates a WebAuthn challenge
func handleMfaChallenge(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	logger.Debug("se", "generating MFA challenge")

	var challengeReq struct {
		TempSession string `json:"temp_session"`
	}

	if err := json.NewDecoder(req.Body).Decode(&challengeReq); err != nil {
		respondWithJSON(rw, http.StatusBadRequest, map[string]interface{}{
			"success": false,
			"error":   "Invalid request",
		})
		return
	}

	session, err := api.Session()
	if err != nil {
		respondWithJSON(rw, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"error":   "Session error",
		})
		return
	}

	// Verify temp session
	storedTempSession, err := session.GetString("temp.session")
	if err != nil {
		logger.Error("se", "unable to get temp.session from session", "error", err.Error())
		respondWithJSON(rw, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"error":   "Session error",
		})
		return
	}
	
	if storedTempSession != challengeReq.TempSession {
		respondWithJSON(rw, http.StatusUnauthorized, map[string]interface{}{
			"success": false,
			"error":   "Invalid session",
		})
		return
	}

	// Generate challenge
	challenge := generateChallenge()
	session.SetString("mfa.challenge", challenge)
	session.Save()

	logger.Debug("se", "MFA challenge generated")
	respondWithJSON(rw, http.StatusOK, map[string]interface{}{
		"success":   true,
		"challenge": challenge,
	})
}

// handleMfaVerify verifies the MFA response
func handleMfaVerify(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	logger.Debug("se", "verifying MFA")

	var verifyReq struct {
		TempSession  string `json:"temp_session"`
		CredentialID string `json:"credential_id"`
		Challenge    string `json:"challenge"`
	}

	if err := json.NewDecoder(req.Body).Decode(&verifyReq); err != nil {
		respondWithJSON(rw, http.StatusBadRequest, map[string]interface{}{
			"success": false,
			"error":   "Invalid request",
		})
		return
	}

	session, err := api.Session()
	if err != nil {
		respondWithJSON(rw, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"error":   "Session error",
		})
		return
	}

	// Verify temp session and challenge
	storedTempSession, err := session.GetString("temp.session")
	if err != nil {
		logger.Error("se", "unable to get temp.session from session", "error", err.Error())
		respondWithJSON(rw, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"error":   "Session error",
		})
		return
	}
	
	storedChallenge, err := session.GetString("mfa.challenge")
	if err != nil {
		logger.Error("se", "unable to get mfa.challenge from session", "error", err.Error())
		respondWithJSON(rw, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"error":   "Session error",
		})
		return
	}
	
	if storedTempSession != verifyReq.TempSession || storedChallenge != verifyReq.Challenge {
		respondWithJSON(rw, http.StatusUnauthorized, map[string]interface{}{
			"success": false,
			"error":   "Invalid session or challenge",
		})
		return
	}

	// Mark MFA as complete
	session.SetString("mfa.complete", "true")
	sessionID := generateSessionID()
	session.SetString("entra.session_id", sessionID)
	
	// Clear temporary data
	session.SetString("temp.session", "")
	session.SetString("mfa.challenge", "")

	if err := session.Save(); err != nil {
		respondWithJSON(rw, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"error":   "Session save error",
		})
		return
	}

	username, _ := session.GetString("entra.username")
	loginTime, _ := session.GetString("entra.login_time")

	logger.Debug("se", "MFA verification successful", "username", username)

	respondWithJSON(rw, http.StatusOK, map[string]interface{}{
		"success":    true,
		"username":   username,
		"session_id": sessionID,
		"login_time": loginTime,
		"message":    "MFA verification successful!",
	})
}

// handleSessionCheck checks if user has valid session
func handleSessionCheck(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	session, err := api.Session()
	if err != nil {
		respondWithJSON(rw, http.StatusOK, map[string]interface{}{
			"valid": false,
		})
		return
	}

	isEntraAuth, _ := session.GetString("entra.authenticated")
	isMfaComplete, _ := session.GetString("mfa.complete")
	
	if isEntraAuth == "true" && isMfaComplete == "true" {
		username, _ := session.GetString("entra.username")
		sessionID, _ := session.GetString("entra.session_id")
		loginTime, _ := session.GetString("entra.login_time")
		
		respondWithJSON(rw, http.StatusOK, map[string]interface{}{
			"valid":        true,
			"mfa_complete": true,
			"username":     username,
			"sessionId":    sessionID,
			"loginTime":    loginTime,
		})
	} else {
		respondWithJSON(rw, http.StatusOK, map[string]interface{}{
			"valid": false,
		})
	}
}

// handleLogout clears the session
func handleLogout(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	logger.Debug("se", "processing logout")
	
	session, err := api.Session()
	if err == nil {
		// Clear all session data
		session.SetString("entra.authenticated", "")
		session.SetString("entra.username", "")
		session.SetString("entra.access_token", "")
		session.SetString("entra.session_id", "")
		session.SetString("entra.login_time", "")
		session.SetString("mfa.complete", "")
		session.SetString("mfa.challenge", "")
		session.SetString("temp.session", "")
		session.Save()
	}
	
	respondWithJSON(rw, http.StatusOK, map[string]interface{}{
		"success": true,
		"message": "Logged out successfully",
	})
}

// authenticateWithMicrosoftEntra performs OAuth2 Resource Owner Password Credentials flow
func authenticateWithMicrosoftEntra(api orchestrator.Orchestrator, username, password string) (string, error) {
	logger := api.Logger()
	logger.Debug("se", "authenticating with Microsoft Entra", "username", username)

	// Get configuration from secrets
	secretProvider, err := api.SecretProvider()
	if err != nil {
		logger.Error("se", "failed to get secret provider", "error", err.Error())
		return "", fmt.Errorf("failed to retrieve secret provider: %w", err)
	}

	clientID := secretProvider.GetString("AZURE_CLIENT_ID")
	if clientID == "" {
		return "", fmt.Errorf("AZURE_CLIENT_ID not found or empty")
	}
	
	clientSecret := secretProvider.GetString("AZURE_CLIENT_SECRET")
	if clientSecret == "" {
		return "", fmt.Errorf("AZURE_CLIENT_SECRET not found or empty")
	}
	
	tenantID := secretProvider.GetString("AZURE_TENANT_ID")
	if tenantID == "" {
		return "", fmt.Errorf("AZURE_TENANT_ID not found or empty")
	}

	if clientID == "" || clientSecret == "" || tenantID == "" {
		return "", fmt.Errorf("missing Microsoft Entra configuration")
	}

	// Microsoft Entra OAuth2 token endpoint
	tokenURL := fmt.Sprintf("https://login.microsoftonline.com/%s/oauth2/v2.0/token", tenantID)

	data := url.Values{}
	data.Set("grant_type", "password")
	data.Set("client_id", clientID)
	data.Set("client_secret", clientSecret)
	data.Set("username", username)
	data.Set("password", password)
	data.Set("scope", "https://graph.microsoft.com/.default")

	req, err := http.NewRequest("POST", tokenURL, strings.NewReader(data.Encode()))
	if err != nil {
		return "", fmt.Errorf("failed to create request: %w", err)
	}

	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")

	client := &http.Client{
		Timeout: 30 * time.Second,
		Transport: &http.Transport{
			TLSClientConfig: &tls.Config{InsecureSkipVerify: false},
		},
	}

	resp, err := client.Do(req)
	if err != nil {
		return "", fmt.Errorf("request failed: %w", err)
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", fmt.Errorf("failed to read response: %w", err)
	}

	if resp.StatusCode != http.StatusOK {
		return "", fmt.Errorf("authentication failed: %s", string(body))
	}

	var tokenResponse EntraAuthResponse
	if err := json.Unmarshal(body, &tokenResponse); err != nil {
		return "", fmt.Errorf("failed to parse response: %w", err)
	}

	return tokenResponse.AccessToken, nil
}

// generateSessionID creates a unique session identifier
func generateSessionID() string {
	return fmt.Sprintf("entra_sess_%d", time.Now().UnixNano())
}

// generateChallenge creates a WebAuthn challenge
func generateChallenge() string {
	b := make([]byte, 32)
	rand.Read(b)
	return base64.URLEncoding.EncodeToString(b)
}

// respondWithJSON sends a JSON response
func respondWithJSON(w http.ResponseWriter, statusCode int, response interface{}) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(statusCode)
	json.NewEncoder(w).Encode(response)
}

// LoadAttributes loads user attributes from Microsoft Entra and stores them in session
func LoadAttributes(api orchestrator.Orchestrator, _ http.ResponseWriter, _ *http.Request) error {
	logger := api.Logger()
	logger.Debug("se", "loading attributes from Microsoft Entra")

	session, err := api.Session()
	if err != nil {
		return fmt.Errorf("unable to retrieve session: %w", err)
	}

	// Get user information from session
	username, err := session.GetString("entra.username")
	if err != nil {
		return fmt.Errorf("unable to get username from session: %w", err)
	}
	
	accessToken, err := session.GetString("entra.access_token")
	if err != nil {
		return fmt.Errorf("unable to get access token from session: %w", err)
	}

	if username == "" || accessToken == "" {
		return fmt.Errorf("missing authentication data in session")
	}

	// Store additional attributes in session
	session.SetString("entra.email", username)
	session.SetString("entra.provider", "EEID")
	session.SetString("entra.tenant_id", "13b7feb2-c2de-455a-a5df-1f7fd82fc51d")

	// Save session
	if err := session.Save(); err != nil {
		return fmt.Errorf("unable to save session: %w", err)
	}

	logger.Debug("se", "attributes loaded successfully", "username", username)
	return nil
}

// BuildAccessTokenClaims creates claims for access tokens
func BuildAccessTokenClaims(api orchestrator.Orchestrator, _ *http.Request) (map[string]any, error) {
	logger := api.Logger()
	logger.Debug("se", "building access token claims")

	session, err := api.Session()
	if err != nil {
		return nil, fmt.Errorf("unable to retrieve session: %w", err)
	}

	username, _ := session.GetString("entra.username")
	email, _ := session.GetString("entra.email")

	return map[string]any{
		"sub":   username,
		"email": email,
		"iss":   "strata-entra-auth",
		"aud":   "application",
	}, nil
}

// BuildIDTokenClaims creates claims for ID tokens
func BuildIDTokenClaims(api orchestrator.Orchestrator, _ *http.Request) (map[string]any, error) {
	logger := api.Logger()
	logger.Debug("se", "building ID token claims")

	session, err := api.Session()
	if err != nil {
		return nil, fmt.Errorf("unable to retrieve session: %w", err)
	}

	username, _ := session.GetString("entra.username")
	email, _ := session.GetString("entra.email")
	provider, _ := session.GetString("entra.provider")

	return map[string]any{
		"sub":      username,
		"email":    email,
		"provider": provider,
		"iss":      "strata-entra-auth",
		"aud":      "application",
	}, nil
}