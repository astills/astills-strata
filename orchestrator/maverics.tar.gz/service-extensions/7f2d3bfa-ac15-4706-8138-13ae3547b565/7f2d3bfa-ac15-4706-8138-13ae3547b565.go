package main

import (
	"crypto/rand"
	"crypto/tls"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"

	"github.com/strata-io/service-extension/orchestrator"
)

// Microsoft Entra authentication response
type EntraAuthResponse struct {
	AccessToken string `json:"access_token"`
	TokenType   string `json:"token_type"`
	ExpiresIn   int    `json:"expires_in"`
}

// WebAuthn registration/authentication structures
type WebAuthnChallenge struct {
	Challenge string `json:"challenge"`
	UserID    string `json:"userId"`
	Username  string `json:"username"`
	ExpiresAt int64  `json:"expiresAt"`
}

type WebAuthnCredential struct {
	ID        string `json:"id"`
	PublicKey string `json:"publicKey"`
	Algorithm string `json:"algorithm"`
	UserID    string `json:"userId"`
	Username  string `json:"username"`
	CreatedAt int64  `json:"createdAt"`
}

// Login page HTML template with inline WebAuthn integration
const loginPageHTML = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enterprise Login with Passkeys</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; display: flex; align-items: center; justify-content: center; }
        .container { background: rgba(255, 255, 255, 0.95); padding: 2.5rem; border-radius: 16px; box-shadow: 0 20px 60px rgba(0, 0, 0, 0.15); width: 100%; max-width: 420px; }
        h1 { color: #333; margin-bottom: 1.5rem; text-align: center; font-weight: 600; }
        .form-group { margin-bottom: 1.25rem; }
        label { display: block; margin-bottom: 0.5rem; color: #555; font-weight: 500; font-size: 0.95rem; }
        input { width: 100%; padding: 0.85rem; border: 2px solid #e1e8ed; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease; }
        input:focus { outline: none; border-color: #667eea; box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1); }
        .btn { width: 100%; padding: 0.85rem; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border: none; border-radius: 8px; font-size: 1rem; font-weight: 500; cursor: pointer; margin-top: 1rem; transition: all 0.3s ease; }
        .btn:hover { transform: translateY(-2px); box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3); }
        .btn-passkey { background: linear-gradient(135deg, #00b4d8 0%, #0077be 100%); }
        .btn-register { background: linear-gradient(135deg, #4CAF50 0%, #45a049 100%); }
        .btn-back { background: linear-gradient(135deg, #6c757d 0%, #495057 100%); }
        .error { color: #f44336; margin-top: 0.5rem; font-size: 0.9rem; background: rgba(244, 67, 54, 0.1); padding: 0.5rem; border-radius: 4px; display: none; }
        .success { color: #4CAF50; margin-top: 0.5rem; font-size: 0.9rem; background: rgba(76, 175, 80, 0.1); padding: 0.5rem; border-radius: 4px; display: none; }
        .info-box { background: linear-gradient(135deg, #e7f3ff 0%, #f0f8ff 100%); padding: 1rem; border-radius: 8px; margin-bottom: 1rem; font-size: 0.9rem; color: #333; border: 1px solid #b3d9ff; }
        .loading { display: none; text-align: center; margin-top: 1rem; }
        .spinner { border: 3px solid rgba(102, 126, 234, 0.2); border-top: 3px solid #667eea; border-radius: 50%; width: 30px; height: 30px; animation: spin 1s linear infinite; margin: 0 auto; }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
        .hidden { display: none !important; }
        .divider { margin: 1.5rem 0; text-align: center; color: #999; position: relative; }
        .divider::before { content: ''; position: absolute; left: 0; top: 50%; width: 100%; height: 1px; background: #e1e8ed; }
        .divider span { background: rgba(255, 255, 255, 0.95); padding: 0 1rem; position: relative; font-size: 0.85rem; }
    </style>
</head>
<body>
    <div class="container">
        <!-- Login Form -->
        <div id="loginView">
            <h1>🔐 Secure Login</h1>
            <div class="info-box">
                <strong>Enterprise Authentication</strong><br>
                Microsoft Entra ID + WebAuthn Passkeys<br>
                Demo credentials: demo@example.com / any password
            </div>
            
            <button id="quickAuthBtn" class="btn btn-passkey" type="button">
                🔑 Sign in with Passkey
            </button>
            
            <div class="divider"><span>OR</span></div>
            
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" id="username" placeholder="Enter your email" />
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" placeholder="Enter your password" />
            </div>
            <button id="loginBtn" class="btn" type="button">Login with Password</button>
            
            <div class="loading" id="loginLoading"><div class="spinner"></div></div>
            <div id="loginError" class="error"></div>
            <div id="loginSuccess" class="success"></div>
        </div>
        
        <!-- MFA Form -->
        <div id="mfaView" class="hidden">
            <h1>🔑 Passkey Authentication</h1>
            <div class="info-box">
                <strong>WebAuthn Passkey Required</strong><br>
                Use your registered passkey or register a new one
            </div>
            <div class="form-group">
                <label>User:</label>
                <input type="text" id="mfaUser" readonly style="background-color: #f8f9fa;" />
            </div>
            <button id="authenticateBtn" class="btn btn-passkey" type="button">
                🔓 Authenticate with Passkey
            </button>
            <button id="registerBtn" class="btn btn-register" type="button">
                ➕ Register New Passkey
            </button>
            <button id="backBtn" class="btn btn-back" type="button">
                ← Back to Login
            </button>
            <div class="loading" id="mfaLoading"><div class="spinner"></div></div>
            <div id="mfaError" class="error"></div>
            <div id="mfaSuccess" class="success"></div>
        </div>
        
        <!-- Dashboard -->
        <div id="dashboardView" class="hidden">
            <h1>🎉 Welcome!</h1>
            <div class="info-box">
                <strong>Authentication Successful</strong><br>
                User: <span id="dashUser"></span><br>
                Session: <span id="dashSession"></span><br>
                Time: <span id="dashTime"></span>
            </div>
            <button id="logoutBtn" class="btn btn-back" type="button">Logout</button>
        </div>
    </div>
    
    <!-- Load WebAuthn library and initialize app -->
    <script src="https://cdn.jsdelivr.net/npm/@passwordless-id/webauthn@2.0.0/dist/webauthn.min.js"></script>
    <script>
    (function() {
        'use strict';
        
        // Wait for library to load
        let webauthnClient = null;
        let checkCount = 0;
        
        function waitForLibrary() {
            if (window.Passwordless && window.Passwordless.client) {
                webauthnClient = window.Passwordless.client;
                console.log('WebAuthn library loaded');
                initApp();
            } else {
                checkCount++;
                if (checkCount < 50) { // Try for 5 seconds
                    setTimeout(waitForLibrary, 100);
                } else {
                    console.error('Failed to load WebAuthn library');
                    initApp(); // Initialize anyway for demo
                }
            }
        }
        
        // State management
        let currentState = {
            tempAuth: null,
            username: null,
            sessionId: null
        };
        
        // View management
        function showView(viewName) {
            document.getElementById('loginView').classList.add('hidden');
            document.getElementById('mfaView').classList.add('hidden');
            document.getElementById('dashboardView').classList.add('hidden');
            
            if (viewName) {
                const view = document.getElementById(viewName + 'View');
                if (view) view.classList.remove('hidden');
            }
        }
        
        // Message display
        function showMessage(type, message, prefix = 'login') {
            const errorEl = document.getElementById(prefix + 'Error');
            const successEl = document.getElementById(prefix + 'Success');
            const loadingEl = document.getElementById(prefix + 'Loading');
            
            if (errorEl) errorEl.style.display = 'none';
            if (successEl) successEl.style.display = 'none';
            if (loadingEl) loadingEl.style.display = 'none';
            
            if (type === 'error' && errorEl) {
                errorEl.textContent = message;
                errorEl.style.display = 'block';
                setTimeout(() => { errorEl.style.display = 'none'; }, 5000);
            } else if (type === 'success' && successEl) {
                successEl.textContent = message;
                successEl.style.display = 'block';
                setTimeout(() => { successEl.style.display = 'none'; }, 3000);
            } else if (type === 'loading' && loadingEl) {
                loadingEl.style.display = 'block';
            }
        }
        
        // API calls
        async function apiCall(endpoint, data) {
            try {
                const response = await fetch(window.location.pathname + endpoint, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    credentials: 'include',
                    body: JSON.stringify(data)
                });
                
                if (!response.ok) {
                    throw new Error('Network response was not ok: ' + response.status);
                }
                
                const result = await response.json();
                console.log('API Response from ' + endpoint + ':', result);
                return result;
            } catch (error) {
                console.error('API Error:', error);
                throw error;
            }
        }
        
        // Initialize app
        function initApp() {
            console.log('Initializing app...');
            
            // Login with password
            document.getElementById('loginBtn').addEventListener('click', async function() {
                const username = document.getElementById('username').value.trim();
                const password = document.getElementById('password').value;
                
                if (!username || !password) {
                    showMessage('error', 'Please enter username and password');
                    return;
                }
                
                showMessage('loading', '', 'login');
                
                try {
                    const result = await apiCall('auth', {
                        username: username,
                        password: password,
                        step: 'entra'
                    });
                    
                    if (result.success) {
                        currentState.tempAuth = result;
                        currentState.username = username;
                        showMessage('success', 'Login successful! Proceeding to passkey verification...');
                        
                        setTimeout(() => {
                            document.getElementById('mfaUser').value = username;
                            showView('mfa');
                        }, 1500);
                    } else {
                        showMessage('error', result.error || 'Authentication failed');
                    }
                } catch (error) {
                    showMessage('error', 'Network error. Please try again.');
                }
            });
            
            // Quick passkey authentication
            document.getElementById('quickAuthBtn').addEventListener('click', async function() {
                if (!webauthnClient) {
                    showMessage('error', 'WebAuthn not available. Using demo mode.');
                    // Demo mode - just show dashboard
                    document.getElementById('dashUser').textContent = 'demo@example.com';
                    document.getElementById('dashSession').textContent = 'demo-session';
                    document.getElementById('dashTime').textContent = new Date().toLocaleString();
                    showView('dashboard');
                    return;
                }
                
                showMessage('loading', '', 'login');
                
                try {
                    // Get challenge
                    const challengeResult = await apiCall('webauthn/challenge', {
                        type: 'authenticate'
                    });
                    
                    if (!challengeResult.success) {
                        throw new Error(challengeResult.error || 'Failed to get challenge');
                    }
                    
                    // Perform WebAuthn authentication
                    const authentication = await webauthnClient.authenticate({
                        challenge: challengeResult.challenge,
                        allowCredentials: [],
                        userVerification: 'preferred'
                    });
                    
                    // Verify authentication
                    const verifyResult = await apiCall('webauthn/verify-quick', {
                        authentication: authentication,
                        challenge: challengeResult.challenge
                    });
                    
                    if (verifyResult.success) {
                        showMessage('success', 'Authentication successful!');
                        setTimeout(() => {
                            document.getElementById('dashUser').textContent = verifyResult.username;
                            document.getElementById('dashSession').textContent = verifyResult.session_id;
                            document.getElementById('dashTime').textContent = new Date(verifyResult.login_time).toLocaleString();
                            showView('dashboard');
                        }, 1000);
                    } else {
                        showMessage('error', verifyResult.error || 'Authentication failed');
                    }
                } catch (error) {
                    showMessage('error', 'Authentication failed: ' + error.message);
                }
            });
            
            // Authenticate with passkey (after login)
            document.getElementById('authenticateBtn').addEventListener('click', async function() {
                if (!currentState.tempAuth) {
                    showMessage('error', 'Session expired. Please login again.', 'mfa');
                    showView('login');
                    return;
                }
                
                // Check for WebAuthn support
                if (!window.PublicKeyCredential) {
                    // Demo mode for unsupported browsers
                    showMessage('success', 'Demo authentication successful!', 'mfa');
                    setTimeout(() => {
                        document.getElementById('dashUser').textContent = currentState.username;
                        document.getElementById('dashSession').textContent = 'demo-session';
                        document.getElementById('dashTime').textContent = new Date().toLocaleString();
                        showView('dashboard');
                    }, 1000);
                    return;
                }
                
                if (!webauthnClient) {
                    console.warn('WebAuthn client not loaded, creating fallback');
                    webauthnClient = createWebAuthnFallback();
                }
                
                showMessage('loading', '', 'mfa');
                
                try {
                    // Get challenge
                    const challengeResult = await apiCall('webauthn/challenge', {
                        type: 'authenticate',
                        username: currentState.tempAuth.username,
                        temp_session: currentState.tempAuth.temp_session
                    });
                    
                    if (!challengeResult.success) {
                        throw new Error(challengeResult.error || 'Failed to get challenge');
                    }
                    
                    console.log('Got authentication challenge:', challengeResult.challenge);
                    
                    // Perform WebAuthn authentication
                    const authentication = await webauthnClient.authenticate({
                        challenge: challengeResult.challenge,
                        allowCredentials: challengeResult.allowCredentials || [],
                        userVerification: 'preferred'
                    });
                    
                    console.log('Authentication completed:', authentication);
                    
                    // Verify authentication
                    const verifyResult = await apiCall('webauthn/verify', {
                        username: currentState.tempAuth.username,
                        temp_session: currentState.tempAuth.temp_session,
                        authentication: authentication,
                        challenge: challengeResult.challenge
                    });
                    
                    if (verifyResult.success) {
                        showMessage('success', 'Passkey verification successful!', 'mfa');
                        setTimeout(() => {
                            document.getElementById('dashUser').textContent = verifyResult.username;
                            document.getElementById('dashSession').textContent = verifyResult.session_id;
                            document.getElementById('dashTime').textContent = new Date(verifyResult.login_time).toLocaleString();
                            showView('dashboard');
                        }, 1000);
                    } else {
                        showMessage('error', verifyResult.error || 'Verification failed', 'mfa');
                    }
                } catch (error) {
                    console.error('Authentication error:', error);
                    showMessage('error', 'Authentication failed: ' + error.message, 'mfa');
                }
            });
            
            // Register new passkey
            document.getElementById('registerBtn').addEventListener('click', async function() {
                if (!currentState.tempAuth) {
                    showMessage('error', 'Session expired. Please login again.', 'mfa');
                    showView('login');
                    return;
                }
                
                if (!webauthnClient) {
                    showMessage('error', 'WebAuthn not available in this browser', 'mfa');
                    return;
                }
                
                showMessage('loading', '', 'mfa');
                
                try {
                    // Get challenge
                    const challengeResult = await apiCall('webauthn/challenge', {
                        type: 'register',
                        username: currentState.tempAuth.username,
                        temp_session: currentState.tempAuth.temp_session
                    });
                    
                    if (!challengeResult.success) {
                        throw new Error(challengeResult.error || 'Failed to get challenge');
                    }
                    
                    // Perform WebAuthn registration
                    const registration = await webauthnClient.register({
                        challenge: challengeResult.challenge,
                        user: currentState.tempAuth.username,
                        authenticatorSelection: {
                            authenticatorAttachment: 'platform',
                            userVerification: 'required'
                        }
                    });
                    
                    // Send registration to server
                    const registerResult = await apiCall('webauthn/register', {
                        username: currentState.tempAuth.username,
                        temp_session: currentState.tempAuth.temp_session,
                        registration: registration,
                        challenge: challengeResult.challenge
                    });
                    
                    if (registerResult.success) {
                        showMessage('success', 'Passkey registered! Now authenticate with it.', 'mfa');
                    } else {
                        showMessage('error', registerResult.error || 'Registration failed', 'mfa');
                    }
                } catch (error) {
                    showMessage('error', 'Registration failed: ' + error.message, 'mfa');
                }
            });
            
            // Back button
            document.getElementById('backBtn').addEventListener('click', function() {
                currentState = { tempAuth: null, username: null, sessionId: null };
                document.getElementById('username').value = '';
                document.getElementById('password').value = '';
                showView('login');
            });
            
            // Logout button
            document.getElementById('logoutBtn').addEventListener('click', async function() {
                try {
                    await apiCall('logout', {});
                } catch (error) {
                    console.error('Logout error:', error);
                }
                currentState = { tempAuth: null, username: null, sessionId: null };
                document.getElementById('username').value = '';
                document.getElementById('password').value = '';
                showView('login');
            });
            
            // Enter key support
            document.getElementById('password').addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    document.getElementById('loginBtn').click();
                }
            });
            
            console.log('App initialized');
        }
        
        // Start initialization
        waitForLibrary();
    })();
    </script>
</body>
</html>`

// IsAuthenticated checks if the current session is authenticated
func IsAuthenticated(api orchestrator.Orchestrator, _ http.ResponseWriter, _ *http.Request) bool {
	logger := api.Logger()
	logger.Debug("se", "checking authentication status")

	session, err := api.Session()
	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		return false
	}

	// Check both Entra and WebAuthn authentication
	entraAuth := session.GetString("entra.authenticated")
	webauthnAuth := session.GetString("webauthn.authenticated")
	quickAuth := session.GetString("webauthn.quick_auth")

	isAuth := (entraAuth == "true" && webauthnAuth == "true") || 
	         (webauthnAuth == "true" && quickAuth == "true")
	
	logger.Debug("se", "authentication check result", 
		"entraAuth", entraAuth, 
		"webauthnAuth", webauthnAuth, 
		"quickAuth", quickAuth,
		"isAuthenticated", isAuth)
	
	return isAuth
}

// Authenticate serves the login page and handles all authentication requests
func Authenticate(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	
	// Extract the path after the base URL
	path := req.URL.Path
	logger.Debug("se", "handling request", "method", req.Method, "path", path, "url", req.URL.String())
	
	// Handle POST requests to API endpoints
	if req.Method == "POST" {
		// Check if path ends with our API endpoints
		if strings.HasSuffix(path, "/auth") {
			handleEntraAuth(api, rw, req)
			return
		} else if strings.HasSuffix(path, "/auth/username-only") {
			handleUsernameOnlyAuth(api, rw, req)
			return
		} else if strings.HasSuffix(path, "/webauthn/challenge") {
			handleWebAuthnChallenge(api, rw, req)
			return
		} else if strings.HasSuffix(path, "/webauthn/register") {
			handleWebAuthnRegister(api, rw, req)
			return
		} else if strings.HasSuffix(path, "/webauthn/verify") {
			handleWebAuthnVerify(api, rw, req)
			return
		} else if strings.HasSuffix(path, "/webauthn/verify-quick") {
			handleWebAuthnQuickVerify(api, rw, req)
			return
		} else if strings.HasSuffix(path, "/logout") {
			handleLogout(api, rw, req)
			return
		}
	}
	
	// Handle GET request for session check
	if req.Method == "GET" && strings.HasSuffix(path, "/session") {
		handleSessionCheck(api, rw, req)
		return
	}

	// For all other requests, serve the login page
	rw.Header().Set("Content-Type", "text/html; charset=utf-8")
	rw.Header().Set("Cache-Control", "no-cache, no-store, must-revalidate")
	rw.WriteHeader(http.StatusOK)
	rw.Write([]byte(loginPageHTML))
}

// handleEntraAuth processes Microsoft Entra authentication
func handleEntraAuth(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	logger.Debug("se", "processing Entra authentication")

	var authReq struct {
		Username string `json:"username"`
		Password string `json:"password"`
		Step     string `json:"step"`
	}

	if err := json.NewDecoder(req.Body).Decode(&authReq); err != nil {
		logger.Error("se", "failed to decode auth request", "error", err.Error())
		respondWithJSON(rw, http.StatusBadRequest, map[string]interface{}{
			"success": false,
			"error":   "Invalid request format",
		})
		return
	}

	if authReq.Username == "" || authReq.Password == "" {
		respondWithJSON(rw, http.StatusBadRequest, map[string]interface{}{
			"success": false,
			"error":   "Username and password required",
		})
		return
	}

	// Authenticate with Entra
	accessToken, err := authenticateWithEntra(api, authReq.Username, authReq.Password)
	if err != nil {
		logger.Error("se", "Entra auth failed", "error", err.Error())
		respondWithJSON(rw, http.StatusUnauthorized, map[string]interface{}{
			"success": false,
			"error":   "Invalid credentials",
		})
		return
	}

	// Store temporary session data
	session, err := api.Session()
	if err != nil {
		logger.Error("se", "session error", "error", err.Error())
		respondWithJSON(rw, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"error":   "Session error",
		})
		return
	}

	tempSession := generateSessionID()
	session.SetString("entra.temp_auth", "true")
	session.SetString("entra.username", authReq.Username)
	session.SetString("entra.token", accessToken)
	session.SetString("entra.temp_session", tempSession)

	if err := session.Save(); err != nil {
		logger.Error("se", "failed to save session", "error", err.Error())
		respondWithJSON(rw, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"error":   "Session save error",
		})
		return
	}

	logger.Debug("se", "Entra auth successful", "username", authReq.Username)
	respondWithJSON(rw, http.StatusOK, map[string]interface{}{
		"success":      true,
		"username":     authReq.Username,
		"temp_session": tempSession,
		"requires_mfa": true,
	})
}

// handleUsernameOnlyAuth handles username-only auth for passkey registration
func handleUsernameOnlyAuth(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	
	var authReq struct {
		Username string `json:"username"`
	}

	if err := json.NewDecoder(req.Body).Decode(&authReq); err != nil {
		respondWithJSON(rw, http.StatusBadRequest, map[string]interface{}{
			"success": false,
			"error":   "Invalid request",
		})
		return
	}

	if authReq.Username == "" {
		respondWithJSON(rw, http.StatusBadRequest, map[string]interface{}{
			"success": false,
			"error":   "Username required",
		})
		return
	}

	session, err := api.Session()
	if err != nil {
		respondWithJSON(rw, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"error":   "Session error",
		})
		return
	}

	tempSession := generateSessionID()
	session.SetString("entra.temp_auth", "true")
	session.SetString("entra.username", authReq.Username)
	session.SetString("entra.temp_session", tempSession)

	if err := session.Save(); err != nil {
		respondWithJSON(rw, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"error":   "Session save error",
		})
		return
	}

	logger.Debug("se", "username-only auth successful", "username", authReq.Username)
	respondWithJSON(rw, http.StatusOK, map[string]interface{}{
		"success":      true,
		"username":     authReq.Username,
		"temp_session": tempSession,
	})
}

// handleWebAuthnChallenge generates a WebAuthn challenge
func handleWebAuthnChallenge(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	
	var challengeReq struct {
		Type        string `json:"type"`
		Username    string `json:"username"`
		TempSession string `json:"temp_session"`
	}

	if err := json.NewDecoder(req.Body).Decode(&challengeReq); err != nil {
		respondWithJSON(rw, http.StatusBadRequest, map[string]interface{}{
			"success": false,
			"error":   "Invalid request",
		})
		return
	}

	challenge := generateWebAuthnChallenge()
	
	session, err := api.Session()
	if err != nil {
		respondWithJSON(rw, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"error":   "Session error",
		})
		return
	}

	session.SetString("webauthn.challenge", challenge)
	session.SetString("webauthn.challenge_type", challengeReq.Type)
	session.SetString("webauthn.challenge_expires", fmt.Sprintf("%d", time.Now().Add(5*time.Minute).Unix()))
	
	if err := session.Save(); err != nil {
		respondWithJSON(rw, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"error":   "Session save error",
		})
		return
	}

	logger.Debug("se", "WebAuthn challenge generated", "type", challengeReq.Type)
	respondWithJSON(rw, http.StatusOK, map[string]interface{}{
		"success":   true,
		"challenge": challenge,
	})
}

// handleWebAuthnRegister handles WebAuthn registration
func handleWebAuthnRegister(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	
	var registerReq struct {
		Username     string                 `json:"username"`
		TempSession  string                 `json:"temp_session"`
		Registration map[string]interface{} `json:"registration"`
		Challenge    string                 `json:"challenge"`
	}

	if err := json.NewDecoder(req.Body).Decode(&registerReq); err != nil {
		respondWithJSON(rw, http.StatusBadRequest, map[string]interface{}{
			"success": false,
			"error":   "Invalid request",
		})
		return
	}

	session, err := api.Session()
	if err != nil {
		respondWithJSON(rw, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"error":   "Session error",
		})
		return
	}

	storedChallenge := session.GetString("webauthn.challenge")
	if storedChallenge != registerReq.Challenge {
		respondWithJSON(rw, http.StatusUnauthorized, map[string]interface{}{
			"success": false,
			"error":   "Invalid challenge",
		})
		return
	}

	// Store credential (in production, save to database)
	if registerReq.Registration["id"] != nil {
		credentialID := fmt.Sprintf("%v", registerReq.Registration["id"])
		session.SetString("webauthn.credential_id", credentialID)
		session.SetString("webauthn.credential_user", registerReq.Username)
		
		if err := session.Save(); err != nil {
			respondWithJSON(rw, http.StatusInternalServerError, map[string]interface{}{
				"success": false,
				"error":   "Failed to save credential",
			})
			return
		}
		
		logger.Debug("se", "WebAuthn credential registered", "username", registerReq.Username)
		respondWithJSON(rw, http.StatusOK, map[string]interface{}{
			"success": true,
			"message": "Passkey registered successfully",
		})
	} else {
		respondWithJSON(rw, http.StatusBadRequest, map[string]interface{}{
			"success": false,
			"error":   "Invalid registration data",
		})
	}
}

// handleWebAuthnVerify handles WebAuthn verification after Entra auth
func handleWebAuthnVerify(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	
	var verifyReq struct {
		Username       string                 `json:"username"`
		TempSession    string                 `json:"temp_session"`
		Authentication map[string]interface{} `json:"authentication"`
		Challenge      string                 `json:"challenge"`
	}

	if err := json.NewDecoder(req.Body).Decode(&verifyReq); err != nil {
		respondWithJSON(rw, http.StatusBadRequest, map[string]interface{}{
			"success": false,
			"error":   "Invalid request",
		})
		return
	}

	session, err := api.Session()
	if err != nil {
		respondWithJSON(rw, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"error":   "Session error",
		})
		return
	}

	// Validate session and challenge
	tempAuth := session.GetString("entra.temp_auth")
	tempSession := session.GetString("entra.temp_session")
	username := session.GetString("entra.username")
	storedChallenge := session.GetString("webauthn.challenge")

	if tempAuth != "true" || tempSession != verifyReq.TempSession || 
	   username != verifyReq.Username || storedChallenge != verifyReq.Challenge {
		logger.Debug("se", "session validation failed", 
			"tempAuth", tempAuth,
			"tempSessionMatch", tempSession == verifyReq.TempSession,
			"usernameMatch", username == verifyReq.Username,
			"challengeMatch", storedChallenge == verifyReq.Challenge)
		respondWithJSON(rw, http.StatusUnauthorized, map[string]interface{}{
			"success": false,
			"error":   "Invalid session or challenge",
		})
		return
	}

	// Verify authentication (in production, use proper WebAuthn verification)
	if !verifyWebAuthnAuthentication(verifyReq.Authentication, storedChallenge) {
		respondWithJSON(rw, http.StatusUnauthorized, map[string]interface{}{
			"success": false,
			"error":   "WebAuthn verification failed",
		})
		return
	}

	// Set final authentication state
	sessionID := generateSessionID()
	loginTime := time.Now().Format(time.RFC3339)
	
	session.SetString("entra.authenticated", "true")
	session.SetString("webauthn.authenticated", "true")
	session.SetString("session_id", sessionID)
	session.SetString("login_time", loginTime)
	
	// Clear temp data
	session.SetString("entra.temp_auth", "")
	session.SetString("entra.temp_session", "")
	session.SetString("webauthn.challenge", "")

	if err := session.Save(); err != nil {
		respondWithJSON(rw, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"error":   "Session save error",
		})
		return
	}

	logger.Debug("se", "User fully authenticated", "username", verifyReq.Username)
	respondWithJSON(rw, http.StatusOK, map[string]interface{}{
		"success":    true,
		"username":   verifyReq.Username,
		"session_id": sessionID,
		"login_time": loginTime,
	})
}

// handleWebAuthnQuickVerify handles quick WebAuthn authentication without Entra
func handleWebAuthnQuickVerify(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	
	var verifyReq struct {
		Authentication map[string]interface{} `json:"authentication"`
		Challenge      string                 `json:"challenge"`
	}

	if err := json.NewDecoder(req.Body).Decode(&verifyReq); err != nil {
		respondWithJSON(rw, http.StatusBadRequest, map[string]interface{}{
			"success": false,
			"error":   "Invalid request",
		})
		return
	}

	session, err := api.Session()
	if err != nil {
		respondWithJSON(rw, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"error":   "Session error",
		})
		return
	}

	storedChallenge := session.GetString("webauthn.challenge")
	if storedChallenge != verifyReq.Challenge {
		respondWithJSON(rw, http.StatusUnauthorized, map[string]interface{}{
			"success": false,
			"error":   "Invalid challenge",
		})
		return
	}

	if !verifyWebAuthnAuthentication(verifyReq.Authentication, storedChallenge) {
		respondWithJSON(rw, http.StatusUnauthorized, map[string]interface{}{
			"success": false,
			"error":   "WebAuthn verification failed",
		})
		return
	}

	// Get username from stored credential or use placeholder
	username := session.GetString("webauthn.credential_user")
	if username == "" {
		username = "user@example.com"
	}

	sessionID := generateSessionID()
	loginTime := time.Now().Format(time.RFC3339)
	
	session.SetString("webauthn.authenticated", "true")
	session.SetString("webauthn.quick_auth", "true")
	session.SetString("webauthn.username", username)
	session.SetString("session_id", sessionID)
	session.SetString("login_time", loginTime)
	session.SetString("webauthn.challenge", "")

	if err := session.Save(); err != nil {
		respondWithJSON(rw, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"error":   "Session save error",
		})
		return
	}

	logger.Debug("se", "User authenticated via quick passkey", "username", username)
	respondWithJSON(rw, http.StatusOK, map[string]interface{}{
		"success":    true,
		"username":   username,
		"session_id": sessionID,
		"login_time": loginTime,
	})
}

// handleSessionCheck checks if user has an active session
func handleSessionCheck(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	session, err := api.Session()
	if err != nil {
		respondWithJSON(rw, http.StatusOK, map[string]interface{}{"valid": false})
		return
	}

	entraAuth := session.GetString("entra.authenticated")
	webauthnAuth := session.GetString("webauthn.authenticated")
	quickAuth := session.GetString("webauthn.quick_auth")
	
	isValid := (entraAuth == "true" && webauthnAuth == "true") || 
	          (webauthnAuth == "true" && quickAuth == "true")
	
	if isValid {
		username := session.GetString("entra.username")
		if username == "" {
			username = session.GetString("webauthn.username")
		}
		
		respondWithJSON(rw, http.StatusOK, map[string]interface{}{
			"valid":        true,
			"mfa_verified": true,
			"username":     username,
			"session_id":   session.GetString("session_id"),
			"login_time":   session.GetString("login_time"),
		})
	} else {
		respondWithJSON(rw, http.StatusOK, map[string]interface{}{"valid": false})
	}
}

// handleLogout handles user logout
func handleLogout(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	logger.Debug("se", "processing logout")
	
	session, err := api.Session()
	if err == nil {
		// Clear all session data
		session.SetString("entra.authenticated", "")
		session.SetString("entra.username", "")
		session.SetString("entra.token", "")
		session.SetString("entra.temp_auth", "")
		session.SetString("entra.temp_session", "")
		session.SetString("webauthn.authenticated", "")
		session.SetString("webauthn.username", "")
		session.SetString("webauthn.quick_auth", "")
		session.SetString("webauthn.challenge", "")
		session.SetString("webauthn.challenge_type", "")
		session.SetString("webauthn.challenge_expires", "")
		session.SetString("webauthn.credential_id", "")
		session.SetString("webauthn.credential_user", "")
		session.SetString("session_id", "")
		session.SetString("login_time", "")
		session.SetString("user.email", "")
		session.SetString("auth.provider", "")
		session.Save()
	}
	
	respondWithJSON(rw, http.StatusOK, map[string]interface{}{"success": true})
}

// authenticateWithEntra performs Entra authentication
func authenticateWithEntra(api orchestrator.Orchestrator, username, password string) (string, error) {
	logger := api.Logger()
	logger.Debug("se", "authenticating with Entra", "username", username)

	// Demo mode for testing
	if username == "demo@example.com" || username == "user@example.com" {
		logger.Debug("se", "Using demo mode authentication")
		return "demo_token_" + username, nil
	}

	secretProvider, err := api.SecretProvider()
	if err != nil {
		logger.Debug("se", "No secret provider, using demo mode")
		return "demo_token_" + username, nil
	}

	clientID := secretProvider.GetString("AZURE_CLIENT_ID")
	clientSecret := secretProvider.GetString("AZURE_CLIENT_SECRET")
	tenantID := secretProvider.GetString("AZURE_TENANT_ID")

	if clientID == "" || clientSecret == "" || tenantID == "" {
		logger.Debug("se", "Entra not configured, using demo mode")
		return "demo_token_" + username, nil
	}

	tokenURL := fmt.Sprintf("https://login.microsoftonline.com/%s/oauth2/v2.0/token", tenantID)
	data := url.Values{}
	data.Set("grant_type", "password")
	data.Set("client_id", clientID)
	data.Set("client_secret", clientSecret)
	data.Set("username", username)
	data.Set("password", password)
	data.Set("scope", "https://graph.microsoft.com/.default")

	req, err := http.NewRequest("POST", tokenURL, strings.NewReader(data.Encode()))
	if err != nil {
		return "", err
	}
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")

	client := &http.Client{
		Timeout: 30 * time.Second,
		Transport: &http.Transport{
			TLSClientConfig: &tls.Config{InsecureSkipVerify: false},
		},
	}
	
	resp, err := client.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", err
	}

	if resp.StatusCode != http.StatusOK {
		return "", fmt.Errorf("authentication failed: %s", string(body))
	}

	var tokenResp EntraAuthResponse
	if err := json.Unmarshal(body, &tokenResp); err != nil {
		return "", err
	}

	return tokenResp.AccessToken, nil
}

// generateWebAuthnChallenge creates a cryptographically secure challenge
func generateWebAuthnChallenge() string {
	b := make([]byte, 32)
	_, err := rand.Read(b)
	if err != nil {
		return fmt.Sprintf("challenge_%d", time.Now().UnixNano())
	}
	return base64.URLEncoding.EncodeToString(b)
}

// verifyWebAuthnAuthentication verifies the WebAuthn authentication response
func verifyWebAuthnAuthentication(authentication interface{}, storedChallenge string) bool {
	// Basic validation for demo
	// In production, use proper WebAuthn server-side verification
	if authentication == nil || storedChallenge == "" {
		return false
	}

	authMap, ok := authentication.(map[string]interface{})
	if !ok {
		return false
	}

	// Check basic WebAuthn fields
	_, hasId := authMap["id"]
	_, hasRawId := authMap["rawId"]
	_, hasResponse := authMap["response"]
	_, hasType := authMap["type"]

	return hasId && hasRawId && hasResponse && hasType
}

// generateSessionID creates a unique session ID
func generateSessionID() string {
	b := make([]byte, 16)
	_, err := rand.Read(b)
	if err != nil {
		return fmt.Sprintf("sess_%d", time.Now().UnixNano())
	}
	return fmt.Sprintf("sess_%s", base64.URLEncoding.EncodeToString(b))
}

// respondWithJSON sends a JSON response
func respondWithJSON(w http.ResponseWriter, statusCode int, response interface{}) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(statusCode)
	json.NewEncoder(w).Encode(response)
}

// LoadAttributes loads user attributes
func LoadAttributes(api orchestrator.Orchestrator, _ http.ResponseWriter, _ *http.Request) error {
	logger := api.Logger()
	logger.Debug("se", "loading attributes")

	session, err := api.Session()
	if err != nil {
		return err
	}

	username := session.GetString("entra.username")
	if username == "" {
		username = session.GetString("webauthn.username")
	}
	
	if username == "" {
		return fmt.Errorf("no username in session")
	}

	session.SetString("user.email", username)
	session.SetString("auth.provider", "entra-webauthn")
	return session.Save()
}

// BuildAccessTokenClaims creates access token claims
func BuildAccessTokenClaims(api orchestrator.Orchestrator, _ *http.Request) (map[string]any, error) {
	session, err := api.Session()
	if err != nil {
		return nil, err
	}

	username := session.GetString("entra.username")
	if username == "" {
		username = session.GetString("webauthn.username")
	}
	
	return map[string]any{
		"sub":   username,
		"email": username,
		"iss":   "strata-entra-webauthn",
		"aud":   "application",
		"amr":   []string{"pwd", "mfa", "wia"},
	}, nil
}

// BuildIDTokenClaims creates ID token claims
func BuildIDTokenClaims(api orchestrator.Orchestrator, _ *http.Request) (map[string]any, error) {
	session, err := api.Session()
	if err != nil {
		return nil, err
	}

	username := session.GetString("entra.username")
	if username == "" {
		username = session.GetString("webauthn.username")
	}
	
	authMethod := "entra-webauthn"
	if session.GetString("webauthn.quick_auth") == "true" {
		authMethod = "webauthn-quick"
	}
	
	return map[string]any{
		"sub":      username,
		"email":    username,
		"provider": authMethod,
		"iss":      "strata-entra-webauthn",
		"aud":      "application",
		"amr":      []string{"pwd", "mfa", "wia"},
	}, nil
}