package main

import (
	"crypto/rand"
	"crypto/tls"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"

	"github.com/strata-io/service-extension/orchestrator"
)

// Microsoft Entra authentication response
type EntraAuthResponse struct {
	AccessToken string `json:"access_token"`
	TokenType   string `json:"token_type"`
	ExpiresIn   int    `json:"expires_in"`
}

// WebAuthn registration/authentication structures
type WebAuthnChallenge struct {
	Challenge string `json:"challenge"`
	UserID    string `json:"userId"`
	Username  string `json:"username"`
	ExpiresAt int64  `json:"expiresAt"`
}

type WebAuthnCredential struct {
	ID        string `json:"id"`
	PublicKey string `json:"publicKey"`
	Algorithm string `json:"algorithm"`
	UserID    string `json:"userId"`
	Username  string `json:"username"`
	CreatedAt int64  `json:"createdAt"`
}

// Login page HTML template with WebAuthn integration
const loginPageHTML = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enterprise Login with Passkeys</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; display: flex; align-items: center; justify-content: center; }
        .container { background: rgba(255, 255, 255, 0.95); padding: 2.5rem; border-radius: 16px; box-shadow: 0 20px 60px rgba(0, 0, 0, 0.15); width: 100%; max-width: 420px; backdrop-filter: blur(10px); }
        .login-form { display: block; }
        .mfa-form { display: none; }
        .dashboard { display: none; text-align: center; }
        h1 { color: #333; margin-bottom: 1.5rem; text-align: center; font-weight: 600; }
        .form-group { margin-bottom: 1.25rem; }
        label { display: block; margin-bottom: 0.5rem; color: #555; font-weight: 500; font-size: 0.95rem; }
        input[type="text"], input[type="password"] { width: 100%; padding: 0.85rem; border: 2px solid #e1e8ed; border-radius: 8px; font-size: 1rem; transition: all 0.3s ease; }
        input[type="text"]:focus, input[type="password"]:focus { outline: none; border-color: #667eea; box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1); }
        .btn { width: 100%; padding: 0.85rem; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border: none; border-radius: 8px; font-size: 1rem; font-weight: 500; cursor: pointer; margin-top: 1rem; transition: all 0.3s ease; }
        .btn:hover { transform: translateY(-2px); box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3); }
        .btn-passkey { background: linear-gradient(135deg, #00b4d8 0%, #0077be 100%); margin-bottom: 0.5rem; display: flex; align-items: center; justify-content: center; gap: 0.5rem; }
        .btn-passkey:hover { box-shadow: 0 5px 15px rgba(0, 119, 190, 0.3); }
        .btn-back { background: linear-gradient(135deg, #6c757d 0%, #495057 100%); }
        .btn-logout { background: linear-gradient(135deg, #f44336 0%, #d32f2f 100%); width: auto; padding: 0.6rem 1.5rem; margin-top: 1rem; }
        .error { color: #f44336; margin-top: 0.5rem; font-size: 0.9rem; background: rgba(244, 67, 54, 0.1); padding: 0.5rem; border-radius: 4px; display: none; }
        .success { color: #4CAF50; margin-top: 0.5rem; font-size: 0.9rem; background: rgba(76, 175, 80, 0.1); padding: 0.5rem; border-radius: 4px; display: none; }
        .demo-info { background: linear-gradient(135deg, #e7f3ff 0%, #f0f8ff 100%); padding: 1rem; border-radius: 8px; margin-bottom: 1rem; font-size: 0.9rem; color: #333; border: 1px solid #b3d9ff; }
        .loading { display: none; text-align: center; margin-top: 1rem; }
        .spinner { border: 3px solid rgba(102, 126, 234, 0.2); border-top: 3px solid #667eea; border-radius: 50%; width: 30px; height: 30px; animation: spin 1s linear infinite; margin: 0 auto; }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
        .step-indicator { text-align: center; color: #666; font-size: 0.9rem; margin-bottom: 1rem; padding: 0.75rem; background: #f8f9fa; border-radius: 8px; }
        .welcome-message { color: #667eea; font-size: 1.3rem; margin-bottom: 1rem; font-weight: 500; }
        .dashboard-content { margin: 2rem 0; }
        .feature-box { background: linear-gradient(135deg, #f8f9fa 0%, #ffffff 100%); padding: 1.25rem; margin: 1rem 0; border-radius: 8px; text-align: left; border: 1px solid #e9ecef; transition: all 0.3s ease; cursor: pointer; }
        .feature-box:hover { transform: translateY(-2px); box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1); }
        .feature-box h3 { color: #333; margin-bottom: 0.5rem; font-weight: 500; }
        .user-info { background: linear-gradient(135deg, #e8f5e8 0%, #f1f8f1 100%); padding: 1.25rem; border-radius: 8px; margin-bottom: 1rem; border: 1px solid #c3e6c3; }
        .current-time { font-size: 0.9rem; color: #666; margin-top: 1rem; }
        .passkey-icon { width: 20px; height: 20px; fill: currentColor; }
        .divider { margin: 1.5rem 0; text-align: center; color: #999; position: relative; }
        .divider::before { content: ''; position: absolute; left: 0; top: 50%; width: 100%; height: 1px; background: #e1e8ed; }
        .divider span { background: rgba(255, 255, 255, 0.95); padding: 0 1rem; position: relative; font-size: 0.85rem; }
        .register-section { margin-top: 1rem; padding-top: 1rem; border-top: 1px solid #e1e8ed; text-align: center; }
        .register-link { color: #667eea; text-decoration: none; font-weight: 500; }
        .register-link:hover { text-decoration: underline; }
    </style>
</head>
<body>
    <div class="container">
        <div id="loginForm" class="login-form">
            <h1>🔐 Secure Login</h1>
            <div class="demo-info">
                <strong>Enterprise Authentication:</strong><br>
                Microsoft Entra ID + WebAuthn Passkeys<br>
                Use your passkey for passwordless authentication
            </div>
            
            <!-- Quick passkey authentication -->
            <button id="quickAuthBtn" class="btn btn-passkey">
                <svg class="passkey-icon" viewBox="0 0 24 24"><path d="M7 14C5.9 14 5 13.1 5 12S5.9 10 7 10 9 10.9 9 12 8.1 14 7 14M12.6 10C11.8 7.7 9.6 6 7 6C3.7 6 1 8.7 1 12S3.7 18 7 18C9.6 18 11.8 16.3 12.6 14H16V18H20V14H23V10H12.6Z"/></svg>
                Sign in with Passkey
            </button>
            
            <div class="divider"><span>OR</span></div>
            
            <form id="loginFormElement">
                <div class="form-group">
                    <label for="username">Username:</label>
                    <input type="text" id="username" name="username" placeholder="Enter your email" required>
                </div>
                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" id="password" name="password" placeholder="Enter your password" required>
                </div>
                <button type="submit" class="btn">Login with Password</button>
            </form>
            
            <div class="register-section">
                <small>Don't have a passkey? <a href="#" id="registerPasskeyLink" class="register-link">Register one now</a></small>
            </div>
            
            <div class="loading" id="loading"><div class="spinner"></div></div>
            <div id="errorMessage" class="error"></div>
            <div id="successMessage" class="success"></div>
        </div>
        
        <div id="mfaForm" class="mfa-form">
            <h1>🔑 Passkey Authentication</h1>
            <div class="step-indicator">Step 2 of 2: Verify your identity</div>
            <div class="demo-info">
                <strong>WebAuthn Passkey Required:</strong><br>
                Use your registered passkey to complete authentication<br>
                Your device will prompt you for biometric or PIN verification
            </div>
            <div class="form-group">
                <label for="mfaUser">User:</label>
                <input type="text" id="mfaUser" readonly style="background-color: #f8f9fa;">
            </div>
            <button id="webauthnAuthBtn" class="btn btn-passkey">
                <svg class="passkey-icon" viewBox="0 0 24 24"><path d="M7 14C5.9 14 5 13.1 5 12S5.9 10 7 10 9 10.9 9 12 8.1 14 7 14M12.6 10C11.8 7.7 9.6 6 7 6C3.7 6 1 8.7 1 12S3.7 18 7 18C9.6 18 11.8 16.3 12.6 14H16V18H20V14H23V10H12.6Z"/></svg>
                Authenticate with Passkey
            </button>
            <button id="webauthnRegisterBtn" class="btn" style="background: linear-gradient(135deg, #4CAF50 0%, #45a049 100%);">
                Register New Passkey
            </button>
            <button id="backToLoginBtn" class="btn btn-back">Back to Login</button>
            <div class="loading" id="mfaLoading"><div class="spinner"></div></div>
            <div id="mfaErrorMessage" class="error"></div>
            <div id="mfaSuccessMessage" class="success"></div>
        </div>
        
        <div id="dashboard" class="dashboard">
            <h1>🎉 Dashboard</h1>
            <div class="welcome-message">Welcome back, <span id="welcomeUser"></span>!</div>
            <div class="user-info">
                <strong>User Information:</strong><br>
                Username: <span id="userInfoName"></span><br>
                Login Time: <span id="loginTime"></span><br>
                Session ID: <span id="sessionId"></span><br>
                Authentication: Microsoft Entra + WebAuthn Passkey
            </div>
            <div class="dashboard-content">
                <div class="feature-box">
                    <h3>📊 Analytics</h3>
                    <p>View your application analytics and reports here.</p>
                </div>
                <div class="feature-box">
                    <h3>⚙️ Settings</h3>
                    <p>Manage your account settings and preferences.</p>
                </div>
                <div class="feature-box">
                    <h3>💬 Messages</h3>
                    <p>Check your messages and notifications.</p>
                </div>
                <div class="feature-box">
                    <h3>👥 Users</h3>
                    <p>Manage users and permissions in your system.</p>
                </div>
            </div>
            <div class="current-time">Current Time: <span id="currentTime"></span></div>
            <button id="logoutBtn" class="btn btn-logout">Logout</button>
        </div>
    </div>
    
    <!-- Import WebAuthn library from CDN -->
    <script type="module">
        import {client} from 'https://cdn.jsdelivr.net/npm/@passwordless-id/webauthn@2.0.0/dist/webauthn.min.js';
        
        // Make client available globally
        window.webauthnClient = client;
        
        const loginForm = document.getElementById('loginForm');
        const mfaForm = document.getElementById('mfaForm');
        const dashboard = document.getElementById('dashboard');
        const loginFormElement = document.getElementById('loginFormElement');
        const usernameInput = document.getElementById('username');
        const passwordInput = document.getElementById('password');
        const mfaUser = document.getElementById('mfaUser');
        const errorMessage = document.getElementById('errorMessage');
        const successMessage = document.getElementById('successMessage');
        const mfaErrorMessage = document.getElementById('mfaErrorMessage');
        const mfaSuccessMessage = document.getElementById('mfaSuccessMessage');
        const loading = document.getElementById('loading');
        const mfaLoading = document.getElementById('mfaLoading');
        const webauthnAuthBtn = document.getElementById('webauthnAuthBtn');
        const webauthnRegisterBtn = document.getElementById('webauthnRegisterBtn');
        const quickAuthBtn = document.getElementById('quickAuthBtn');
        const registerPasskeyLink = document.getElementById('registerPasskeyLink');
        const backToLoginBtn = document.getElementById('backToLoginBtn');
        const logoutBtn = document.getElementById('logoutBtn');
        const welcomeUser = document.getElementById('welcomeUser');
        const userInfoName = document.getElementById('userInfoName');
        const loginTimeEl = document.getElementById('loginTime');
        const sessionIdEl = document.getElementById('sessionId');
        const currentTime = document.getElementById('currentTime');

        let currentUser = null, currentSessionId = null, tempAuthData = null;

        function showError(message, isMfa = false) {
            const errorEl = isMfa ? mfaErrorMessage : errorMessage;
            const successEl = isMfa ? mfaSuccessMessage : successMessage;
            const loadingEl = isMfa ? mfaLoading : loading;
            errorEl.textContent = message;
            errorEl.style.display = 'block';
            successEl.style.display = 'none';
            loadingEl.style.display = 'none';
            setTimeout(() => {
                errorEl.style.display = 'none';
                errorEl.textContent = '';
            }, 5000);
        }

        function showSuccess(message, isMfa = false) {
            const errorEl = isMfa ? mfaErrorMessage : errorMessage;
            const successEl = isMfa ? mfaSuccessMessage : successMessage;
            const loadingEl = isMfa ? mfaLoading : loading;
            successEl.textContent = message;
            successEl.style.display = 'block';
            errorEl.style.display = 'none';
            loadingEl.style.display = 'none';
            setTimeout(() => {
                successEl.style.display = 'none';
                successEl.textContent = '';
            }, 3000);
        }

        function showLoading(isMfa = false) {
            const loadingEl = isMfa ? mfaLoading : loading;
            const errorEl = isMfa ? mfaErrorMessage : errorMessage;
            const successEl = isMfa ? mfaSuccessMessage : successMessage;
            loadingEl.style.display = 'block';
            errorEl.style.display = 'none';
            successEl.style.display = 'none';
        }

        function showMfaForm(username) {
            loginForm.style.display = 'none';
            mfaForm.style.display = 'block';
            dashboard.style.display = 'none';
            mfaUser.value = username;
        }

        function showDashboard(username, sessionId, loginTime) {
            loginForm.style.display = 'none';
            mfaForm.style.display = 'none';
            dashboard.style.display = 'block';
            welcomeUser.textContent = username;
            userInfoName.textContent = username;
            loginTimeEl.textContent = new Date(loginTime).toLocaleString();
            sessionIdEl.textContent = sessionId;
            updateCurrentTime();
            setInterval(updateCurrentTime, 1000);
        }

        function showLoginForm() {
            loginForm.style.display = 'block';
            mfaForm.style.display = 'none';
            dashboard.style.display = 'none';
            usernameInput.value = '';
            passwordInput.value = '';
            mfaUser.value = '';
            [errorMessage, successMessage, mfaErrorMessage, mfaSuccessMessage].forEach(el => {
                el.textContent = '';
                el.style.display = 'none';
            });
            [loading, mfaLoading].forEach(el => el.style.display = 'none');
            tempAuthData = null;
        }

        function updateCurrentTime() {
            currentTime.textContent = new Date().toLocaleString();
        }

        // Quick authentication with passkey (no username/password needed)
        quickAuthBtn.addEventListener('click', async function() {
            showLoading();
            try {
                // Get challenge from server
                const challengeResp = await fetch('/webauthn/challenge', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    credentials: 'include',
                    body: JSON.stringify({ type: 'authenticate' })
                });
                const challengeData = await challengeResp.json();
                
                if (!challengeData.success) {
                    showError(challengeData.error || 'Failed to get challenge');
                    return;
                }
                
                // Perform WebAuthn authentication
                const authentication = await window.webauthnClient.authenticate({
                    challenge: challengeData.challenge,
                    allowCredentials: [],
                    userVerification: 'preferred'
                });
                
                // Send authentication to server
                const verifyResp = await fetch('/webauthn/verify-quick', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    credentials: 'include',
                    body: JSON.stringify({
                        authentication: authentication,
                        challenge: challengeData.challenge
                    })
                });
                
                const verifyData = await verifyResp.json();
                if (verifyData.success) {
                    showSuccess('Authentication successful!');
                    setTimeout(() => showDashboard(verifyData.username, verifyData.session_id, verifyData.login_time), 1000);
                } else {
                    showError(verifyData.error || 'Authentication failed');
                }
            } catch (error) {
                console.error('WebAuthn error:', error);
                showError('Authentication failed: ' + error.message);
            }
        });

        // Traditional login with username/password
        loginFormElement.addEventListener('submit', async function(e) {
            e.preventDefault();
            const username = usernameInput.value.trim();
            const password = passwordInput.value;
            
            if (!username || !password) {
                showError('Please enter both username and password');
                return;
            }
            
            showLoading();
            try {
                const response = await fetch('/auth', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    credentials: 'include',
                    body: JSON.stringify({ username, password, step: 'entra' })
                });
                
                const data = await response.json();
                if (data.success) {
                    tempAuthData = data;
                    showSuccess('Authentication successful! Proceeding to passkey verification...');
                    setTimeout(() => showMfaForm(data.username), 1000);
                } else {
                    showError(data.error || 'Authentication failed');
                }
            } catch (error) {
                showError('Network error. Please try again.');
            }
        });

        // WebAuthn authentication after Entra login
        webauthnAuthBtn.addEventListener('click', async function() {
            if (!tempAuthData) {
                showError('Session expired. Please start over.', true);
                showLoginForm();
                return;
            }
            
            showLoading(true);
            try {
                // Get challenge from server
                const challengeResp = await fetch('/webauthn/challenge', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    credentials: 'include',
                    body: JSON.stringify({
                        type: 'authenticate',
                        username: tempAuthData.username,
                        temp_session: tempAuthData.temp_session
                    })
                });
                
                const challengeData = await challengeResp.json();
                if (!challengeData.success) {
                    showError(challengeData.error || 'Failed to get challenge', true);
                    return;
                }
                
                // Perform WebAuthn authentication
                const authentication = await window.webauthnClient.authenticate({
                    challenge: challengeData.challenge,
                    allowCredentials: challengeData.allowCredentials || [],
                    userVerification: 'preferred'
                });
                
                // Verify with server
                const verifyResp = await fetch('/webauthn/verify', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    credentials: 'include',
                    body: JSON.stringify({
                        username: tempAuthData.username,
                        temp_session: tempAuthData.temp_session,
                        authentication: authentication,
                        challenge: challengeData.challenge
                    })
                });
                
                const verifyData = await verifyResp.json();
                if (verifyData.success) {
                    currentUser = verifyData.username;
                    currentSessionId = verifyData.session_id;
                    showSuccess('Passkey verification successful!', true);
                    setTimeout(() => showDashboard(verifyData.username, verifyData.session_id, verifyData.login_time), 1000);
                } else {
                    showError(verifyData.error || 'Passkey verification failed', true);
                }
            } catch (error) {
                console.error('WebAuthn error:', error);
                showError('Passkey authentication failed: ' + error.message, true);
            }
        });

        // Register new passkey
        webauthnRegisterBtn.addEventListener('click', async function() {
            if (!tempAuthData) {
                showError('Session expired. Please start over.', true);
                showLoginForm();
                return;
            }
            
            showLoading(true);
            try {
                // Get registration challenge
                const challengeResp = await fetch('/webauthn/challenge', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    credentials: 'include',
                    body: JSON.stringify({
                        type: 'register',
                        username: tempAuthData.username,
                        temp_session: tempAuthData.temp_session
                    })
                });
                
                const challengeData = await challengeResp.json();
                if (!challengeData.success) {
                    showError(challengeData.error || 'Failed to get challenge', true);
                    return;
                }
                
                // Perform WebAuthn registration
                const registration = await window.webauthnClient.register({
                    challenge: challengeData.challenge,
                    user: tempAuthData.username,
                    authenticatorSelection: {
                        authenticatorAttachment: 'platform',
                        userVerification: 'required'
                    }
                });
                
                // Send registration to server
                const registerResp = await fetch('/webauthn/register', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    credentials: 'include',
                    body: JSON.stringify({
                        username: tempAuthData.username,
                        temp_session: tempAuthData.temp_session,
                        registration: registration,
                        challenge: challengeData.challenge
                    })
                });
                
                const registerData = await registerResp.json();
                if (registerData.success) {
                    showSuccess('Passkey registered successfully! Now authenticate with it.', true);
                } else {
                    showError(registerData.error || 'Registration failed', true);
                }
            } catch (error) {
                console.error('WebAuthn registration error:', error);
                showError('Passkey registration failed: ' + error.message, true);
            }
        });

        // Register passkey from login page
        registerPasskeyLink.addEventListener('click', async function(e) {
            e.preventDefault();
            const username = prompt('Enter your username/email to register a passkey:');
            if (!username) return;
            
            showLoading();
            try {
                // First authenticate with username only to get a temp session
                const authResp = await fetch('/auth/username-only', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    credentials: 'include',
                    body: JSON.stringify({ username })
                });
                
                const authData = await authResp.json();
                if (authData.success) {
                    tempAuthData = authData;
                    showSuccess('Proceeding to passkey registration...');
                    showMfaForm(username);
                } else {
                    showError(authData.error || 'Failed to initialize registration');
                }
            } catch (error) {
                showError('Registration initialization failed');
            }
        });

        backToLoginBtn.addEventListener('click', () => showLoginForm());
        
        logoutBtn.addEventListener('click', async function() {
            try {
                await fetch('/logout', { method: 'POST', credentials: 'include' });
            } catch (e) {}
            showLoginForm();
        });

        // Check existing session
        async function checkExistingSession() {
            try {
                const r = await fetch('/session', { credentials: 'include' });
                const d = await r.json();
                if (d.valid && d.mfa_verified) {
                    showDashboard(d.username, d.session_id, d.login_time);
                }
            } catch (e) {}
        }
        
        checkExistingSession();
        usernameInput.focus();
    </script>
</body>
</html>`

// IsAuthenticated checks if the current session is authenticated by both Microsoft Entra and WebAuthn
func IsAuthenticated(api orchestrator.Orchestrator, _ http.ResponseWriter, _ *http.Request) bool {
	logger := api.Logger()
	logger.Debug("se", "determining if user is authenticated")

	session, err := api.Session()
	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		return false
	}

	// Check both Entra and WebAuthn authentication
	entraAuth := session.GetString("entra.authenticated")
	webauthnAuth := session.GetString("webauthn.authenticated")

	if entraAuth == "true" && webauthnAuth == "true" {
		logger.Debug("se", "user is fully authenticated")
		return true
	}

	// Also check for quick WebAuthn authentication (no Entra)
	if webauthnAuth == "true" && session.GetString("webauthn.quick_auth") == "true" {
		logger.Debug("se", "user authenticated via quick passkey")
		return true
	}

	logger.Debug("se", "user is not fully authenticated")
	return false
}

// Authenticate serves the login page and handles authentication requests
func Authenticate(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	logger.Debug("se", "handling authentication request", "path", req.URL.Path)

	switch req.URL.Path {
	case "/auth":
		if req.Method == "POST" {
			handleEntraAuth(api, rw, req)
			return
		}
	case "/auth/username-only":
		if req.Method == "POST" {
			handleUsernameOnlyAuth(api, rw, req)
			return
		}
	case "/webauthn/challenge":
		if req.Method == "POST" {
			handleWebAuthnChallenge(api, rw, req)
			return
		}
	case "/webauthn/register":
		if req.Method == "POST" {
			handleWebAuthnRegister(api, rw, req)
			return
		}
	case "/webauthn/verify":
		if req.Method == "POST" {
			handleWebAuthnVerify(api, rw, req)
			return
		}
	case "/webauthn/verify-quick":
		if req.Method == "POST" {
			handleWebAuthnQuickVerify(api, rw, req)
			return
		}
	case "/session":
		if req.Method == "GET" {
			handleSessionCheck(api, rw, req)
			return
		}
	case "/logout":
		if req.Method == "POST" {
			handleLogout(api, rw, req)
			return
		}
	}

	// Serve login page
	rw.Header().Set("Content-Type", "text/html; charset=utf-8")
	rw.WriteHeader(http.StatusOK)
	rw.Write([]byte(loginPageHTML))
}

// handleEntraAuth processes Microsoft Entra authentication
func handleEntraAuth(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	logger.Debug("se", "processing Entra authentication")

	var authReq struct {
		Username string `json:"username"`
		Password string `json:"password"`
		Step     string `json:"step"`
	}

	if err := json.NewDecoder(req.Body).Decode(&authReq); err != nil {
		respondWithJSON(rw, http.StatusBadRequest, map[string]interface{}{
			"success": false,
			"error":   "Invalid request",
		})
		return
	}

	if authReq.Username == "" || authReq.Password == "" {
		respondWithJSON(rw, http.StatusBadRequest, map[string]interface{}{
			"success": false,
			"error":   "Username and password required",
		})
		return
	}

	// Authenticate with Entra
	accessToken, err := authenticateWithEntra(api, authReq.Username, authReq.Password)
	if err != nil {
		logger.Error("se", "Entra auth failed", "error", err.Error())
		respondWithJSON(rw, http.StatusUnauthorized, map[string]interface{}{
			"success": false,
			"error":   "Invalid credentials",
		})
		return
	}

	// Store temporary session data
	session, err := api.Session()
	if err != nil {
		respondWithJSON(rw, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"error":   "Session error",
		})
		return
	}

	session.SetString("entra.temp_auth", "true")
	session.SetString("entra.username", authReq.Username)
	session.SetString("entra.token", accessToken)
	tempSession := generateSessionID()
	session.SetString("entra.temp_session", tempSession)

	if err := session.Save(); err != nil {
		respondWithJSON(rw, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"error":   "Session save error",
		})
		return
	}

	respondWithJSON(rw, http.StatusOK, map[string]interface{}{
		"success":      true,
		"username":     authReq.Username,
		"temp_session": tempSession,
		"requires_mfa": true,
	})
}

// handleUsernameOnlyAuth handles username-only auth for passkey registration
func handleUsernameOnlyAuth(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	var authReq struct {
		Username string `json:"username"`
	}

	if err := json.NewDecoder(req.Body).Decode(&authReq); err != nil {
		respondWithJSON(rw, http.StatusBadRequest, map[string]interface{}{
			"success": false,
			"error":   "Invalid request",
		})
		return
	}

	if authReq.Username == "" {
		respondWithJSON(rw, http.StatusBadRequest, map[string]interface{}{
			"success": false,
			"error":   "Username required",
		})
		return
	}

	// Create temporary session for registration
	session, err := api.Session()
	if err != nil {
		respondWithJSON(rw, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"error":   "Session error",
		})
		return
	}

	tempSession := generateSessionID()
	session.SetString("entra.temp_auth", "true")
	session.SetString("entra.username", authReq.Username)
	session.SetString("entra.temp_session", tempSession)

	if err := session.Save(); err != nil {
		respondWithJSON(rw, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"error":   "Session save error",
		})
		return
	}

	respondWithJSON(rw, http.StatusOK, map[string]interface{}{
		"success":      true,
		"username":     authReq.Username,
		"temp_session": tempSession,
	})
}

// handleWebAuthnChallenge generates a WebAuthn challenge
func handleWebAuthnChallenge(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	
	var challengeReq struct {
		Type        string `json:"type"` // "register" or "authenticate"
		Username    string `json:"username"`
		TempSession string `json:"temp_session"`
	}

	if err := json.NewDecoder(req.Body).Decode(&challengeReq); err != nil {
		respondWithJSON(rw, http.StatusBadRequest, map[string]interface{}{
			"success": false,
			"error":   "Invalid request",
		})
		return
	}

	// Generate challenge
	challenge := generateWebAuthnChallenge()
	
	// Store challenge in session
	session, err := api.Session()
	if err != nil {
		respondWithJSON(rw, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"error":   "Session error",
		})
		return
	}

	session.SetString("webauthn.challenge", challenge)
	session.SetString("webauthn.challenge_type", challengeReq.Type)
	session.SetInt64("webauthn.challenge_expires", time.Now().Add(5*time.Minute).Unix())
	
	if err := session.Save(); err != nil {
		respondWithJSON(rw, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"error":   "Session save error",
		})
		return
	}

	response := map[string]interface{}{
		"success":   true,
		"challenge": challenge,
	}

	// For authentication, include allowed credentials if available
	if challengeReq.Type == "authenticate" && challengeReq.Username != "" {
		// In production, fetch user's registered credentials from database
		// For now, we'll return empty array to allow any credential
		response["allowCredentials"] = []interface{}{}
	}

	logger.Debug("se", "WebAuthn challenge generated", "type", challengeReq.Type)
	respondWithJSON(rw, http.StatusOK, response)
}

// handleWebAuthnRegister handles WebAuthn registration
func handleWebAuthnRegister(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	
	var registerReq struct {
		Username     string                 `json:"username"`
		TempSession  string                 `json:"temp_session"`
		Registration map[string]interface{} `json:"registration"`
		Challenge    string                 `json:"challenge"`
	}

	if err := json.NewDecoder(req.Body).Decode(&registerReq); err != nil {
		respondWithJSON(rw, http.StatusBadRequest, map[string]interface{}{
			"success": false,
			"error":   "Invalid request",
		})
		return
	}

	// Validate session
	session, err := api.Session()
	if err != nil {
		respondWithJSON(rw, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"error":   "Session error",
		})
		return
	}

	storedChallenge := session.GetString("webauthn.challenge")
	if storedChallenge != registerReq.Challenge {
		respondWithJSON(rw, http.StatusUnauthorized, map[string]interface{}{
			"success": false,
			"error":   "Invalid challenge",
		})
		return
	}

	// In production, you would:
	// 1. Verify the registration response using the WebAuthn server library
	// 2. Store the credential ID and public key in database
	// 3. Associate with the user account
	
	// For demo, we'll store in session (not recommended for production)
	if registerReq.Registration["id"] != nil {
		credentialID := registerReq.Registration["id"].(string)
		session.SetString("webauthn.credential_id", credentialID)
		session.SetString("webauthn.credential_user", registerReq.Username)
		
		if err := session.Save(); err != nil {
			respondWithJSON(rw, http.StatusInternalServerError, map[string]interface{}{
				"success": false,
				"error":   "Failed to save credential",
			})
			return
		}
		
		logger.Debug("se", "WebAuthn credential registered", "username", registerReq.Username)
		respondWithJSON(rw, http.StatusOK, map[string]interface{}{
			"success": true,
			"message": "Passkey registered successfully",
		})
	} else {
		respondWithJSON(rw, http.StatusBadRequest, map[string]interface{}{
			"success": false,
			"error":   "Invalid registration data",
		})
	}
}

// handleWebAuthnVerify handles WebAuthn verification after Entra auth
func handleWebAuthnVerify(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	
	var verifyReq struct {
		Username       string                 `json:"username"`
		TempSession    string                 `json:"temp_session"`
		Authentication map[string]interface{} `json:"authentication"`
		Challenge      string                 `json:"challenge"`
	}

	if err := json.NewDecoder(req.Body).Decode(&verifyReq); err != nil {
		respondWithJSON(rw, http.StatusBadRequest, map[string]interface{}{
			"success": false,
			"error":   "Invalid request",
		})
		return
	}

	// Validate session
	session, err := api.Session()
	if err != nil {
		respondWithJSON(rw, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"error":   "Session error",
		})
		return
	}

	tempAuth := session.GetString("entra.temp_auth")
	tempSession := session.GetString("entra.temp_session")
	username := session.GetString("entra.username")
	storedChallenge := session.GetString("webauthn.challenge")

	if tempAuth != "true" || tempSession != verifyReq.TempSession || 
	   username != verifyReq.Username || storedChallenge != verifyReq.Challenge {
		respondWithJSON(rw, http.StatusUnauthorized, map[string]interface{}{
			"success": false,
			"error":   "Invalid session or challenge",
		})
		return
	}

	// In production, verify the authentication response using WebAuthn server library
	// For demo, we'll do basic validation
	if !verifyWebAuthnAuthentication(verifyReq.Authentication, storedChallenge) {
		respondWithJSON(rw, http.StatusUnauthorized, map[string]interface{}{
			"success": false,
			"error":   "WebAuthn verification failed",
		})
		return
	}

	// Set final authentication state
	session.SetString("entra.authenticated", "true")
	session.SetString("webauthn.authenticated", "true")
	sessionID := generateSessionID()
	session.SetString("session_id", sessionID)
	loginTime := time.Now().Format(time.RFC3339)
	session.SetString("login_time", loginTime)

	// Clear temp data
	session.SetString("entra.temp_auth", "")
	session.SetString("entra.temp_session", "")
	session.SetString("webauthn.challenge", "")

	if err := session.Save(); err != nil {
		respondWithJSON(rw, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"error":   "Session save error",
		})
		return
	}

	logger.Debug("se", "User fully authenticated", "username", verifyReq.Username)
	respondWithJSON(rw, http.StatusOK, map[string]interface{}{
		"success":    true,
		"username":   verifyReq.Username,
		"session_id": sessionID,
		"login_time": loginTime,
	})
}

// handleWebAuthnQuickVerify handles quick WebAuthn authentication without Entra
func handleWebAuthnQuickVerify(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	
	var verifyReq struct {
		Authentication map[string]interface{} `json:"authentication"`
		Challenge      string                 `json:"challenge"`
	}

	if err := json.NewDecoder(req.Body).Decode(&verifyReq); err != nil {
		respondWithJSON(rw, http.StatusBadRequest, map[string]interface{}{
			"success": false,
			"error":   "Invalid request",
		})
		return
	}

	// Validate session and challenge
	session, err := api.Session()
	if err != nil {
		respondWithJSON(rw, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"error":   "Session error",
		})
		return
	}

	storedChallenge := session.GetString("webauthn.challenge")
	if storedChallenge != verifyReq.Challenge {
		respondWithJSON(rw, http.StatusUnauthorized, map[string]interface{}{
			"success": false,
			"error":   "Invalid challenge",
		})
		return
	}

	// Verify authentication
	if !verifyWebAuthnAuthentication(verifyReq.Authentication, storedChallenge) {
		respondWithJSON(rw, http.StatusUnauthorized, map[string]interface{}{
			"success": false,
			"error":   "WebAuthn verification failed",
		})
		return
	}

	// In production, extract username from credential ID lookup
	// For demo, we'll use a placeholder
	username := "user@example.com"
	if credUser := session.GetString("webauthn.credential_user"); credUser != "" {
		username = credUser
	}

	// Set authentication state
	session.SetString("webauthn.authenticated", "true")
	session.SetString("webauthn.quick_auth", "true")
	session.SetString("webauthn.username", username)
	sessionID := generateSessionID()
	session.SetString("session_id", sessionID)
	loginTime := time.Now().Format(time.RFC3339)
	session.SetString("login_time", loginTime)

	// Clear challenge
	session.SetString("webauthn.challenge", "")

	if err := session.Save(); err != nil {
		respondWithJSON(rw, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"error":   "Session save error",
		})
		return
	}

	logger.Debug("se", "User authenticated via quick passkey", "username", username)
	respondWithJSON(rw, http.StatusOK, map[string]interface{}{
		"success":    true,
		"username":   username,
		"session_id": sessionID,
		"login_time": loginTime,
	})
}

// handleSessionCheck checks if user has an active session
func handleSessionCheck(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	session, err := api.Session()
	if err != nil {
		respondWithJSON(rw, http.StatusOK, map[string]interface{}{
			"valid": false,
		})
		return
	}

	entraAuth := session.GetString("entra.authenticated")
	webauthnAuth := session.GetString("webauthn.authenticated")
	quickAuth := session.GetString("webauthn.quick_auth")
	
	isValid := (entraAuth == "true" && webauthnAuth == "true") || 
	          (webauthnAuth == "true" && quickAuth == "true")
	
	if isValid {
		username := session.GetString("entra.username")
		if username == "" {
			username = session.GetString("webauthn.username")
		}
		
		respondWithJSON(rw, http.StatusOK, map[string]interface{}{
			"valid":        true,
			"mfa_verified": true,
			"username":     username,
			"session_id":   session.GetString("session_id"),
			"login_time":   session.GetString("login_time"),
		})
	} else {
		respondWithJSON(rw, http.StatusOK, map[string]interface{}{
			"valid": false,
		})
	}
}

// handleLogout handles user logout
func handleLogout(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	session, err := api.Session()
	if err == nil {
		// Clear all session data
		session.Clear()
		session.Save()
	}
	
	respondWithJSON(rw, http.StatusOK, map[string]interface{}{
		"success": true,
	})
}

// authenticateWithEntra performs Entra authentication
func authenticateWithEntra(api orchestrator.Orchestrator, username, password string) (string, error) {
	logger := api.Logger()
	logger.Debug("se", "authenticating with Entra", "username", username)

	secretProvider, err := api.SecretProvider()
	if err != nil {
		return "", err
	}

	clientID := secretProvider.GetString("AZURE_CLIENT_ID")
	clientSecret := secretProvider.GetString("AZURE_CLIENT_SECRET")
	tenantID := secretProvider.GetString("AZURE_TENANT_ID")

	// For demo purposes, if Entra credentials are not configured,
	// simulate successful authentication for demo users
	if clientID == "" || clientSecret == "" || tenantID == "" {
		logger.Debug("se", "Entra not configured, using demo mode")
		// Demo mode: accept any password for demo users
		if username == "demo@example.com" || username == "user@example.com" {
			return "demo_token_" + username, nil
		}
		return "", fmt.Errorf("invalid credentials")
	}

	tokenURL := fmt.Sprintf("https://login.microsoftonline.com/%s/oauth2/v2.0/token", tenantID)
	data := url.Values{}
	data.Set("grant_type", "password")
	data.Set("client_id", clientID)
	data.Set("client_secret", clientSecret)
	data.Set("username", username)
	data.Set("password", password)
	data.Set("scope", "https://graph.microsoft.com/.default")

	req, err := http.NewRequest("POST", tokenURL, strings.NewReader(data.Encode()))
	if err != nil {
		return "", err
	}
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")

	client := &http.Client{
		Timeout: 30 * time.Second,
		Transport: &http.Transport{
			TLSClientConfig: &tls.Config{InsecureSkipVerify: false},
		},
	}
	
	resp, err := client.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", err
	}

	if resp.StatusCode != http.StatusOK {
		return "", fmt.Errorf("authentication failed: %s", string(body))
	}

	var tokenResp EntraAuthResponse
	if err := json.Unmarshal(body, &tokenResp); err != nil {
		return "", err
	}

	return tokenResp.AccessToken, nil
}

// generateWebAuthnChallenge creates a cryptographically secure challenge for WebAuthn
func generateWebAuthnChallenge() string {
	// Generate a cryptographically secure random challenge
	b := make([]byte, 32)
	_, err := rand.Read(b)
	if err != nil {
		// Fallback to timestamp-based challenge
		return fmt.Sprintf("challenge_%d_%d", time.Now().UnixNano(), time.Now().Unix())
	}
	return base64.URLEncoding.EncodeToString(b)
}

// verifyWebAuthnAuthentication verifies the WebAuthn authentication response
func verifyWebAuthnAuthentication(authentication interface{}, storedChallenge string) bool {
	// In a production environment, you would use the server-side WebAuthn library
	// to properly verify the authentication response, including:
	// 1. Parsing the authentication response
	// 2. Verifying the signature using the stored public key
	// 3. Checking the challenge matches
	// 4. Validating the origin and other security parameters
	// 5. Checking the authenticator data and flags
	
	// For this demo, we'll do basic validation
	if authentication == nil || storedChallenge == "" {
		return false
	}

	// Convert authentication to map for basic validation
	authMap, ok := authentication.(map[string]interface{})
	if !ok {
		return false
	}

	// Check that basic WebAuthn fields are present
	_, hasId := authMap["id"]
	_, hasRawId := authMap["rawId"]
	_, hasResponse := authMap["response"]
	_, hasType := authMap["type"]

	// Basic validation - in production, you'd do cryptographic verification
	// using the @passwordless-id/webauthn server module
	return hasId && hasRawId && hasResponse && hasType
}

// generateSessionID creates a unique session ID
func generateSessionID() string {
	b := make([]byte, 16)
	_, err := rand.Read(b)
	if err != nil {
		return fmt.Sprintf("sess_%d", time.Now().UnixNano())
	}
	return fmt.Sprintf("sess_%s", base64.URLEncoding.EncodeToString(b))
}

// respondWithJSON sends a JSON response
func respondWithJSON(w http.ResponseWriter, statusCode int, response interface{}) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(statusCode)
	json.NewEncoder(w).Encode(response)
}

// LoadAttributes loads user attributes
func LoadAttributes(api orchestrator.Orchestrator, _ http.ResponseWriter, _ *http.Request) error {
	logger := api.Logger()
	logger.Debug("se", "loading attributes")

	session, err := api.Session()
	if err != nil {
		return err
	}

	username := session.GetString("entra.username")
	if username == "" {
		username = session.GetString("webauthn.username")
	}
	
	if username == "" {
		return fmt.Errorf("no username in session")
	}

	session.SetString("user.email", username)
	session.SetString("auth.provider", "entra-webauthn")
	return session.Save()
}

// BuildAccessTokenClaims creates access token claims
func BuildAccessTokenClaims(api orchestrator.Orchestrator, _ *http.Request) (map[string]any, error) {
	session, err := api.Session()
	if err != nil {
		return nil, err
	}

	username := session.GetString("entra.username")
	if username == "" {
		username = session.GetString("webauthn.username")
	}
	
	return map[string]any{
		"sub":   username,
		"email": username,
		"iss":   "strata-entra-webauthn",
		"aud":   "application",
		"amr":   []string{"pwd", "mfa", "wia"}, // Authentication methods: password, MFA, Windows integrated auth
	}, nil
}

// BuildIDTokenClaims creates ID token claims
func BuildIDTokenClaims(api orchestrator.Orchestrator, _ *http.Request) (map[string]any, error) {
	session, err := api.Session()
	if err != nil {
		return nil, err
	}

	username := session.GetString("entra.username")
	if username == "" {
		username = session.GetString("webauthn.username")
	}
	
	authMethod := "entra-webauthn"
	if session.GetString("webauthn.quick_auth") == "true" {
		authMethod = "webauthn-quick"
	}
	
	return map[string]any{
		"sub":      username,
		"email":    username,
		"provider": authMethod,
		"iss":      "strata-entra-webauthn",
		"aud":      "application",
		"amr":      []string{"pwd", "mfa", "wia"},
	}, nil
}