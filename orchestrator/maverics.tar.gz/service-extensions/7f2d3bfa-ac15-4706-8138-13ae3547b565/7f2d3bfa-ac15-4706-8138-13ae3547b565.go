package main

import (
	"crypto/rand"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"net/http"
	"strings"

	"github.com/strata-io/service-extension/orchestrator"
)

// Simple HTML login page with inline WebAuthn
const loginHTML = `<!DOCTYPE html>
<html>
<head>
    <title>WebAuthn Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body { font-family: Arial, sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
        .container { background: white; padding: 2rem; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); width: 90%; max-width: 400px; }
        h2 { text-align: center; color: #333; }
        input { width: 100%; padding: 10px; margin: 10px 0; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box; }
        button { width: 100%; padding: 12px; margin: 10px 0; border: none; border-radius: 4px; background: #667eea; color: white; font-size: 16px; cursor: pointer; }
        button:hover { background: #5a67d8; }
        .error { color: red; text-align: center; margin: 10px 0; }
        .success { color: green; text-align: center; margin: 10px 0; }
        .hidden { display: none; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Login</h2>
        <div id="step1">
            <input type="text" id="username" placeholder="Username" value="demo@example.com">
            <input type="password" id="password" placeholder="Password" value="password">
            <button onclick="doLogin()">Login</button>
        </div>
        <div id="step2" class="hidden">
            <p>Choose your second factor:</p>
            <button onclick="doWebAuthn()">Use Passkey (WebAuthn)</button>
            <button onclick="skipMFA()">Skip (Demo Mode)</button>
        </div>
        <div id="message"></div>
    </div>
    
    <script>
        const baseUrl = window.location.pathname.endsWith('/') ? window.location.pathname.slice(0, -1) : window.location.pathname;
        
        async function doLogin() {
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;
            showMessage('Authenticating...', 'success');
            
            try {
                const resp = await fetch(baseUrl + '/api/login', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    credentials: 'same-origin',
                    body: JSON.stringify({username, password})
                });
                
                const data = await resp.json();
                if (data.success) {
                    showMessage('Login successful! Choose MFA method.', 'success');
                    document.getElementById('step1').classList.add('hidden');
                    document.getElementById('step2').classList.remove('hidden');
                } else {
                    showMessage(data.error || 'Login failed', 'error');
                }
            } catch (err) {
                showMessage('Network error: ' + err.message, 'error');
            }
        }
        
        async function doWebAuthn() {
            if (!window.PublicKeyCredential) {
                showMessage('WebAuthn not supported. Using demo mode.', 'error');
                skipMFA();
                return;
            }
            
            showMessage('Initiating WebAuthn...', 'success');
            
            try {
                // Get challenge
                const challengeResp = await fetch(baseUrl + '/api/challenge', {
                    method: 'POST',
                    credentials: 'same-origin'
                });
                const challengeData = await challengeResp.json();
                
                if (!challengeData.success) {
                    throw new Error(challengeData.error || 'Failed to get challenge');
                }
                
                // Create credential
                const credential = await navigator.credentials.create({
                    publicKey: {
                        challenge: Uint8Array.from(challengeData.challenge, c => c.charCodeAt(0)),
                        rp: { name: "Maverics Demo", id: window.location.hostname },
                        user: {
                            id: Uint8Array.from("user123", c => c.charCodeAt(0)),
                            name: "demo@example.com",
                            displayName: "Demo User"
                        },
                        pubKeyCredParams: [
                            { type: "public-key", alg: -7 },
                            { type: "public-key", alg: -257 }
                        ],
                        authenticatorSelection: {
                            authenticatorAttachment: "platform",
                            userVerification: "preferred"
                        },
                        timeout: 60000,
                        attestation: "direct"
                    }
                });
                
                // Verify with server
                const verifyResp = await fetch(baseUrl + '/api/verify', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    credentials: 'same-origin',
                    body: JSON.stringify({
                        credentialId: credential.id,
                        challenge: challengeData.challenge
                    })
                });
                
                const verifyData = await verifyResp.json();
                if (verifyData.success) {
                    showMessage('WebAuthn successful! Redirecting...', 'success');
                    setTimeout(() => {
                        window.location.href = baseUrl + '/success';
                    }, 1000);
                } else {
                    showMessage(verifyData.error || 'Verification failed', 'error');
                }
            } catch (err) {
                console.error('WebAuthn error:', err);
                showMessage('WebAuthn failed: ' + err.message + '. Using demo mode.', 'error');
                setTimeout(skipMFA, 2000);
            }
        }
        
        async function skipMFA() {
            showMessage('Completing login (demo mode)...', 'success');
            
            try {
                const resp = await fetch(baseUrl + '/api/skip-mfa', {
                    method: 'POST',
                    credentials: 'same-origin'
                });
                
                const data = await resp.json();
                if (data.success) {
                    showMessage('Login complete! Redirecting...', 'success');
                    setTimeout(() => {
                        window.location.href = baseUrl + '/success';
                    }, 1000);
                } else {
                    showMessage(data.error || 'Failed to complete login', 'error');
                }
            } catch (err) {
                showMessage('Error: ' + err.message, 'error');
            }
        }
        
        function showMessage(msg, type) {
            const el = document.getElementById('message');
            el.textContent = msg;
            el.className = type;
        }
        
        // Enter key support
        document.getElementById('password').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') doLogin();
        });
    </script>
</body>
</html>`

// Success page HTML
const successHTML = `<!DOCTYPE html>
<html>
<head>
    <title>Login Successful</title>
    <style>
        body { font-family: Arial, sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
        .container { background: white; padding: 2rem; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); text-align: center; }
        h1 { color: #10b981; }
        button { padding: 10px 20px; background: #667eea; color: white; border: none; border-radius: 4px; cursor: pointer; margin-top: 20px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>✓ Authentication Successful!</h1>
        <p>You are now logged in.</p>
        <p>Session ID: <span id="sessionId"></span></p>
        <button onclick="logout()">Logout</button>
    </div>
    <script>
        // Display session info
        fetch(window.location.pathname.replace('/success', '/api/session'))
            .then(r => r.json())
            .then(d => {
                if (d.sessionId) {
                    document.getElementById('sessionId').textContent = d.sessionId;
                }
            });
            
        function logout() {
            fetch(window.location.pathname.replace('/success', '/api/logout'), {
                method: 'POST',
                credentials: 'same-origin'
            }).then(() => {
                window.location.href = window.location.pathname.replace('/success', '');
            });
        }
    </script>
</body>
</html>`

// IsAuthenticated checks if the user is authenticated
func IsAuthenticated(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) bool {
	logger := api.Logger()
	session, err := api.Session()
	if err != nil {
		logger.Error("se", "session error", "error", err.Error())
		return false
	}

	authenticated := session.GetString("authenticated") == "true"
	mfaComplete := session.GetString("mfa_complete") == "true"
	
	logger.Debug("se", "auth check", "authenticated", authenticated, "mfa", mfaComplete, "path", req.URL.Path)
	
	// Allow access to success page if fully authenticated
	if strings.Contains(req.URL.Path, "/success") && authenticated && mfaComplete {
		return true
	}
	
	return authenticated && mfaComplete
}

// Authenticate handles the authentication flow
func Authenticate(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	path := req.URL.Path
	
	logger.Debug("se", "authenticate called", "method", req.Method, "path", path)
	
	// Handle API endpoints
	if strings.Contains(path, "/api/") {
		if strings.HasSuffix(path, "/api/login") && req.Method == "POST" {
			handleLogin(api, rw, req)
			return
		}
		if strings.HasSuffix(path, "/api/challenge") && req.Method == "POST" {
			handleChallenge(api, rw, req)
			return
		}
		if strings.HasSuffix(path, "/api/verify") && req.Method == "POST" {
			handleVerify(api, rw, req)
			return
		}
		if strings.HasSuffix(path, "/api/skip-mfa") && req.Method == "POST" {
			handleSkipMFA(api, rw, req)
			return
		}
		if strings.HasSuffix(path, "/api/logout") && req.Method == "POST" {
			handleLogout(api, rw, req)
			return
		}
		if strings.HasSuffix(path, "/api/session") && req.Method == "GET" {
			handleSessionInfo(api, rw, req)
			return
		}
	}
	
	// Serve login page
	rw.Header().Set("Content-Type", "text/html")
	rw.Write([]byte(loginHTML))
}

// handleLogin processes the initial login
func handleLogin(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	
	var loginReq struct {
		Username string `json:"username"`
		Password string `json:"password"`
	}
	
	if err := json.NewDecoder(req.Body).Decode(&loginReq); err != nil {
		respondJSON(rw, map[string]interface{}{"success": false, "error": "Invalid request"})
		return
	}
	
	logger.Debug("se", "login attempt", "username", loginReq.Username)
	
	// Demo authentication - accept any password for demo users
	if loginReq.Username == "" || loginReq.Password == "" {
		respondJSON(rw, map[string]interface{}{"success": false, "error": "Username and password required"})
		return
	}
	
	// Store in session
	session, err := api.Session()
	if err != nil {
		respondJSON(rw, map[string]interface{}{"success": false, "error": "Session error"})
		return
	}
	
	session.SetString("authenticated", "true")
	session.SetString("username", loginReq.Username)
	session.SetString("mfa_complete", "false")
	
	if err := session.Save(); err != nil {
		logger.Error("se", "session save error", "error", err.Error())
		respondJSON(rw, map[string]interface{}{"success": false, "error": "Session save error"})
		return
	}
	
	respondJSON(rw, map[string]interface{}{"success": true, "message": "Login successful, MFA required"})
}

// handleChallenge generates a WebAuthn challenge
func handleChallenge(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	
	challenge := generateChallenge()
	
	session, err := api.Session()
	if err != nil {
		respondJSON(rw, map[string]interface{}{"success": false, "error": "Session error"})
		return
	}
	
	session.SetString("challenge", challenge)
	if err := session.Save(); err != nil {
		logger.Error("se", "session save error", "error", err.Error())
		respondJSON(rw, map[string]interface{}{"success": false, "error": "Failed to save challenge"})
		return
	}
	
	logger.Debug("se", "challenge generated", "challenge", challenge)
	respondJSON(rw, map[string]interface{}{"success": true, "challenge": challenge})
}

// handleVerify verifies the WebAuthn response
func handleVerify(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	
	var verifyReq struct {
		CredentialID string `json:"credentialId"`
		Challenge    string `json:"challenge"`
	}
	
	if err := json.NewDecoder(req.Body).Decode(&verifyReq); err != nil {
		respondJSON(rw, map[string]interface{}{"success": false, "error": "Invalid request"})
		return
	}
	
	session, err := api.Session()
	if err != nil {
		respondJSON(rw, map[string]interface{}{"success": false, "error": "Session error"})
		return
	}
	
	storedChallenge := session.GetString("challenge")
	
	logger.Debug("se", "verify attempt", "stored", storedChallenge, "provided", verifyReq.Challenge)
	
	// In demo mode, just check that challenges match
	if storedChallenge == verifyReq.Challenge {
		session.SetString("mfa_complete", "true")
		session.SetString("session_id", generateSessionID())
		
		if err := session.Save(); err != nil {
			logger.Error("se", "session save error", "error", err.Error())
			respondJSON(rw, map[string]interface{}{"success": false, "error": "Failed to save session"})
			return
		}
		
		logger.Debug("se", "MFA complete")
		respondJSON(rw, map[string]interface{}{"success": true, "message": "MFA verification successful"})
	} else {
		respondJSON(rw, map[string]interface{}{"success": false, "error": "Invalid challenge"})
	}
}

// handleSkipMFA allows skipping MFA in demo mode
func handleSkipMFA(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	
	session, err := api.Session()
	if err != nil {
		respondJSON(rw, map[string]interface{}{"success": false, "error": "Session error"})
		return
	}
	
	authenticated := session.GetString("authenticated")
	if authenticated != "true" {
		respondJSON(rw, map[string]interface{}{"success": false, "error": "Not authenticated"})
		return
	}
	
	session.SetString("mfa_complete", "true")
	session.SetString("session_id", generateSessionID())
	
	if err := session.Save(); err != nil {
		logger.Error("se", "session save error", "error", err.Error())
		respondJSON(rw, map[string]interface{}{"success": false, "error": "Failed to save session"})
		return
	}
	
	logger.Debug("se", "MFA skipped (demo mode)")
	respondJSON(rw, map[string]interface{}{"success": true, "message": "Login complete"})
}

// handleLogout clears the session
func handleLogout(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	session, err := api.Session()
	if err == nil {
		session.SetString("authenticated", "")
		session.SetString("mfa_complete", "")
		session.SetString("username", "")
		session.SetString("session_id", "")
		session.SetString("challenge", "")
		session.Save()
	}
	
	respondJSON(rw, map[string]interface{}{"success": true})
}

// handleSessionInfo returns session information
func handleSessionInfo(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	session, err := api.Session()
	if err != nil {
		respondJSON(rw, map[string]interface{}{"error": "No session"})
		return
	}
	
	authenticated := session.GetString("authenticated") == "true"
	mfaComplete := session.GetString("mfa_complete") == "true"
	username := session.GetString("username")
	sessionID := session.GetString("session_id")
	
	respondJSON(rw, map[string]interface{}{
		"authenticated": authenticated,
		"mfaComplete":   mfaComplete,
		"username":      username,
		"sessionId":     sessionID,
	})
}

// Helper functions
func generateChallenge() string {
	b := make([]byte, 32)
	rand.Read(b)
	return base64.URLEncoding.EncodeToString(b)
}

func generateSessionID() string {
	b := make([]byte, 16)
	rand.Read(b)
	return fmt.Sprintf("sess_%s", base64.URLEncoding.EncodeToString(b))
}

func respondJSON(w http.ResponseWriter, data interface{}) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(data)
}

// LoadAttributes loads user attributes (required by Maverics)
func LoadAttributes(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) error {
	session, err := api.Session()
	if err != nil {
		return err
	}
	
	username := session.GetString("username")
	if username != "" {
		session.SetString("user.email", username)
		session.Save()
	}
	
	return nil
}

// BuildAccessTokenClaims builds access token claims (if needed)
func BuildAccessTokenClaims(api orchestrator.Orchestrator, req *http.Request) (map[string]any, error) {
	session, err := api.Session()
	if err != nil {
		return nil, err
	}
	
	username := session.GetString("username")
	
	return map[string]any{
		"sub":   username,
		"email": username,
		"iss":   "maverics-webauthn",
	}, nil
}

// BuildIDTokenClaims builds ID token claims (if needed)
func BuildIDTokenClaims(api orchestrator.Orchestrator, req *http.Request) (map[string]any, error) {
	return BuildAccessTokenClaims(api, req)
}