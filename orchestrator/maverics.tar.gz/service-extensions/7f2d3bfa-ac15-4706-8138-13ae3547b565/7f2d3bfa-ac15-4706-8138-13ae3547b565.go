package main

import (
	"crypto/rand"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"

	"github.com/strata-io/service-extension/orchestrator"
)

// HTML login page
const loginHTML = `<!DOCTYPE html>
<html>
<head>
    <title>Microsoft Entra + WebAuthn Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body { 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; 
            display: flex; 
            justify-content: center; 
            align-items: center; 
            height: 100vh; 
            margin: 0; 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
        }
        .container { 
            background: white; 
            padding: 2.5rem; 
            border-radius: 12px; 
            box-shadow: 0 4px 20px rgba(0,0,0,0.1); 
            width: 90%; 
            max-width: 400px; 
        }
        h2 { 
            text-align: center; 
            color: #333; 
            margin-bottom: 1.5rem; 
        }
        input { 
            width: 100%; 
            padding: 12px; 
            margin: 10px 0; 
            border: 2px solid #e1e8ed; 
            border-radius: 6px; 
            box-sizing: border-box; 
            font-size: 16px;
        }
        input:focus {
            outline: none;
            border-color: #667eea;
        }
        button { 
            width: 100%; 
            padding: 14px; 
            margin: 10px 0; 
            border: none; 
            border-radius: 6px; 
            background: #667eea; 
            color: white; 
            font-size: 16px; 
            font-weight: 500;
            cursor: pointer; 
            transition: all 0.3s;
        }
        button:hover { 
            background: #5a67d8; 
            transform: translateY(-1px);
        }
        .error { 
            color: #dc2626; 
            text-align: center; 
            margin: 10px 0; 
            padding: 10px;
            background: #fef2f2;
            border-radius: 6px;
            display: none;
        }
        .success { 
            color: #16a34a; 
            text-align: center; 
            margin: 10px 0;
            padding: 10px;
            background: #f0fdf4;
            border-radius: 6px;
            display: none;
        }
        .hidden { 
            display: none !important; 
        }
        .info { 
            background: #eff6ff; 
            padding: 12px; 
            border-radius: 6px; 
            margin: 10px 0; 
            font-size: 14px;
            color: #1e40af;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>🔐 Secure Login</h2>
        
        <div id="step1">
            <div class="info">
                Sign in with your Microsoft Entra credentials
            </div>
            <input type="email" id="username" placeholder="Email address" autocomplete="username">
            <input type="password" id="password" placeholder="Password" autocomplete="current-password">
            <button onclick="doLogin()">Sign In</button>
        </div>
        
        <div id="step2" class="hidden">
            <div class="info">
                Complete authentication with your second factor
            </div>
            <button onclick="doWebAuthn()">🔑 Use Passkey (WebAuthn)</button>
            <button onclick="skipMFA()" style="background: #6b7280;">Skip MFA (Testing Only)</button>
        </div>
        
        <div id="authSuccess" class="hidden">
            <div class="success" style="display: block;">
                ✓ Authentication successful! Loading application...
            </div>
        </div>
        
        <div id="errorMsg" class="error"></div>
        <div id="successMsg" class="success"></div>
    </div>
    
    <script>
        const baseUrl = window.location.pathname;
        
        async function doLogin() {
            const username = document.getElementById('username').value.trim();
            const password = document.getElementById('password').value;
            
            if (!username || !password) {
                showError('Please enter both email and password');
                return;
            }
            
            showSuccess('Authenticating with Microsoft Entra...');
            
            try {
                const resp = await fetch(baseUrl + 'api/login', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    credentials: 'same-origin',
                    body: JSON.stringify({username, password})
                });
                
                const data = await resp.json();
                
                if (data.success) {
                    showSuccess('Login successful! Please complete MFA.');
                    document.getElementById('step1').classList.add('hidden');
                    document.getElementById('step2').classList.remove('hidden');
                    window.currentUser = username;
                } else {
                    showError(data.error || 'Invalid credentials');
                }
            } catch (err) {
                showError('Network error: ' + err.message);
            }
        }
        
        async function doWebAuthn() {
            if (!window.PublicKeyCredential) {
                showError('WebAuthn is not supported in this browser. Please use Chrome, Edge, Firefox, or Safari.');
                return;
            }
            
            showSuccess('Initiating passkey authentication...');
            
            try {
                // Get challenge from server
                const challengeResp = await fetch(baseUrl + 'api/challenge', {
                    method: 'POST',
                    credentials: 'same-origin'
                });
                
                const challengeData = await challengeResp.json();
                if (!challengeData.success) {
                    throw new Error(challengeData.error || 'Failed to get challenge');
                }
                
                // Create passkey credential
                const credential = await navigator.credentials.create({
                    publicKey: {
                        challenge: Uint8Array.from(challengeData.challenge, c => c.charCodeAt(0)),
                        rp: { 
                            name: "Maverics Entra Auth",
                            id: window.location.hostname 
                        },
                        user: {
                            id: Uint8Array.from(window.currentUser || 'user', c => c.charCodeAt(0)),
                            name: window.currentUser || 'user@example.com',
                            displayName: window.currentUser || 'User'
                        },
                        pubKeyCredParams: [
                            { type: "public-key", alg: -7 },  // ES256
                            { type: "public-key", alg: -257 } // RS256
                        ],
                        authenticatorSelection: {
                            authenticatorAttachment: "platform",
                            userVerification: "preferred"
                        },
                        timeout: 60000,
                        attestation: "direct"
                    }
                });
                
                // Verify with server
                const verifyResp = await fetch(baseUrl + 'api/verify', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    credentials: 'same-origin',
                    body: JSON.stringify({
                        credentialId: credential.id,
                        challenge: challengeData.challenge
                    })
                });
                
                const verifyData = await verifyResp.json();
                
                if (verifyData.success) {
                    document.getElementById('step2').classList.add('hidden');
                    document.getElementById('authSuccess').classList.remove('hidden');
                    
                    // Reload page after a short delay to let Maverics handle the authenticated session
                    setTimeout(() => {
                        window.location.reload();
                    }, 2000);
                } else {
                    showError(verifyData.error || 'Verification failed');
                }
            } catch (err) {
                console.error('WebAuthn error:', err);
                if (err.name === 'NotAllowedError') {
                    showError('Authentication was cancelled or timed out. Please try again.');
                } else {
                    showError('Passkey error: ' + err.message);
                }
            }
        }
        
        async function skipMFA() {
            showSuccess('Completing authentication...');
            
            try {
                const resp = await fetch(baseUrl + 'api/skip-mfa', {
                    method: 'POST',
                    credentials: 'same-origin'
                });
                
                const data = await resp.json();
                
                if (data.success) {
                    document.getElementById('step2').classList.add('hidden');
                    document.getElementById('authSuccess').classList.remove('hidden');
                    
                    // Reload page after a short delay
                    setTimeout(() => {
                        window.location.reload();
                    }, 2000);
                } else {
                    showError(data.error || 'Failed to complete authentication');
                }
            } catch (err) {
                showError('Error: ' + err.message);
            }
        }
        
        function showError(msg) {
            const errorEl = document.getElementById('errorMsg');
            const successEl = document.getElementById('successMsg');
            errorEl.textContent = msg;
            errorEl.style.display = 'block';
            successEl.style.display = 'none';
            
            setTimeout(() => {
                errorEl.style.display = 'none';
            }, 5000);
        }
        
        function showSuccess(msg) {
            const errorEl = document.getElementById('errorMsg');
            const successEl = document.getElementById('successMsg');
            successEl.textContent = msg;
            successEl.style.display = 'block';
            errorEl.style.display = 'none';
        }
        
        // Enter key support
        document.getElementById('password').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') doLogin();
        });
        
        // Focus on username field
        document.getElementById('username').focus();
    </script>
</body>
</html>`

// IsAuthenticated checks if user is authenticated
func IsAuthenticated(api orchestrator.Orchestrator, _ http.ResponseWriter, _ *http.Request) bool {
	logger := api.Logger()
	
	session, err := api.Session()
	if err != nil {
		logger.Error("se", "Failed to get session", "error", err.Error())
		return false
	}
	
	// Check authentication status - GetString returns (string, error)
	authenticated, err := session.GetString("authenticated")
	if err != nil {
		authenticated = ""
	}
	
	mfaComplete, err := session.GetString("mfa_complete")
	if err != nil {
		mfaComplete = ""
	}
	
	isFullyAuthenticated := authenticated == "true" && mfaComplete == "true"
	
	logger.Debug("se", "Authentication check", 
		"authenticated", authenticated,
		"mfa_complete", mfaComplete,
		"result", isFullyAuthenticated)
	
	return isFullyAuthenticated
}

// Authenticate handles the login flow
func Authenticate(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	path := req.URL.Path
	
	logger.Debug("se", "Authenticate called", "path", path, "method", req.Method)
	
	// Handle API endpoints
	if strings.Contains(path, "/api/") {
		switch {
		case strings.HasSuffix(path, "/api/login") && req.Method == "POST":
			handleLogin(api, rw, req)
			return
		case strings.HasSuffix(path, "/api/challenge") && req.Method == "POST":
			handleChallenge(api, rw, req)
			return
		case strings.HasSuffix(path, "/api/verify") && req.Method == "POST":
			handleVerify(api, rw, req)
			return
		case strings.HasSuffix(path, "/api/skip-mfa") && req.Method == "POST":
			handleSkipMFA(api, rw, req)
			return
		case strings.HasSuffix(path, "/api/logout") && req.Method == "POST":
			handleLogout(api, rw, req)
			return
		}
	}
	
	// Serve login page for all other requests
	rw.Header().Set("Content-Type", "text/html; charset=utf-8")
	rw.WriteHeader(http.StatusOK)
	rw.Write([]byte(loginHTML))
}

// handleLogin processes the login request
func handleLogin(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	
	var loginReq struct {
		Username string `json:"username"`
		Password string `json:"password"`
	}
	
	if err := json.NewDecoder(req.Body).Decode(&loginReq); err != nil {
		sendJSON(rw, map[string]interface{}{
			"success": false,
			"error":   "Invalid request format",
		})
		return
	}
	
	if loginReq.Username == "" || loginReq.Password == "" {
		sendJSON(rw, map[string]interface{}{
			"success": false,
			"error":   "Username and password are required",
		})
		return
	}
	
	logger.Debug("se", "Login attempt", "username", loginReq.Username)
	
	// Check if we have Entra configuration
	authenticated := false
	
	secretProvider, err := api.SecretProvider()
	if err == nil {
		// Fixed: GetString returns (string, error), not just string
		clientID, _ := secretProvider.GetString("AZURE_CLIENT_ID")
		clientSecret, _ := secretProvider.GetString("AZURE_CLIENT_SECRET")
		tenantID, _ := secretProvider.GetString("AZURE_TENANT_ID")
		
		if clientID != "" && clientSecret != "" && tenantID != "" {
			// Authenticate with Microsoft Entra
			authenticated = authenticateEntra(clientID, clientSecret, tenantID, 
				loginReq.Username, loginReq.Password, api)
		} else {
			logger.Debug("se", "Entra not configured, using test mode")
			// Test mode - only for development
			if loginReq.Username == "test@test.com" && loginReq.Password == "test123" {
				authenticated = true
			}
		}
	} else {
		logger.Debug("se", "No secret provider, using test mode")
		// Test mode fallback
		if loginReq.Username == "test@test.com" && loginReq.Password == "test123" {
			authenticated = true
		}
	}
	
	if !authenticated {
		sendJSON(rw, map[string]interface{}{
			"success": false,
			"error":   "Invalid credentials",
		})
		return
	}
	
	// Create session
	session, err := api.Session()
	if err != nil {
		logger.Error("se", "Failed to get session", "error", err.Error())
		sendJSON(rw, map[string]interface{}{
			"success": false,
			"error":   "Session error",
		})
		return
	}
	
	// Set session values - SetString returns error
	err = session.SetString("authenticated", "true")
	if err != nil {
		logger.Error("se", "Failed to set authenticated", "error", err.Error())
	}
	
	err = session.SetString("username", loginReq.Username)
	if err != nil {
		logger.Error("se", "Failed to set username", "error", err.Error())
	}
	
	err = session.SetString("mfa_complete", "false")
	if err != nil {
		logger.Error("se", "Failed to set mfa_complete", "error", err.Error())
	}
	
	if err := session.Save(); err != nil {
		logger.Error("se", "Failed to save session", "error", err.Error())
		sendJSON(rw, map[string]interface{}{
			"success": false,
			"error":   "Failed to save session",
		})
		return
	}
	
	logger.Debug("se", "Login successful", "username", loginReq.Username)
	
	sendJSON(rw, map[string]interface{}{
		"success": true,
		"message": "Login successful, MFA required",
	})
}

// authenticateEntra authenticates with Microsoft Entra
func authenticateEntra(clientID, clientSecret, tenantID, username, password string, api orchestrator.Orchestrator) bool {
	logger := api.Logger()
	tokenURL := fmt.Sprintf("https://login.microsoftonline.com/%s/oauth2/v2.0/token", tenantID)
	
	logger.Debug("se", "Attempting Entra authentication", 
		"url", tokenURL,
		"username", username,
		"clientID", clientID)
	
	data := url.Values{}
	data.Set("grant_type", "password")
	data.Set("client_id", clientID)
	data.Set("client_secret", clientSecret)
	data.Set("username", username)
	data.Set("password", password)
	data.Set("scope", "https://graph.microsoft.com/.default")
	
	resp, err := http.PostForm(tokenURL, data)
	if err != nil {
		logger.Error("se", "Entra request failed", "error", err.Error())
		return false
	}
	defer resp.Body.Close()
	
	body, _ := io.ReadAll(resp.Body)
	
	if resp.StatusCode == http.StatusOK {
		logger.Debug("se", "Entra authentication successful")
		return true
	}
	
	// Parse error response for better debugging
	var errorResp map[string]interface{}
	if err := json.Unmarshal(body, &errorResp); err == nil {
		if errDesc, ok := errorResp["error_description"]; ok {
			logger.Error("se", "Entra authentication failed", 
				"error", errorResp["error"],
				"description", errDesc)
		}
	} else {
		logger.Debug("se", "Entra authentication failed", 
			"status", resp.StatusCode,
			"response", string(body))
	}
	
	return false
}

// handleChallenge generates a WebAuthn challenge
func handleChallenge(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	
	// Generate random challenge
	challenge := generateChallenge()
	
	// Store in session
	session, err := api.Session()
	if err != nil {
		logger.Error("se", "Failed to get session", "error", err.Error())
		sendJSON(rw, map[string]interface{}{
			"success": false,
			"error":   "Session error",
		})
		return
	}
	
	err = session.SetString("webauthn_challenge", challenge)
	if err != nil {
		logger.Error("se", "Failed to set challenge", "error", err.Error())
	}
	
	if err := session.Save(); err != nil {
		logger.Error("se", "Failed to save challenge", "error", err.Error())
		sendJSON(rw, map[string]interface{}{
			"success": false,
			"error":   "Failed to save challenge",
		})
		return
	}
	
	logger.Debug("se", "Challenge generated")
	
	sendJSON(rw, map[string]interface{}{
		"success":   true,
		"challenge": challenge,
	})
}

// handleVerify verifies the WebAuthn response
func handleVerify(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	
	var verifyReq struct {
		CredentialID string `json:"credentialId"`
		Challenge    string `json:"challenge"`
	}
	
	if err := json.NewDecoder(req.Body).Decode(&verifyReq); err != nil {
		sendJSON(rw, map[string]interface{}{
			"success": false,
			"error":   "Invalid request",
		})
		return
	}
	
	session, err := api.Session()
	if err != nil {
		logger.Error("se", "Failed to get session", "error", err.Error())
		sendJSON(rw, map[string]interface{}{
			"success": false,
			"error":   "Session error",
		})
		return
	}
	
	// Verify challenge - GetString returns (string, error)
	storedChallenge, err := session.GetString("webauthn_challenge")
	if err != nil {
		storedChallenge = ""
	}
	
	if storedChallenge == "" || storedChallenge != verifyReq.Challenge {
		logger.Debug("se", "Challenge mismatch", 
			"stored", storedChallenge,
			"provided", verifyReq.Challenge)
		sendJSON(rw, map[string]interface{}{
			"success": false,
			"error":   "Invalid challenge",
		})
		return
	}
	
	// Mark MFA as complete - SetString returns error
	err = session.SetString("mfa_complete", "true")
	if err != nil {
		logger.Error("se", "Failed to set mfa_complete", "error", err.Error())
	}
	
	err = session.SetString("webauthn_challenge", "") // Clear challenge
	if err != nil {
		logger.Error("se", "Failed to clear challenge", "error", err.Error())
	}
	
	if err := session.Save(); err != nil {
		logger.Error("se", "Failed to save session", "error", err.Error())
		sendJSON(rw, map[string]interface{}{
			"success": false,
			"error":   "Failed to save session",
		})
		return
	}
	
	logger.Debug("se", "WebAuthn verification successful")
	
	sendJSON(rw, map[string]interface{}{
		"success": true,
		"message": "MFA verification successful",
	})
}

// handleSkipMFA allows skipping MFA for testing
func handleSkipMFA(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	
	session, err := api.Session()
	if err != nil {
		logger.Error("se", "Failed to get session", "error", err.Error())
		sendJSON(rw, map[string]interface{}{
			"success": false,
			"error":   "Session error",
		})
		return
	}
	
	// Check if user is authenticated - GetString returns (string, error)
	authenticated, err := session.GetString("authenticated")
	if err != nil {
		authenticated = ""
	}
	
	if authenticated != "true" {
		sendJSON(rw, map[string]interface{}{
			"success": false,
			"error":   "Not authenticated",
		})
		return
	}
	
	// Mark MFA as complete - SetString returns error
	err = session.SetString("mfa_complete", "true")
	if err != nil {
		logger.Error("se", "Failed to set mfa_complete", "error", err.Error())
	}
	
	if err := session.Save(); err != nil {
		logger.Error("se", "Failed to save session", "error", err.Error())
		sendJSON(rw, map[string]interface{}{
			"success": false,
			"error":   "Failed to save session",
		})
		return
	}
	
	logger.Debug("se", "MFA skipped (testing mode)")
	
	sendJSON(rw, map[string]interface{}{
		"success": true,
		"message": "Authentication complete",
	})
}

// handleLogout clears the session
func handleLogout(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	session, err := api.Session()
	if err == nil {
		// Clear all session values - SetString returns error but we ignore for logout
		_ = session.SetString("authenticated", "")
		_ = session.SetString("mfa_complete", "")
		_ = session.SetString("username", "")
		_ = session.SetString("webauthn_challenge", "")
		_ = session.Save()
	}
	
	sendJSON(rw, map[string]interface{}{
		"success": true,
		"message": "Logged out",
	})
}

// Helper function to generate challenge
func generateChallenge() string {
	b := make([]byte, 32)
	rand.Read(b)
	return base64.URLEncoding.EncodeToString(b)
}

// Helper function to send JSON response
func sendJSON(w http.ResponseWriter, data interface{}) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(data)
}

// LoadAttributes loads user attributes (required by Maverics)
func LoadAttributes(api orchestrator.Orchestrator, _ http.ResponseWriter, _ *http.Request) error {
	session, err := api.Session()
	if err != nil {
		return err
	}
	
	// GetString returns (string, error)
	username, err := session.GetString("username")
	if err != nil {
		username = ""
	}
	
	if username != "" {
		err = session.SetString("user.email", username)
		if err != nil {
			return err
		}
		err = session.Save()
		if err != nil {
			return err
		}
	}
	
	return nil
}