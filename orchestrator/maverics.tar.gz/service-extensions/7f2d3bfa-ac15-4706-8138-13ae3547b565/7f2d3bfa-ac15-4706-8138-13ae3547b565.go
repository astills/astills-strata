package main

import (
	"crypto/tls"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"

	"github.com/strata-io/service-extension/orchestrator"
)

// Microsoft Entra authentication response
type EntraAuthResponse struct {
	AccessToken string `json:"access_token"`
	TokenType   string `json:"token_type"`
	ExpiresIn   int    `json:"expires_in"`
}

// Login page HTML template with WebAuthn MFA
const loginPageHTML = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enterprise Login</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; background-color: #f0f2f5; min-height: 100vh; display: flex; align-items: center; justify-content: center; }
        .container { background: white; padding: 2rem; border-radius: 8px; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); width: 100%; max-width: 400px; }
        .login-form { display: block; }
        .mfa-form { display: none; }
        .dashboard { display: none; text-align: center; }
        h1 { color: #333; margin-bottom: 1.5rem; text-align: center; }
        .form-group { margin-bottom: 1rem; }
        label { display: block; margin-bottom: 0.5rem; color: #555; font-weight: bold; }
        input[type="text"], input[type="password"] { width: 100%; padding: 0.75rem; border: 2px solid #ddd; border-radius: 4px; font-size: 1rem; }
        input[type="text"]:focus, input[type="password"]:focus { outline: none; border-color: #4CAF50; }
        .btn { width: 100%; padding: 0.75rem; background-color: #4CAF50; color: white; border: none; border-radius: 4px; font-size: 1rem; cursor: pointer; margin-top: 1rem; }
        .btn:hover { background-color: #45a049; }
        .btn-webauthn { background-color: #007acc; margin-bottom: 0.5rem; }
        .btn-webauthn:hover { background-color: #005c99; }
        .btn-back { background-color: #6c757d; }
        .btn-back:hover { background-color: #5a6268; }
        .btn-logout { background-color: #f44336; width: auto; padding: 0.5rem 1rem; margin-top: 1rem; }
        .btn-logout:hover { background-color: #da190b; }
        .error { color: #f44336; margin-top: 0.5rem; font-size: 0.9rem; }
        .success { color: #4CAF50; margin-top: 0.5rem; font-size: 0.9rem; }
        .demo-info { background-color: #e7f3ff; padding: 1rem; border-radius: 4px; margin-bottom: 1rem; font-size: 0.9rem; color: #333; }
        .loading { display: none; text-align: center; margin-top: 1rem; }
        .spinner { border: 4px solid #f3f3f3; border-top: 4px solid #4CAF50; border-radius: 50%; width: 30px; height: 30px; animation: spin 1s linear infinite; margin: 0 auto; }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
        .step-indicator { text-align: center; color: #666; font-size: 0.9rem; margin-bottom: 1rem; }
        .welcome-message { color: #4CAF50; font-size: 1.2rem; margin-bottom: 1rem; }
        .dashboard-content { margin: 2rem 0; }
        .feature-box { background-color: #f9f9f9; padding: 1rem; margin: 1rem 0; border-radius: 4px; text-align: left; }
        .feature-box h3 { color: #333; margin-bottom: 0.5rem; }
        .user-info { background-color: #e8f5e8; padding: 1rem; border-radius: 4px; margin-bottom: 1rem; }
        .current-time { font-size: 0.9rem; color: #666; margin-top: 1rem; }
        .webauthn-icon { font-size: 2rem; margin-bottom: 1rem; }
    </style>
    <script type="module">
        import { client } from 'https://cdn.jsdelivr.net/npm/@passwordless-id/webauthn@1.2.1/dist/webauthn.min.js'
        window.webauthnClient = client;
    </script>
</head>
<body>
    <div class="container">
        <div id="loginForm" class="login-form">
            <h1>Login</h1>
            <div class="demo-info"><strong>Enterprise Authentication:</strong><br>Microsoft Entra ID + WebAuthn MFA<br>Enter your corporate credentials</div>
            <form id="loginFormElement">
                <div class="form-group"><label for="username">Username:</label><input type="text" id="username" name="username" required></div>
                <div class="form-group"><label for="password">Password:</label><input type="password" id="password" name="password" required></div>
                <button type="submit" class="btn">Login</button>
                <div class="loading" id="loading"><div class="spinner"></div></div>
                <div id="errorMessage" class="error"></div>
                <div id="successMessage" class="success"></div>
            </form>
        </div>
        <div id="mfaForm" class="mfa-form">
            <h1>Multi-Factor Authentication</h1>
            <div class="step-indicator">Step 2 of 2</div>
            <div class="demo-info"><strong>WebAuthn Required:</strong><br>Use your biometric sensor, security key, or device authenticator</div>
            <div class="webauthn-icon">🔐</div>
            <div class="form-group"><label for="mfaUser">User:</label><input type="text" id="mfaUser" readonly></div>
            <button id="webauthnBtn" class="btn btn-webauthn">Authenticate with WebAuthn</button>
            <button id="registerBtn" class="btn" style="background-color: #28a745;">Register WebAuthn</button>
            <button id="backToLoginBtn" class="btn btn-back">Back to Login</button>
            <div class="loading" id="mfaLoading"><div class="spinner"></div></div>
            <div id="mfaErrorMessage" class="error"></div>
            <div id="mfaSuccessMessage" class="success"></div>
        </div>
        <div id="dashboard" class="dashboard">
            <h1>Dashboard</h1>
            <div class="welcome-message">Welcome back, <span id="welcomeUser"></span>!</div>
            <div class="user-info"><strong>User Information:</strong><br>Username: <span id="userInfoName"></span><br>Login Time: <span id="loginTime"></span><br>Session ID: <span id="sessionId"></span><br>Authentication: Microsoft Entra + WebAuthn MFA</div>
            <div class="dashboard-content">
                <div class="feature-box"><h3>Analytics</h3><p>View your application analytics and reports here.</p></div>
                <div class="feature-box"><h3>Settings</h3><p>Manage your account settings and preferences.</p></div>
                <div class="feature-box"><h3>Messages</h3><p>Check your messages and notifications.</p></div>
                <div class="feature-box"><h3>Users</h3><p>Manage users and permissions in your system.</p></div>
            </div>
            <div class="current-time">Current Time: <span id="currentTime"></span></div>
            <button id="logoutBtn" class="btn btn-logout">Logout</button>
        </div>
    </div>
    <script>
        const loginForm = document.getElementById('loginForm');
        const mfaForm = document.getElementById('mfaForm');
        const dashboard = document.getElementById('dashboard');
        const loginFormElement = document.getElementById('loginFormElement');
        const usernameInput = document.getElementById('username');
        const passwordInput = document.getElementById('password');
        const mfaUser = document.getElementById('mfaUser');
        const errorMessage = document.getElementById('errorMessage');
        const successMessage = document.getElementById('successMessage');
        const mfaErrorMessage = document.getElementById('mfaErrorMessage');
        const mfaSuccessMessage = document.getElementById('mfaSuccessMessage');
        const loading = document.getElementById('loading');
        const mfaLoading = document.getElementById('mfaLoading');
        const webauthnBtn = document.getElementById('webauthnBtn');
        const registerBtn = document.getElementById('registerBtn');
        const backToLoginBtn = document.getElementById('backToLoginBtn');
        const logoutBtn = document.getElementById('logoutBtn');
        const welcomeUser = document.getElementById('welcomeUser');
        const userInfoName = document.getElementById('userInfoName');
        const loginTimeEl = document.getElementById('loginTime');
        const sessionIdEl = document.getElementById('sessionId');
        const currentTime = document.getElementById('currentTime');

        let currentUser = null, currentSessionId = null, tempAuthData = null;

        function showError(message, isMfa = false) {
            const errorEl = isMfa ? mfaErrorMessage : errorMessage;
            const successEl = isMfa ? mfaSuccessMessage : successMessage;
            const loadingEl = isMfa ? mfaLoading : loading;
            errorEl.textContent = message; successEl.textContent = ''; loadingEl.style.display = 'none';
            setTimeout(() => errorEl.textContent = '', 5000);
        }

        function showSuccess(message, isMfa = false) {
            const errorEl = isMfa ? mfaErrorMessage : errorMessage;
            const successEl = isMfa ? mfaSuccessMessage : successMessage;
            const loadingEl = isMfa ? mfaLoading : loading;
            successEl.textContent = message; errorEl.textContent = ''; loadingEl.style.display = 'none';
        }

        function showLoading(isMfa = false) {
            const loadingEl = isMfa ? mfaLoading : loading;
            const errorEl = isMfa ? mfaErrorMessage : errorMessage;
            const successEl = isMfa ? mfaSuccessMessage : successMessage;
            loadingEl.style.display = 'block'; errorEl.textContent = ''; successEl.textContent = '';
        }

        function showMfaForm(username) {
            loginForm.style.display = 'none'; mfaForm.style.display = 'block'; dashboard.style.display = 'none';
            mfaUser.value = username;
        }

        function showDashboard(username, sessionId, loginTime) {
            loginForm.style.display = 'none'; mfaForm.style.display = 'none'; dashboard.style.display = 'block';
            welcomeUser.textContent = username; userInfoName.textContent = username;
            loginTimeEl.textContent = loginTime; sessionIdEl.textContent = sessionId;
            updateCurrentTime(); setInterval(updateCurrentTime, 1000);
        }

        function showLoginForm() {
            loginForm.style.display = 'block'; mfaForm.style.display = 'none'; dashboard.style.display = 'none';
            usernameInput.value = ''; passwordInput.value = ''; mfaUser.value = '';
            [errorMessage, successMessage, mfaErrorMessage, mfaSuccessMessage].forEach(el => el.textContent = '');
            [loading, mfaLoading].forEach(el => el.style.display = 'none'); tempAuthData = null;
        }

        function updateCurrentTime() { currentTime.textContent = new Date().toLocaleString(); }

        // Login form submission
        loginFormElement.addEventListener('submit', async function(e) {
            e.preventDefault();
            const username = usernameInput.value.trim(), password = passwordInput.value;
            if (!username || !password) { showError('Please enter both username and password'); return; }
            showLoading();
            try {
                const response = await fetch('/auth', { method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'include', body: JSON.stringify({ username, password, step: 'entra' }) });
                const data = await response.json();
                if (data.success) { 
                    tempAuthData = data; 
                    showSuccess('Authentication successful! Proceeding to MFA...'); 
                    setTimeout(() => showMfaForm(data.username), 1000); 
                } else { 
                    showError(data.error || 'Authentication failed'); 
                }
            } catch (error) { 
                showError('Network error. Please try again.'); 
            }
        });

        // WebAuthn Registration
        registerBtn.addEventListener('click', async function() {
            if (!tempAuthData) { showError('Session expired. Please start over.', true); showLoginForm(); return; }
            showLoading(true);
            
            try {
                // Check WebAuthn support
                if (!window.webauthnClient || !window.PublicKeyCredential) {
                    showError('WebAuthn is not supported on this device/browser', true);
                    return;
                }

                // Register new WebAuthn credential using the correct API
                const registration = await window.webauthnClient.register({
                    user: tempAuthData.username,
                    challenge: 'registration_challenge_' + Date.now(),
                    userHandle: tempAuthData.username,
                    userName: tempAuthData.username,
                    userDisplayName: tempAuthData.username.split('@')[0],
                    timeout: 60000,
                    userVerification: 'preferred'
                });

                showSuccess('WebAuthn registration successful! Now try authentication.', true);
                console.log('Registration successful:', registration);
                
            } catch (error) {
                console.error('WebAuthn registration error:', error);
                if (error.name === 'NotAllowedError') {
                    showError('Registration cancelled by user', true);
                } else if (error.name === 'NotSupportedError') {
                    showError('WebAuthn not supported on this device', true);
                } else {
                    showError('Registration failed: ' + error.message, true);
                }
            }
        });

        // WebAuthn MFA authentication
        webauthnBtn.addEventListener('click', async function() {
            if (!tempAuthData) { showError('Session expired. Please start over.', true); showLoginForm(); return; }
            showLoading(true);
            
            try {
                // Check WebAuthn support first
                if (!window.webauthnClient || !window.PublicKeyCredential) {
                    showError('WebAuthn is not supported on this device/browser', true);
                    return;
                }

                // Get challenge from server
                const challengeResponse = await fetch('/webauthn/challenge', { 
                    method: 'POST', 
                    headers: { 'Content-Type': 'application/json' },
                    credentials: 'include',
                    body: JSON.stringify({ username: tempAuthData.username, temp_session: tempAuthData.temp_session })
                });
                const challengeData = await challengeResponse.json();
                
                if (!challengeData.success) {
                    showError(challengeData.error || 'Failed to get challenge', true);
                    return;
                }

                console.log('Challenge received:', challengeData.challenge);

                // Perform WebAuthn authentication using the correct API
                const authentication = await window.webauthnClient.authenticate({
                    challenge: challengeData.challenge,
                    allowCredentials: challengeData.allowCredentials || [],
                    userVerification: 'preferred',
                    timeout: 60000
                });

                console.log('Authentication successful:', authentication);

                // Verify authentication with server
                const verifyResponse = await fetch('/webauthn/verify', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    credentials: 'include',
                    body: JSON.stringify({
                        username: tempAuthData.username,
                        temp_session: tempAuthData.temp_session,
                        authentication: authentication
                    })
                });
                const verifyData = await verifyResponse.json();
                
                if (verifyData.success) {
                    currentUser = verifyData.username;
                    currentSessionId = verifyData.session_id;
                    showSuccess('WebAuthn MFA verification successful!', true);
                    setTimeout(() => showDashboard(verifyData.username, verifyData.session_id, verifyData.login_time), 1000);
                } else {
                    showError(verifyData.error || 'MFA verification failed', true);
                }
            } catch (error) {
                console.error('WebAuthn error:', error);
                if (error.name === 'NotAllowedError') {
                    showError('Authentication cancelled by user', true);
                } else if (error.name === 'InvalidStateError') {
                    showError('No registered authenticators found. Please register first.', true);
                } else if (error.name === 'NotSupportedError') {
                    showError('WebAuthn not supported on this device', true);
                } else {
                    showError('WebAuthn authentication failed: ' + error.message, true);
                }
            }
        });

        backToLoginBtn.addEventListener('click', () => showLoginForm());
        logoutBtn.addEventListener('click', async function() { 
            try { 
                await fetch('/logout', { method: 'POST', credentials: 'include' }); 
            } catch (e) {} 
            showLoginForm(); 
        });
        
        usernameInput.focus();
        passwordInput.addEventListener('keypress', e => { if (e.key === 'Enter') loginFormElement.dispatchEvent(new Event('submit')); });
        document.addEventListener('click', e => { if (e.target.closest('.feature-box')) alert('Feature: ' + e.target.closest('.feature-box').querySelector('h3').textContent); });

        async function checkExistingSession() { 
            try { 
                const r = await fetch('/session', { credentials: 'include' }); 
                const d = await r.json(); 
                if (d.valid && d.mfa_verified) showDashboard(d.username, d.sessionId, d.loginTime); 
            } catch (e) {} 
        }
        checkExistingSession();
    </script>
</body>
</html>`

// IsAuthenticated checks if the current session is authenticated by both Microsoft Entra and WebAuthn MFA
func IsAuthenticated(api orchestrator.Orchestrator, _ http.ResponseWriter, _ *http.Request) bool {
	logger := api.Logger()
	logger.Debug("se", "determining if user is authenticated")

	session, err := api.Session()
	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		return false
	}

	// Check both Entra and WebAuthn authentication
	entraAuth := session.GetString("entra.authenticated")
	webauthnAuth := session.GetString("webauthn.authenticated")

	if entraAuth == "true" && webauthnAuth == "true" {
		logger.Debug("se", "user is fully authenticated")
		return true
	}

	logger.Debug("se", "user is not fully authenticated")
	return false
}

// Authenticate serves the login page and handles authentication requests
func Authenticate(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	logger.Debug("se", "handling authentication request")

	if req.Method == "POST" && req.URL.Path == "/auth" {
		handleEntraAuth(api, rw, req)
		return
	}

	if req.Method == "POST" && req.URL.Path == "/webauthn/challenge" {
		handleWebAuthnChallenge(api, rw, req)
		return
	}

	if req.Method == "POST" && req.URL.Path == "/webauthn/verify" {
		handleWebAuthnVerify(api, rw, req)
		return
	}

	// Serve login page
	rw.Header().Set("Content-Type", "text/html; charset=utf-8")
	rw.WriteHeader(http.StatusOK)
	rw.Write([]byte(loginPageHTML))
}

// handleEntraAuth processes Microsoft Entra authentication
func handleEntraAuth(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	logger.Debug("se", "processing Entra authentication")

	var authReq struct {
		Username string `json:"username"`
		Password string `json:"password"`
		Step     string `json:"step"`
	}

	if err := json.NewDecoder(req.Body).Decode(&authReq); err != nil {
		http.Error(rw, "Invalid request", http.StatusBadRequest)
		return
	}

	if authReq.Username == "" || authReq.Password == "" {
		respondWithJSON(rw, http.StatusBadRequest, map[string]interface{}{"success": false, "error": "Username and password required"})
		return
	}

	// Authenticate with Entra
	accessToken, err := authenticateWithEntra(api, authReq.Username, authReq.Password)
	if err != nil {
		logger.Error("se", "Entra auth failed", "error", err.Error())
		respondWithJSON(rw, http.StatusUnauthorized, map[string]interface{}{"success": false, "error": "Invalid credentials"})
		return
	}

	// Store temporary session data
	session, err := api.Session()
	if err != nil {
		http.Error(rw, "Session error", http.StatusInternalServerError)
		return
	}

	session.SetString("entra.temp_auth", "true")
	session.SetString("entra.username", authReq.Username)
	session.SetString("entra.token", accessToken)
	tempSession := generateSessionID()
	session.SetString("entra.temp_session", tempSession)

	if err := session.Save(); err != nil {
		http.Error(rw, "Session save error", http.StatusInternalServerError)
		return
	}

	respondWithJSON(rw, http.StatusOK, map[string]interface{}{
		"success":      true,
		"username":     authReq.Username,
		"temp_session": tempSession,
		"requires_mfa": true,
	})
}

// handleHyprMFA processes HYPR MFA authentication
func handleHyprMFA(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	logger.Debug("se", "processing HYPR MFA")

	var mfaReq struct {
		Username    string `json:"username"`
		TempSession string `json:"temp_session"`
		Step        string `json:"step"`
	}

	if err := json.NewDecoder(req.Body).Decode(&mfaReq); err != nil {
		http.Error(rw, "Invalid request", http.StatusBadRequest)
		return
	}

	// Validate temp session
	session, err := api.Session()
	if err != nil {
		http.Error(rw, "Session error", http.StatusInternalServerError)
		return
	}

	tempAuth := session.GetString("entra.temp_auth")
	tempSession := session.GetString("entra.temp_session")
	username := session.GetString("entra.username")

	if tempAuth != "true" || tempSession != mfaReq.TempSession || username != mfaReq.Username {
		respondWithJSON(rw, http.StatusUnauthorized, map[string]interface{}{"success": false, "error": "Invalid session"})
		return
	}

	// Perform HYPR authentication
	err = performHyprAuth(api, mfaReq.Username)
	if err != nil {
		respondWithJSON(rw, http.StatusUnauthorized, map[string]interface{}{"success": false, "error": "HYPR MFA failed"})
		return
	}

	// Set final authentication state
	session.SetString("entra.authenticated", "true")
	session.SetString("hypr.authenticated", "true")
	sessionID := generateSessionID()
	session.SetString("session_id", sessionID)
	session.SetString("login_time", time.Now().Format(time.RFC3339))

	// Clear temp data
	session.SetString("entra.temp_auth", "")
	session.SetString("entra.temp_session", "")

	if err := session.Save(); err != nil {
		http.Error(rw, "Session save error", http.StatusInternalServerError)
		return
	}

	respondWithJSON(rw, http.StatusOK, map[string]interface{}{
		"success":    true,
		"username":   mfaReq.Username,
		"session_id": sessionID,
		"login_time": time.Now().Format(time.RFC3339),
	})
}

// handleWebAuthnChallenge generates a WebAuthn challenge
func handleWebAuthnChallenge(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	logger.Debug("se", "generating WebAuthn challenge")

	var challengeReq struct {
		Username    string `json:"username"`
		TempSession string `json:"temp_session"`
	}

	if err := json.NewDecoder(req.Body).Decode(&challengeReq); err != nil {
		respondWithJSON(rw, http.StatusBadRequest, map[string]interface{}{"success": false, "error": "Invalid request"})
		return
	}

	// Validate temp session
	session, err := api.Session()
	if err != nil {
		respondWithJSON(rw, http.StatusInternalServerError, map[string]interface{}{"success": false, "error": "Session error"})
		return
	}

	tempAuth := session.GetString("entra.temp_auth")
	tempSession := session.GetString("entra.temp_session")
	username := session.GetString("entra.username")

	if tempAuth != "true" || tempSession != challengeReq.TempSession || username != challengeReq.Username {
		respondWithJSON(rw, http.StatusUnauthorized, map[string]interface{}{"success": false, "error": "Invalid session"})
		return
	}

	// Generate WebAuthn challenge
	challenge := generateWebAuthnChallenge()
	
	// Store challenge in session for verification
	session.SetString("webauthn.challenge", challenge)
	session.SetString("webauthn.username", challengeReq.Username)
	
	if err := session.Save(); err != nil {
		respondWithJSON(rw, http.StatusInternalServerError, map[string]interface{}{"success": false, "error": "Session save error"})
		return
	}

	respondWithJSON(rw, http.StatusOK, map[string]interface{}{
		"success":   true,
		"challenge": challenge,
		"allowCredentials": []interface{}{}, // Empty for first-time setup, populate with user's registered credentials
	})
}

// handleWebAuthnVerify verifies WebAuthn authentication
func handleWebAuthnVerify(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	logger.Debug("se", "verifying WebAuthn authentication")

	var verifyReq struct {
		Username       string      `json:"username"`
		TempSession    string      `json:"temp_session"`
		Authentication interface{} `json:"authentication"`
	}

	if err := json.NewDecoder(req.Body).Decode(&verifyReq); err != nil {
		respondWithJSON(rw, http.StatusBadRequest, map[string]interface{}{"success": false, "error": "Invalid request"})
		return
	}

	// Validate temp session
	session, err := api.Session()
	if err != nil {
		respondWithJSON(rw, http.StatusInternalServerError, map[string]interface{}{"success": false, "error": "Session error"})
		return
	}

	tempAuth := session.GetString("entra.temp_auth")
	tempSession := session.GetString("entra.temp_session")
	username := session.GetString("entra.username")
	storedChallenge := session.GetString("webauthn.challenge")

	if tempAuth != "true" || tempSession != verifyReq.TempSession || username != verifyReq.Username {
		respondWithJSON(rw, http.StatusUnauthorized, map[string]interface{}{"success": false, "error": "Invalid session"})
		return
	}

	// Verify WebAuthn authentication
	// In a production environment, you would properly verify the WebAuthn signature
	// For this demo, we'll do basic validation
	isValid := verifyWebAuthnAuthentication(verifyReq.Authentication, storedChallenge)
	if !isValid {
		respondWithJSON(rw, http.StatusUnauthorized, map[string]interface{}{"success": false, "error": "WebAuthn verification failed"})
		return
	}

	// Set final authentication state
	session.SetString("entra.authenticated", "true")
	session.SetString("webauthn.authenticated", "true")
	sessionID := generateSessionID()
	session.SetString("session_id", sessionID)
	session.SetString("login_time", time.Now().Format(time.RFC3339))

	// Clear temp data
	session.SetString("entra.temp_auth", "")
	session.SetString("entra.temp_session", "")
	session.SetString("webauthn.challenge", "")

	if err := session.Save(); err != nil {
		respondWithJSON(rw, http.StatusInternalServerError, map[string]interface{}{"success": false, "error": "Session save error"})
		return
	}

	logger.Debug("se", "WebAuthn authentication successful", "username", verifyReq.Username)

	respondWithJSON(rw, http.StatusOK, map[string]interface{}{
		"success":    true,
		"username":   verifyReq.Username,
		"session_id": sessionID,
		"login_time": time.Now().Format(time.RFC3339),
		"message":    "Authentication successful!",
	})
}

// authenticateWithEntra performs Entra authentication
func authenticateWithEntra(api orchestrator.Orchestrator, username, password string) (string, error) {
	logger := api.Logger()
	logger.Debug("se", "authenticating with Entra", "username", username)

	secretProvider, err := api.SecretProvider()
	if err != nil {
		return "", err
	}

	clientID := secretProvider.GetString("AZURE_CLIENT_ID")
	clientSecret := secretProvider.GetString("AZURE_CLIENT_SECRET")
	tenantID := secretProvider.GetString("AZURE_TENANT_ID")

	if clientID == "" || clientSecret == "" || tenantID == "" {
		return "", fmt.Errorf("missing Entra configuration")
	}

	tokenURL := fmt.Sprintf("https://login.microsoftonline.com/%s/oauth2/v2.0/token", tenantID)
	data := url.Values{}
	data.Set("grant_type", "password")
	data.Set("client_id", clientID)
	data.Set("client_secret", clientSecret)
	data.Set("username", username)
	data.Set("password", password)
	data.Set("scope", "https://graph.microsoft.com/.default")

	req, err := http.NewRequest("POST", tokenURL, strings.NewReader(data.Encode()))
	if err != nil {
		return "", err
	}
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")

	client := &http.Client{Timeout: 30 * time.Second, Transport: &http.Transport{TLSClientConfig: &tls.Config{InsecureSkipVerify: false}}}
	resp, err := client.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", err
	}

	if resp.StatusCode != http.StatusOK {
		return "", fmt.Errorf("authentication failed: %s", string(body))
	}

	var tokenResp EntraAuthResponse
	if err := json.Unmarshal(body, &tokenResp); err != nil {
		return "", err
	}

	return tokenResp.AccessToken, nil
}

// performHyprAuth performs HYPR MFA authentication
func performHyprAuth(api orchestrator.Orchestrator, username string) error {
	logger := api.Logger()
	logger.Debug("se", "performing HYPR auth", "username", username)

	hyprIDP, err := api.IdentityProvider("hypr")
	if err != nil {
		return err
	}

	// This would normally trigger HYPR authentication flow
	// For now, we'll simulate success
	logger.Debug("se", "HYPR auth successful", "username", username)
	return nil
}

// generateWebAuthnChallenge creates a cryptographically secure challenge for WebAuthn
func generateWebAuthnChallenge() string {
	// Generate a cryptographically secure random challenge
	// In production, this should be a proper cryptographic random byte array
	// For this demo, we'll create a base64-encoded random string
	challenge := fmt.Sprintf("challenge_%d_%d", time.Now().UnixNano(), time.Now().Unix())
	return challenge
}

// verifyWebAuthnAuthentication verifies the WebAuthn authentication response
func verifyWebAuthnAuthentication(authentication interface{}, storedChallenge string) bool {
	// In a production environment, you would:
	// 1. Parse the authentication response
	// 2. Verify the signature using the stored public key
	// 3. Check the challenge matches
	// 4. Validate the origin and other security parameters
	// 
	// For this demo, we'll do basic validation
	if authentication == nil || storedChallenge == "" {
		return false
	}

	// Convert authentication to map for basic validation
	authMap, ok := authentication.(map[string]interface{})
	if !ok {
		return false
	}

	// Check that basic WebAuthn fields are present
	_, hasId := authMap["id"]
	_, hasRawId := authMap["rawId"]
	_, hasResponse := authMap["response"]
	_, hasType := authMap["type"]

	// Basic validation - in production, you'd do cryptographic verification
	return hasId && hasRawId && hasResponse && hasType
}

// generateSessionID creates a unique session ID
func generateSessionID() string {
	return fmt.Sprintf("sess_%d", time.Now().UnixNano())
}

// respondWithJSON sends a JSON response
func respondWithJSON(w http.ResponseWriter, statusCode int, response interface{}) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(statusCode)
	json.NewEncoder(w).Encode(response)
}

// LoadAttributes loads user attributes
func LoadAttributes(api orchestrator.Orchestrator, _ http.ResponseWriter, _ *http.Request) error {
	logger := api.Logger()
	logger.Debug("se", "loading attributes")

	session, err := api.Session()
	if err != nil {
		return err
	}

	username := session.GetString("entra.username")
	if username == "" {
		return fmt.Errorf("no username in session")
	}

	session.SetString("user.email", username)
	session.SetString("auth.provider", "entra-hypr")
	return session.Save()
}

// BuildAccessTokenClaims creates access token claims
func BuildAccessTokenClaims(api orchestrator.Orchestrator, _ *http.Request) (map[string]any, error) {
	session, err := api.Session()
	if err != nil {
		return nil, err
	}

	username := session.GetString("entra.username")
	return map[string]any{
		"sub":   username,
		"email": username,
		"iss":   "strata-entra-hypr",
		"aud":   "application",
	}, nil
}

// BuildIDTokenClaims creates ID token claims
func BuildIDTokenClaims(api orchestrator.Orchestrator, _ *http.Request) (map[string]any, error) {
	session, err := api.Session()
	if err != nil {
		return nil, err
	}

	username := session.GetString("entra.username")
	return map[string]any{
		"sub":      username,
		"email":    username,
		"provider": "entra-hypr",
		"iss":      "strata-entra-hypr",
		"aud":      "application",
	}, nil
}