package main

import (
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"

	"github.com/strata-io/service-extension/orchestrator"
)

// Token response structures
type TokenResponse struct {
	AccessToken  string `json:"access_token"`
	TokenType    string `json:"token_type"`
	ExpiresIn    int    `json:"expires_in"`
	RefreshToken string `json:"refresh_token,omitempty"`
	IDToken      string `json:"id_token,omitempty"`
	Scope        string `json:"scope,omitempty"`
}

// ID Token claims structure
type IDTokenClaims struct {
	Sub               string `json:"sub"`
	Name              string `json:"name"`
	PreferredUsername string `json:"preferred_username"`
	Email             string `json:"email"`
	EmailVerified     bool   `json:"email_verified"`
}

// PKCE challenge structure
type PKCEChallenge struct {
	Verifier  string `json:"verifier"`
	Challenge string `json:"challenge"`
	Method    string `json:"method"`
}

// Error response structure
type ErrorResponse struct {
	Error            string `json:"error"`
	ErrorDescription string `json:"error_description"`
	ErrorCodes       []int  `json:"error_codes,omitempty"`
	Timestamp        string `json:"timestamp,omitempty"`
	TraceID          string `json:"trace_id,omitempty"`
	CorrelationID    string `json:"correlation_id,omitempty"`
}

// IsAuthenticated checks if the current session is marked as authenticated by Microsoft Entra
func IsAuthenticated(api orchestrator.Orchestrator, _ http.ResponseWriter, _ *http.Request) bool {
	logger := api.Logger()
	logger.Debug("se", "determining if user is authenticated via Microsoft Entra")

	session, err := api.Session()
	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		return false
	}

	isEntraAuth := session.GetString("entra.authenticated")
	username := session.GetString("entra.username")
	smUser := session.GetString("SM_USER")

	if isEntraAuth == "true" && username != "" {
		// Ensure SM_USER is set if authenticated
		if smUser == "" {
			logger.Debug("se", "SM_USER not set, loading attributes")
			if err := LoadAttributes(api, nil, nil); err != nil {
				logger.Error("se", "failed to load attributes", "error", err.Error())
			}
		}
		
		logger.Debug("se", "user is authenticated via Microsoft Entra", 
			"username", username,
			"SM_USER", smUser)
		return true
	}

	logger.Debug("se", "user is not authenticated via Microsoft Entra")
	return false
}

// Authenticate handles the OAuth2 authorization code flow with PKCE
func Authenticate(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	
	// Check if user is authenticated and trying to access the app
	session, _ := api.Session()
	isEntraAuth := session.GetString("entra.authenticated")
	username := session.GetString("entra.username")
	
	if isEntraAuth == "true" && username != "" && (req.URL.Path == "/" || req.URL.Path == "/index.html") {
		logger.Debug("se", "authenticated user accessing app, injecting credentials")
		injectAuthenticationScript(rw, username)
		return
	}
	
	// Handle OAuth callback
	if strings.HasPrefix(req.URL.Path, "/auth/callback") || req.URL.Query().Get("code") != "" || req.URL.Query().Get("error") != "" {
		handleOAuthCallback(api, rw, req)
		return
	}

	// Check if already authenticated
	if IsAuthenticated(api, rw, req) {
		logger.Debug("se", "user already authenticated, redirecting to application")
		// Redirect to root which will inject the authentication
		http.Redirect(rw, req, "/", http.StatusFound)
		return
	}

	logger.Info("se", "initiating Microsoft Entra authentication with PKCE")

	// Generate PKCE challenge
	pkce, err := generatePKCEChallenge()
	if err != nil {
		logger.Error("se", "failed to generate PKCE challenge", "error", err.Error())
		http.Error(rw, "Authentication setup failed", http.StatusInternalServerError)
		return
	}

	// Generate state for CSRF protection
	state, err := generateRandomString(32)
	if err != nil {
		logger.Error("se", "failed to generate state", "error", err.Error())
		http.Error(rw, "Authentication setup failed", http.StatusInternalServerError)
		return
	}

	// Store PKCE and state in session
	session, err := api.Session()
	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		http.Error(rw, "Session error", http.StatusInternalServerError)
		return
	}

	session.SetString("pkce.verifier", pkce.Verifier)
	session.SetString("pkce.challenge", pkce.Challenge)
	session.SetString("oauth.state", state)
	session.SetString("auth.timestamp", time.Now().Format(time.RFC3339))
	
	if err := session.Save(); err != nil {
		logger.Error("se", "unable to save session", "error", err.Error())
		http.Error(rw, "Session save error", http.StatusInternalServerError)
		return
	}

	// Get Azure AD configuration
	secretProvider, err := api.SecretProvider()
	if err != nil {
		logger.Error("se", "failed to get secret provider", "error", err.Error())
		http.Error(rw, "Configuration error", http.StatusInternalServerError)
		return
	}

	clientID := secretProvider.GetString("AZURE_CLIENT_ID")
	tenantID := secretProvider.GetString("AZURE_TENANT_ID")

	if clientID == "" || tenantID == "" {
		logger.Error("se", "missing Azure configuration")
		http.Error(rw, "Configuration error", http.StatusInternalServerError)
		return
	}

	// Build authorization URL
	authURL := buildAuthorizationURL(clientID, tenantID, pkce.Challenge, state, req)

	logger.Info("se", "redirecting to Microsoft Entra for authentication", 
		"client_id", clientID,
		"state", state[:8]+"...",
		"pkce_method", pkce.Method)

	// Redirect to Microsoft Entra
	http.Redirect(rw, req, authURL, http.StatusFound)
}

// handleOAuthCallback processes the OAuth callback from Microsoft Entra
func handleOAuthCallback(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	logger.Info("se", "handling OAuth callback from Microsoft Entra")

	session, err := api.Session()
	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		http.Error(rw, "Session error", http.StatusInternalServerError)
		return
	}

	// Check for error in callback
	if errCode := req.URL.Query().Get("error"); errCode != "" {
		errDesc := req.URL.Query().Get("error_description")
		logger.Error("se", "authentication error from Microsoft Entra", 
			"error", errCode, 
			"description", errDesc)
		
		// Render error page
		renderErrorPage(rw, fmt.Sprintf("Authentication failed: %s - %s", errCode, errDesc))
		return
	}

	// Get authorization code and state
	code := req.URL.Query().Get("code")
	state := req.URL.Query().Get("state")

	if code == "" {
		logger.Error("se", "no authorization code in callback")
		renderErrorPage(rw, "Authentication failed: no authorization code received")
		return
	}

	// Verify state parameter
	savedState := session.GetString("oauth.state")
	if state != savedState {
		logger.Error("se", "state parameter mismatch", "expected", savedState, "received", state)
		renderErrorPage(rw, "Authentication failed: invalid state parameter")
		return
	}

	// Get PKCE verifier
	pkceVerifier := session.GetString("pkce.verifier")
	if pkceVerifier == "" {
		logger.Error("se", "no PKCE verifier found in session")
		renderErrorPage(rw, "Authentication failed: invalid session")
		return
	}

	// Exchange code for tokens
	logger.Info("se", "exchanging authorization code for tokens")
	tokens, err := exchangeCodeForTokens(api, code, pkceVerifier, req)
	if err != nil {
		logger.Error("se", "token exchange failed", "error", err.Error())
		renderErrorPage(rw, fmt.Sprintf("Authentication failed: %v", err))
		return
	}

	// Parse ID token to get user information
	userInfo, err := parseIDToken(tokens.IDToken)
	if err != nil {
		logger.Error("se", "failed to parse ID token", "error", err.Error())
		renderErrorPage(rw, "Authentication failed: invalid ID token")
		return
	}

	// Store authentication data in session
	session.SetString("entra.authenticated", "true")
	session.SetString("entra.username", userInfo.Email)
	session.SetString("entra.name", userInfo.Name)
	session.SetString("entra.sub", userInfo.Sub)
	session.SetString("entra.access_token", tokens.AccessToken)
	session.SetString("entra.id_token", tokens.IDToken)
	if tokens.RefreshToken != "" {
		session.SetString("entra.refresh_token", tokens.RefreshToken)
	}
	session.SetString("entra.login_time", time.Now().Format(time.RFC3339))
	session.SetString("entra.session_id", generateSessionID())
	
	// Set SM_USER and other required attributes immediately
	smUser := userInfo.Sub
	if smUser == "" {
		smUser = userInfo.Email
	}
	session.SetString("SM_USER", smUser)
	session.SetString("sm_user", smUser)
	session.SetString("MSFT-EEID.SM_USER", smUser)
	session.SetString("email", userInfo.Email)
	session.SetString("mail", userInfo.Email)
	session.SetString("displayName", userInfo.Name)
	session.SetString("name", userInfo.Name)

	// Clean up PKCE and state from session
	session.SetString("pkce.verifier", "")
	session.SetString("pkce.challenge", "")
	session.SetString("oauth.state", "")

	if err := session.Save(); err != nil {
		logger.Error("se", "unable to save session", "error", err.Error())
		http.Error(rw, "Session save error", http.StatusInternalServerError)
		return
	}

	logger.Info("se", "user authenticated successfully", 
		"username", userInfo.Email,
		"name", userInfo.Name)

	// Render success page with redirect
	renderSuccessPage(rw, userInfo.Email)
}

// exchangeCodeForTokens exchanges the authorization code for tokens
func exchangeCodeForTokens(api orchestrator.Orchestrator, code string, pkceVerifier string, req *http.Request) (*TokenResponse, error) {
	logger := api.Logger()
	
	secretProvider, err := api.SecretProvider()
	if err != nil {
		return nil, fmt.Errorf("failed to get secret provider: %w", err)
	}

	clientID := secretProvider.GetString("AZURE_CLIENT_ID")
	clientSecret := secretProvider.GetString("AZURE_CLIENT_SECRET")
	tenantID := secretProvider.GetString("AZURE_TENANT_ID")

	if clientID == "" || tenantID == "" {
		return nil, fmt.Errorf("missing Azure configuration")
	}

	tokenURL := fmt.Sprintf("https://login.microsoftonline.com/%s/oauth2/v2.0/token", tenantID)
	redirectURI := getRedirectURI(req)

	data := url.Values{}
	data.Set("grant_type", "authorization_code")
	data.Set("client_id", clientID)
	data.Set("code", code)
	data.Set("redirect_uri", redirectURI)
	data.Set("code_verifier", pkceVerifier)
	
	// Include client secret if configured (for confidential clients)
	if clientSecret != "" {
		data.Set("client_secret", clientSecret)
	}

	logger.Debug("se", "making token exchange request", 
		"client_id", clientID,
		"redirect_uri", redirectURI)

	httpReq, err := http.NewRequest("POST", tokenURL, strings.NewReader(data.Encode()))
	if err != nil {
		return nil, fmt.Errorf("failed to create request: %w", err)
	}

	httpReq.Header.Set("Content-Type", "application/x-www-form-urlencoded")

	client := &http.Client{Timeout: 30 * time.Second}
	resp, err := client.Do(httpReq)
	if err != nil {
		return nil, fmt.Errorf("request failed: %w", err)
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("failed to read response: %w", err)
	}

	if resp.StatusCode != http.StatusOK {
		var errResp ErrorResponse
		if err := json.Unmarshal(body, &errResp); err == nil {
			return nil, fmt.Errorf("%s: %s", errResp.Error, errResp.ErrorDescription)
		}
		return nil, fmt.Errorf("token exchange failed: %s", string(body))
	}

	var tokenResp TokenResponse
	if err := json.Unmarshal(body, &tokenResp); err != nil {
		return nil, fmt.Errorf("failed to parse token response: %w", err)
	}

	return &tokenResp, nil
}

// generatePKCEChallenge generates PKCE code verifier and challenge
func generatePKCEChallenge() (*PKCEChallenge, error) {
	// Generate code verifier (43-128 characters)
	verifier, err := generateRandomString(128)
	if err != nil {
		return nil, err
	}

	// Generate code challenge using S256 method
	h := sha256.Sum256([]byte(verifier))
	challenge := base64.RawURLEncoding.EncodeToString(h[:])

	return &PKCEChallenge{
		Verifier:  verifier,
		Challenge: challenge,
		Method:    "S256",
	}, nil
}

// generateRandomString generates a cryptographically secure random string
func generateRandomString(length int) (string, error) {
	bytes := make([]byte, length)
	if _, err := rand.Read(bytes); err != nil {
		return "", err
	}
	return base64.RawURLEncoding.EncodeToString(bytes)[:length], nil
}

// buildAuthorizationURL builds the Microsoft Entra authorization URL
func buildAuthorizationURL(clientID, tenantID, codeChallenge, state string, req *http.Request) string {
	authURL := fmt.Sprintf("https://login.microsoftonline.com/%s/oauth2/v2.0/authorize", tenantID)
	
	params := url.Values{}
	params.Set("client_id", clientID)
	params.Set("response_type", "code")
	params.Set("redirect_uri", getRedirectURI(req))
	params.Set("response_mode", "query")
	params.Set("scope", "openid profile email offline_access")
	params.Set("state", state)
	params.Set("code_challenge", codeChallenge)
	params.Set("code_challenge_method", "S256")
	params.Set("prompt", "select_account") // Allows account selection and handles MFA

	return authURL + "?" + params.Encode()
}

// getRedirectURI constructs the redirect URI based on the current request
func getRedirectURI(req *http.Request) string {
	scheme := "https"
	if req.TLS == nil && req.Header.Get("X-Forwarded-Proto") != "https" {
		scheme = "http"
	}
	
	host := req.Host
	if forwarded := req.Header.Get("X-Forwarded-Host"); forwarded != "" {
		host = forwarded
	}
	
	return fmt.Sprintf("%s://%s/auth/callback", scheme, host)
}

// parseIDToken parses the ID token (simplified - in production use proper JWT validation)
func parseIDToken(idToken string) (*IDTokenClaims, error) {
	// Split the JWT
	parts := strings.Split(idToken, ".")
	if len(parts) != 3 {
		return nil, fmt.Errorf("invalid ID token format")
	}

	// Decode the payload (parts[1])
	payload, err := base64.RawURLEncoding.DecodeString(parts[1])
	if err != nil {
		return nil, fmt.Errorf("failed to decode ID token: %w", err)
	}

	var claims IDTokenClaims
	if err := json.Unmarshal(payload, &claims); err != nil {
		return nil, fmt.Errorf("failed to parse ID token claims: %w", err)
	}

	// Use preferred_username as email if email is not set
	if claims.Email == "" && claims.PreferredUsername != "" {
		claims.Email = claims.PreferredUsername
	}

	return &claims, nil
}

// generateSessionID creates a unique session identifier
func generateSessionID() string {
	return fmt.Sprintf("entra_sess_%d_%s", time.Now().UnixNano(), generateShortID())
}

// generateShortID generates a short random ID
func generateShortID() string {
	b := make([]byte, 4)
	rand.Read(b)
	return fmt.Sprintf("%x", b)
}

// renderSuccessPage renders a success page after authentication
func renderSuccessPage(rw http.ResponseWriter, username string) {
	html := fmt.Sprintf(`
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Authentication Successful</title>
    <script>
        // Set localStorage to bypass the application's login
        localStorage.setItem('currentUser', '%s');
        localStorage.setItem('sessionId', 'entra_sess_%d');
        localStorage.setItem('loginTime', new Date().toLocaleString());
        
        // Redirect to application after setting localStorage
        setTimeout(function() {
            window.location.href = '/';
        }, 2000);
    </script>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            background: linear-gradient(135deg, #667eea 0%%, #764ba2 100%%);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background: white;
            padding: 2rem 3rem;
            border-radius: 10px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            text-align: center;
            max-width: 400px;
        }
        .success-icon {
            width: 80px;
            height: 80px;
            margin: 0 auto 1rem;
            background: #48bb78;
            border-radius: 50%%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .checkmark {
            color: white;
            font-size: 48px;
        }
        h1 {
            color: #2d3748;
            margin-bottom: 0.5rem;
        }
        .username {
            color: #4a5568;
            margin-bottom: 1.5rem;
            font-weight: 500;
        }
        .message {
            color: #718096;
            margin-bottom: 1rem;
        }
        .spinner {
            border: 3px solid #f3f3f3;
            border-top: 3px solid #667eea;
            border-radius: 50%%;
            width: 30px;
            height: 30px;
            animation: spin 1s linear infinite;
            margin: 0 auto;
        }
        @keyframes spin {
            0%% { transform: rotate(0deg); }
            100%% { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="success-icon">
            <div class="checkmark">✓</div>
        </div>
        <h1>Authentication Successful!</h1>
        <div class="username">Welcome, %s</div>
        <div class="message">Setting up your session...</div>
        <div class="spinner"></div>
    </div>
</body>
</html>`, username, time.Now().UnixNano(), username)

	rw.Header().Set("Content-Type", "text/html; charset=utf-8")
	rw.WriteHeader(http.StatusOK)
	rw.Write([]byte(html))
}

// renderErrorPage renders an error page
func renderErrorPage(rw http.ResponseWriter, errorMessage string) {
	html := fmt.Sprintf(`
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Authentication Failed</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            background: linear-gradient(135deg, #f56565 0%%, #c53030 100%%);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background: white;
            padding: 2rem 3rem;
            border-radius: 10px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            text-align: center;
            max-width: 500px;
        }
        .error-icon {
            width: 80px;
            height: 80px;
            margin: 0 auto 1rem;
            background: #f56565;
            border-radius: 50%%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .error-x {
            color: white;
            font-size: 48px;
            font-weight: bold;
        }
        h1 {
            color: #2d3748;
            margin-bottom: 1rem;
        }
        .error-message {
            color: #e53e3e;
            margin-bottom: 1.5rem;
            padding: 1rem;
            background: #fff5f5;
            border-radius: 5px;
            border: 1px solid #feb2b2;
        }
        .back-button {
            display: inline-block;
            padding: 0.75rem 2rem;
            background: #4299e1;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background 0.3s;
        }
        .back-button:hover {
            background: #3182ce;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="error-icon">
            <div class="error-x">✕</div>
        </div>
        <h1>Authentication Failed</h1>
        <div class="error-message">%s</div>
        <a href="/" class="back-button">Try Again</a>
    </div>
</body>
</html>`, errorMessage)

	rw.Header().Set("Content-Type", "text/html; charset=utf-8")
	rw.WriteHeader(http.StatusUnauthorized)
	rw.Write([]byte(html))
}

// LoadAttributes loads user attributes from session
func LoadAttributes(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) error {
	logger := api.Logger()
	logger.Debug("se", "loading attributes from Microsoft Entra session")

	session, err := api.Session()
	if err != nil {
		return fmt.Errorf("unable to retrieve session: %w", err)
	}

	username := session.GetString("entra.username")
	sub := session.GetString("entra.sub")
	name := session.GetString("entra.name")
	
	if username == "" {
		return fmt.Errorf("no authenticated user in session")
	}

	// Set SM_USER attribute (required by the application)
	// Use sub (subject) as the primary identifier, fallback to username
	smUser := sub
	if smUser == "" {
		smUser = username
	}
	
	// Set all required attributes with various naming conventions
	session.SetString("SM_USER", smUser)
	session.SetString("sm_user", smUser)
	session.SetString("MSFT-EEID.SM_USER", smUser)
	session.SetString("SM_USERLOGIN", username)
	
	// Set additional common attributes
	session.SetString("entra.email", username)
	session.SetString("entra.provider", "MSFT-EEID")
	session.SetString("email", username)
	session.SetString("mail", username)
	session.SetString("displayName", name)
	session.SetString("name", name)
	session.SetString("SM_USERNAME", name)
	
	// Set provider-specific attributes
	session.SetString("MSFT-EEID.email", username)
	session.SetString("MSFT-EEID.name", name)
	session.SetString("MSFT-EEID.sub", sub)
	
	// Try to get tenant ID from secrets
	secretProvider, err := api.SecretProvider()
	if err == nil {
		tenantID := secretProvider.GetString("AZURE_TENANT_ID")
		if tenantID != "" {
			session.SetString("entra.tenant_id", tenantID)
			session.SetString("MSFT-EEID.tenant_id", tenantID)
		}
	}

	// If response writer is available, set headers directly
	if rw != nil {
		rw.Header().Set("SM_USER", smUser)
		rw.Header().Set("SM_USERLOGIN", username)
		rw.Header().Set("email", username)
		rw.Header().Set("displayName", name)
		rw.Header().Set("SM_USERNAME", name)
		
		logger.Debug("se", "headers set directly on response")
	}

	if err := session.Save(); err != nil {
		return fmt.Errorf("unable to save session: %w", err)
	}

	logger.Debug("se", "attributes loaded successfully", 
		"username", username,
		"SM_USER", smUser,
		"provider", "MSFT-EEID")
	return nil
}

// BuildAccessTokenClaims creates claims for access tokens
func BuildAccessTokenClaims(api orchestrator.Orchestrator, _ *http.Request) (map[string]any, error) {
	logger := api.Logger()
	logger.Debug("se", "building access token claims")

	session, err := api.Session()
	if err != nil {
		return nil, fmt.Errorf("unable to retrieve session: %w", err)
	}

	username := session.GetString("entra.username")
	email := session.GetString("entra.email")
	sub := session.GetString("entra.sub")
	name := session.GetString("entra.name")

	if username == "" {
		return nil, fmt.Errorf("no authenticated user in session")
	}

	return map[string]any{
		"sub":   sub,
		"email": email,
		"name":  name,
		"preferred_username": username,
		"iss":   "strata-entra-auth",
		"aud":   "application",
		"auth_time": time.Now().Unix(),
	}, nil
}

// BuildIDTokenClaims creates claims for ID tokens
func BuildIDTokenClaims(api orchestrator.Orchestrator, _ *http.Request) (map[string]any, error) {
	logger := api.Logger()
	logger.Debug("se", "building ID token claims")

	session, err := api.Session()
	if err != nil {
		return nil, fmt.Errorf("unable to retrieve session: %w", err)
	}

	username := session.GetString("entra.username")
	email := session.GetString("entra.email")
	provider := session.GetString("entra.provider")
	sub := session.GetString("entra.sub")
	name := session.GetString("entra.name")
	nonce := session.GetString("oauth.nonce")

	if username == "" {
		return nil, fmt.Errorf("no authenticated user in session")
	}

	return map[string]any{
		"sub":      sub,
		"email":    email,
		"name":     name,
		"preferred_username": username,
		"provider": provider,
		"iss":      "strata-entra-auth",
		"aud":      "application",
		"auth_time": time.Now().Unix(),
		"nonce":    nonce,
	}, nil
}