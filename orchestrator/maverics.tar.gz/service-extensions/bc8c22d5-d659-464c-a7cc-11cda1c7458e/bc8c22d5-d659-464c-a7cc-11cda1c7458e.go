package main

import (
	"crypto/tls"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"

	"github.com/strata-io/service-extension/orchestrator"
)

// Microsoft Entra authentication response
type EntraAuthResponse struct {
	AccessToken string `json:"access_token"`
	TokenType   string `json:"token_type"`
	ExpiresIn   int    `json:"expires_in"`
}

// Login page HTML template with embedded JavaScript for Microsoft Entra + HYPR MFA authentication
const loginPageHTML = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Microsoft Entra + HYPR MFA Login</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f0f2f5;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .container {
            background: white;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
        }

        .login-form, .mfa-form {
            display: block;
        }

        .mfa-form {
            display: none;
        }

        .dashboard {
            display: none;
            text-align: center;
        }

        h1 {
            color: #333;
            margin-bottom: 1.5rem;
            text-align: center;
        }

        .form-group {
            margin-bottom: 1rem;
        }

        label {
            display: block;
            margin-bottom: 0.5rem;
            color: #555;
            font-weight: bold;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 0.75rem;
            border: 2px solid #ddd;
            border-radius: 4px;
            font-size: 1rem;
        }

        input[type="text"]:focus,
        input[type="password"]:focus {
            outline: none;
            border-color: #4CAF50;
        }

        .btn {
            width: 100%;
            padding: 0.75rem;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 1rem;
            cursor: pointer;
            margin-top: 1rem;
        }

        .btn:hover {
            background-color: #45a049;
        }

        .btn-hypr {
            background-color: #007acc;
        }

        .btn-hypr:hover {
            background-color: #005c99;
        }

        .btn-logout {
            background-color: #f44336;
            width: auto;
            padding: 0.5rem 1rem;
            margin-top: 1rem;
        }

        .btn-logout:hover {
            background-color: #da190b;
        }

        .error {
            color: #f44336;
            margin-top: 0.5rem;
            font-size: 0.9rem;
        }

        .success {
            color: #4CAF50;
            margin-top: 0.5rem;
            font-size: 0.9rem;
        }

        .demo-info {
            background-color: #e7f3ff;
            padding: 1rem;
            border-radius: 4px;
            margin-bottom: 1rem;
            font-size: 0.9rem;
            color: #333;
        }

        .mfa-info {
            background-color: #fff3cd;
            padding: 1rem;
            border-radius: 4px;
            margin-bottom: 1rem;
            font-size: 0.9rem;
            color: #856404;
            border: 1px solid #ffeaa7;
        }

        .welcome-message {
            color: #4CAF50;
            font-size: 1.2rem;
            margin-bottom: 1rem;
        }

        .dashboard-content {
            margin: 2rem 0;
        }

        .feature-box {
            background-color: #f9f9f9;
            padding: 1rem;
            margin: 1rem 0;
            border-radius: 4px;
            text-align: left;
        }

        .feature-box h3 {
            color: #333;
            margin-bottom: 0.5rem;
        }

        .user-info {
            background-color: #e8f5e8;
            padding: 1rem;
            border-radius: 4px;
            margin-bottom: 1rem;
        }

        .current-time {
            font-size: 0.9rem;
            color: #666;
            margin-top: 1rem;
        }

        .loading {
            display: none;
            text-align: center;
            margin-top: 1rem;
        }

        .spinner {
            border: 4px solid #f3f3f3;
            border-top: 4px solid #4CAF50;
            border-radius: 50%;
            width: 30px;
            height: 30px;
            animation: spin 1s linear infinite;
            margin: 0 auto;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .auth-step {
            font-weight: bold;
            color: #007acc;
            margin-bottom: 1rem;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Login Form -->
        <div id="loginForm" class="login-form">
            <h1>Enterprise Login</h1>
            
            <div class="demo-info">
                <strong>Two-Factor Authentication:</strong><br>
                Step 1: Microsoft Entra ID Authentication<br>
                Step 2: HYPR MFA Verification<br>
                Integrated with Strata Identity
            </div>

            <form id="loginFormElement">
                <div class="form-group">
                    <label for="username">Username (Email):</label>
                    <input type="text" id="username" name="username" required>
                </div>

                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" id="password" name="password" required>
                </div>

                <button type="submit" class="btn">Step 1: Login with Microsoft Entra</button>
                
                <div class="loading" id="loading">
                    <div class="spinner"></div>
                    <p>Authenticating with Microsoft Entra...</p>
                </div>
                
                <div id="errorMessage" class="error"></div>
                <div id="successMessage" class="success"></div>
            </form>
        </div>

        <!-- MFA Form -->
        <div id="mfaForm" class="mfa-form">
            <h1>HYPR MFA Verification</h1>
            
            <div class="auth-step">Step 2 of 2: Multi-Factor Authentication</div>
            
            <div class="mfa-info">
                <strong>HYPR MFA Required:</strong><br>
                Please complete the HYPR authentication challenge to proceed.
            </div>

            <div class="form-group">
                <label for="mfaUser">Verified User:</label>
                <input type="text" id="mfaUser" readonly>
            </div>

            <button id="hyprAuthBtn" class="btn btn-hypr">Authenticate with HYPR</button>
            <button id="backToLoginBtn" class="btn" style="background-color: #6c757d;">Back to Login</button>
            
            <div class="loading" id="mfaLoading">
                <div class="spinner"></div>
                <p>Processing HYPR MFA...</p>
            </div>
            
            <div id="mfaErrorMessage" class="error"></div>
            <div id="mfaSuccessMessage" class="success"></div>
        </div>

        <!-- Dashboard (Hidden initially) -->
        <div id="dashboard" class="dashboard">
            <h1>Strata Identity Dashboard</h1>
            
            <div class="welcome-message">
                Welcome back, <span id="welcomeUser"></span>!
            </div>

            <div class="user-info">
                <strong>User Information:</strong><br>
                Username: <span id="userInfoName"></span><br>
                Login Time: <span id="loginTime"></span><br>
                Session ID: <span id="sessionId"></span><br>
                Authentication: Microsoft Entra + HYPR MFA
            </div>

            <div class="dashboard-content">
                <div class="feature-box">
                    <h3>🔐 Identity Management</h3>
                    <p>Manage your identity and access controls through Strata Identity.</p>
                </div>

                <div class="feature-box">
                    <h3>📊 Analytics</h3>
                    <p>View your application analytics and access reports.</p>
                </div>

                <div class="feature-box">
                    <h3>⚙️ Settings</h3>
                    <p>Manage your account settings and preferences.</p>
                </div>

                <div class="feature-box">
                    <h3>🔒 Security</h3>
                    <p>Review security settings and access logs with enhanced MFA protection.</p>
                </div>
            </div>

            <div class="current-time">
                Current Time: <span id="currentTime"></span>
            </div>

            <button id="logoutBtn" class="btn btn-logout">Logout</button>
        </div>
    </div>

    <script>
        // DOM elements
        const loginForm = document.getElementById('loginForm');
        const mfaForm = document.getElementById('mfaForm');
        const dashboard = document.getElementById('dashboard');
        const loginFormElement = document.getElementById('loginFormElement');
        const usernameInput = document.getElementById('username');
        const passwordInput = document.getElementById('password');
        const mfaUser = document.getElementById('mfaUser');
        const errorMessage = document.getElementById('errorMessage');
        const successMessage = document.getElementById('successMessage');
        const mfaErrorMessage = document.getElementById('mfaErrorMessage');
        const mfaSuccessMessage = document.getElementById('mfaSuccessMessage');
        const loading = document.getElementById('loading');
        const mfaLoading = document.getElementById('mfaLoading');
        const hyprAuthBtn = document.getElementById('hyprAuthBtn');
        const backToLoginBtn = document.getElementById('backToLoginBtn');
        const logoutBtn = document.getElementById('logoutBtn');
        const welcomeUser = document.getElementById('welcomeUser');
        const userInfoName = document.getElementById('userInfoName');
        const loginTime = document.getElementById('loginTime');
        const sessionId = document.getElementById('sessionId');
        const currentTime = document.getElementById('currentTime');

        // Current user session
        let currentUser = null;
        let currentSessionId = null;
        let tempAuthData = null;

        // Show error message
        function showError(message, isMfa = false) {
            const errorEl = isMfa ? mfaErrorMessage : errorMessage;
            const successEl = isMfa ? mfaSuccessMessage : successMessage;
            const loadingEl = isMfa ? mfaLoading : loading;
            
            errorEl.textContent = message;
            successEl.textContent = '';
            loadingEl.style.display = 'none';
            setTimeout(() => {
                errorEl.textContent = '';
            }, 5000);
        }

        // Show success message
        function showSuccess(message, isMfa = false) {
            const errorEl = isMfa ? mfaErrorMessage : errorMessage;
            const successEl = isMfa ? mfaSuccessMessage : successMessage;
            const loadingEl = isMfa ? mfaLoading : loading;
            
            successEl.textContent = message;
            errorEl.textContent = '';
            loadingEl.style.display = 'none';
        }

        // Show loading
        function showLoading(isMfa = false) {
            const loadingEl = isMfa ? mfaLoading : loading;
            const errorEl = isMfa ? mfaErrorMessage : errorMessage;
            const successEl = isMfa ? mfaSuccessMessage : successMessage;
            
            loadingEl.style.display = 'block';
            errorEl.textContent = '';
            successEl.textContent = '';
        }

        // Show MFA form
        function showMfaForm(username) {
            loginForm.style.display = 'none';
            mfaForm.style.display = 'block';
            dashboard.style.display = 'none';
            
            mfaUser.value = username;
        }

        // Show dashboard
        function showDashboard(username, sessionId, loginTime) {
            loginForm.style.display = 'none';
            mfaForm.style.display = 'none';
            dashboard.style.display = 'block';
            
            welcomeUser.textContent = username;
            userInfoName.textContent = username;
            loginTime.textContent = loginTime;
            sessionId.textContent = sessionId;
            
            updateCurrentTime();
            setInterval(updateCurrentTime, 1000);
        }

        // Show login form
        function showLoginForm() {
            loginForm.style.display = 'block';
            mfaForm.style.display = 'none';
            dashboard.style.display = 'none';
            
            // Clear forms
            usernameInput.value = '';
            passwordInput.value = '';
            mfaUser.value = '';
            errorMessage.textContent = '';
            successMessage.textContent = '';
            mfaErrorMessage.textContent = '';
            mfaSuccessMessage.textContent = '';
            loading.style.display = 'none';
            mfaLoading.style.display = 'none';
            tempAuthData = null;
        }

        // Update current time display
        function updateCurrentTime() {
            const now = new Date();
            currentTime.textContent = now.toLocaleString();
        }

        // Handle login form submission (Step 1: Entra ID)
        loginFormElement.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const username = usernameInput.value.trim();
            const password = passwordInput.value;

            if (!username || !password) {
                showError('Please enter both username and password');
                return;
            }

            showLoading();

            try {
                const response = await fetch('/auth', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    credentials: 'include',
                    body: JSON.stringify({
                        username: username,
                        password: password,
                        step: 'entra'
                    })
                });

                const data = await response.json();

                if (data.success) {
                    tempAuthData = data;
                    showSuccess('Microsoft Entra authentication successful! Proceeding to MFA...');
                    
                    setTimeout(() => {
                        showMfaForm(data.username);
                    }, 1000);
                } else {
                    showError(data.error || 'Microsoft Entra authentication failed');
                }
            } catch (error) {
                showError('Network error. Please try again.');
                console.error('Login error:', error);
            }
        });

        // Handle HYPR MFA authentication (Step 2)
        hyprAuthBtn.addEventListener('click', async function() {
            if (!tempAuthData) {
                showError('Session expired. Please start over.', true);
                showLoginForm();
                return;
            }

            showLoading(true);

            try {
                const response = await fetch('/mfa', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    credentials: 'include',
                    body: JSON.stringify({
                        username: tempAuthData.username,
                        temp_session: tempAuthData.temp_session,
                        step: 'hypr'
                    })
                });

                const data = await response.json();

                if (data.success) {
                    currentUser = data.username;
                    currentSessionId = data.session_id;
                    
                    showSuccess('HYPR MFA verification successful!', true);
                    
                    setTimeout(() => {
                        showDashboard(data.username, data.session_id, data.login_time);
                    }, 1000);
                } else {
                    showError(data.error || 'HYPR MFA verification failed', true);
                }
            } catch (error) {
                showError('MFA verification error. Please try again.', true);
                console.error('MFA error:', error);
            }
        });

        // Back to login button
        backToLoginBtn.addEventListener('click', function() {
            showLoginForm();
        });

        // Handle logout
        logoutBtn.addEventListener('click', async function() {
            try {
                const response = await fetch('/logout', {
                    method: 'POST',
                    credentials: 'include'
                });
                
                const data = await response.json();
                
                if (data.success) {
                    currentUser = null;
                    currentSessionId = null;
                    showLoginForm();
                }
            } catch (error) {
                console.error('Logout error:', error);
                showLoginForm();
            }
        });

        // Auto-focus username field
        usernameInput.focus();

        // Handle Enter key on password field
        passwordInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                loginFormElement.dispatchEvent(new Event('submit'));
            }
        });

        // Check for existing session on page load
        async function checkExistingSession() {
            try {
                const response = await fetch('/session', {
                    method: 'GET',
                    credentials: 'include'
                });
                
                const data = await response.json();
                
                if (data.valid && data.mfa_verified) {
                    currentUser = data.username;
                    currentSessionId = data.sessionId;
                    showDashboard(data.username, data.sessionId, data.loginTime);
                }
            } catch (error) {
                console.log('No existing session found');
            }
        }

        checkExistingSession();
    </script>
</body>
</html>`

// IsAuthenticated checks if the current session is authenticated by both Microsoft Entra and HYPR MFA
func IsAuthenticated(api orchestrator.Orchestrator, _ http.ResponseWriter, _ *http.Request) bool {
	logger := api.Logger()
	logger.Debug("se", "determining if user is authenticated via Microsoft Entra + HYPR MFA")

	session, err := api.Session()
	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		return false
	}

	// Check Microsoft Entra authentication
	isEntraAuth, err := session.GetString("entra.authenticated")
	if err != nil {
		logger.Error("se", "unable to retrieve Entra auth status", "error", err.Error())
		return false
	}
	if isEntraAuth != "true" {
		logger.Debug("se", "user not authenticated via Microsoft Entra")
		return false
	}

	// Check HYPR MFA authentication
	isHyprAuth, err := session.GetString("hypr.authenticated")
	if err != nil {
		logger.Error("se", "unable to retrieve HYPR auth status", "error", err.Error())
		return false
	}
	if isHyprAuth != "true" {
		logger.Debug("se", "user not authenticated via HYPR MFA")
		return false
	}

	logger.Debug("se", "user is fully authenticated via Microsoft Entra + HYPR MFA")
	return true
}

// Authenticate serves the login page and handles both Microsoft Entra and HYPR MFA authentication
func Authenticate(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	logger.Debug("se", "serving Microsoft Entra + HYPR MFA login page")

	// Check if this is a POST request for authentication
	if req.Method == "POST" && req.URL.Path == "/auth" {
		handleEntraAuthentication(api, rw, req)
		return
	}

	// Check if this is a POST request for MFA
	if req.Method == "POST" && req.URL.Path == "/mfa" {
		handleHyprMFA(api, rw, req)
		return
	}

	// Serve the login page
	rw.Header().Set("Content-Type", "text/html; charset=utf-8")
	rw.WriteHeader(http.StatusOK)
	rw.Write([]byte(loginPageHTML))
}

// handleEntraAuthentication processes the Microsoft Entra authentication request (Step 1)
func handleEntraAuthentication(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	logger.Debug("se", "processing Microsoft Entra authentication")

	var authRequest struct {
		Username string `json:"username"`
		Password string `json:"password"`
		Step     string `json:"step"`
	}

	if err := json.NewDecoder(req.Body).Decode(&authRequest); err != nil {
		logger.Error("se", "failed to decode request body", "error", err.Error())
		http.Error(rw, "Invalid request format", http.StatusBadRequest)
		return
	}

	if authRequest.Username == "" || authRequest.Password == "" {
		logger.Error("se", "missing username or password")
		respondWithJSON(rw, http.StatusBadRequest, map[string]interface{}{
			"success": false,
			"error":   "Username and password are required",
		})
		return
	}

	// Authenticate with Microsoft Entra
	accessToken, err := authenticateWithMicrosoftEntra(api, authRequest.Username, authRequest.Password)
	if err != nil {
		logger.Error("se", "Microsoft Entra authentication failed", "username", authRequest.Username, "error", err.Error())
		respondWithJSON(rw, http.StatusUnauthorized, map[string]interface{}{
			"success": false,
			"error":   "Invalid username or password",
		})
		return
	}

	// Get session and store temporary authentication data
	session, err := api.Session()
	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		http.Error(rw, "Session error", http.StatusInternalServerError)
		return
	}

	// Store authentication data in session
	err = session.SetString("entra.temp_authenticated", "true")
	if err != nil {
		logger.Error("se", "unable to set session value", "error", err.Error())
		http.Error(rw, "Session error", http.StatusInternalServerError)
		return
	}
	err = session.SetString("entra.username", authRequest.Username)
	if err != nil {
		logger.Error("se", "unable to set session value", "error", err.Error())
		http.Error(rw, "Session error", http.StatusInternalServerError)
		return
	}
	err = session.SetString("entra.access_token", accessToken)
	if err != nil {
		logger.Error("se", "unable to set session value", "error", err.Error())
		http.Error(rw, "Session error", http.StatusInternalServerError)
		return
	}
	err = session.SetString("entra.login_time", time.Now().Format(time.RFC3339))
	if err != nil {
		logger.Error("se", "unable to set session value", "error", err.Error())
		http.Error(rw, "Session error", http.StatusInternalServerError)
		return
	}
	tempSession := generateSessionID()
	err = session.SetString("entra.temp_session", tempSession)
	if err != nil {
		logger.Error("se", "unable to set session value", "error", err.Error())
		http.Error(rw, "Session error", http.StatusInternalServerError)
		return
	}

	if err := session.Save(); err != nil {
		logger.Error("se", "unable to save session", "error", err.Error())
		http.Error(rw, "Session save error", http.StatusInternalServerError)
		return
	}

	logger.Debug("se", "Microsoft Entra authentication successful, proceeding to MFA", "username", authRequest.Username)

	respondWithJSON(rw, http.StatusOK, map[string]interface{}{
		"success":      true,
		"username":     authRequest.Username,
		"temp_session": tempSession,
		"message":      "Microsoft Entra authentication successful. MFA required.",
		"requires_mfa": true,
	})
}

// handleHyprMFA processes the HYPR MFA authentication request (Step 2)
func handleHyprMFA(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	logger.Debug("se", "processing HYPR MFA authentication")

	var mfaRequest struct {
		Username    string `json:"username"`
		TempSession string `json:"temp_session"`
		Step        string `json:"step"`
	}

	if err := json.NewDecoder(req.Body).Decode(&mfaRequest); err != nil {
		logger.Error("se", "failed to decode MFA request body", "error", err.Error())
		http.Error(rw, "Invalid request format", http.StatusBadRequest)
		return
	}

	// Get session and validate temporary authentication
	session, err := api.Session()
	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		http.Error(rw, "Session error", http.StatusInternalServerError)
		return
	}

	// Validate temporary session
	tempAuth, err := session.GetString("entra.temp_authenticated")
	if err != nil {
		logger.Error("se", "unable to retrieve temp auth status", "error", err.Error())
		respondWithJSON(rw, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"error":   "Session error",
		})
		return
	}
	tempSession, err := session.GetString("entra.temp_session")
	if err != nil {
		logger.Error("se", "unable to retrieve temp session", "error", err.Error())
		respondWithJSON(rw, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"error":   "Session error",
		})
		return
	}
	storedUsername, err := session.GetString("entra.username")
	if err != nil {
		logger.Error("se", "unable to retrieve stored username", "error", err.Error())
		respondWithJSON(rw, http.StatusInternalServerError, map[string]interface{}{
			"success": false,
			"error":   "Session error",
		})
		return
	}

	if tempAuth != "true" || tempSession != mfaRequest.TempSession || storedUsername != mfaRequest.Username {
		logger.Error("se", "invalid temporary session or username mismatch")
		respondWithJSON(rw, http.StatusUnauthorized, map[string]interface{}{
			"success": false,
			"error":   "Invalid session. Please start over.",
		})
		return
	}

	// Authenticate with HYPR
	err = authenticateWithHypr(api, mfaRequest.Username)
	if err != nil {
		logger.Error("se", "HYPR MFA authentication failed", "username", mfaRequest.Username, "error", err.Error())
		respondWithJSON(rw, http.StatusUnauthorized, map[string]interface{}{
			"success": false,
			"error":   "HYPR MFA verification failed",
		})
		return
	}

	// Complete authentication - set final session data
	err = session.SetString("entra.authenticated", "true")
	if err != nil {
		logger.Error("se", "unable to set entra auth", "error", err.Error())
	}
	err = session.SetString("hypr.authenticated", "true")
	if err != nil {
		logger.Error("se", "unable to set hypr auth", "error", err.Error())
	}
	sessionID := generateSessionID()
	err = session.SetString("session_id", sessionID)
	if err != nil {
		logger.Error("se", "unable to set session id", "error", err.Error())
	}
	err = session.SetString("login_time", time.Now().Format(time.RFC3339))
	if err != nil {
		logger.Error("se", "unable to set login time", "error", err.Error())
	}

	// Clean up temporary session data
	session.SetString("entra.temp_authenticated", "")
	session.SetString("entra.temp_session", "")

	if err := session.Save(); err != nil {
		logger.Error("se", "unable to save final session", "error", err.Error())
		http.Error(rw, "Session save error", http.StatusInternalServerError)
		return
	}

	logger.Debug("se", "user fully authenticated via Microsoft Entra + HYPR MFA", "username", mfaRequest.Username)

	respondWithJSON(rw, http.StatusOK, map[string]interface{}{
		"success":    true,
		"username":   mfaRequest.Username,
		"session_id": sessionID,
		"login_time": time.Now().Format(time.RFC3339),
		"message":    "Authentication successful!",
	})
}

// authenticateWithMicrosoftEntra performs OAuth2 Resource Owner Password Credentials flow
func authenticateWithMicrosoftEntra(api orchestrator.Orchestrator, username, password string) (string, error) {
	logger := api.Logger()
	logger.Debug("se", "authenticating with Microsoft Entra", "username", username)

	secretProvider, err := api.SecretProvider()
	if err != nil {
		logger.Error("se", "failed to get secret provider", "error", err.Error())
		return "", fmt.Errorf("failed to retrieve secret provider: %w", err)
	}

	clientID, err := secretProvider.GetString("AZURE_CLIENT_ID", err)
	if err != nil {
		return "", fmt.Errorf("failed to get AZURE_CLIENT_ID: %w", err)
	}
	if clientID == "" {
		return "", fmt.Errorf("AZURE_CLIENT_ID not found or empty")
	}
	
	clientSecret, err := secretProvider.GetString("AZURE_CLIENT_SECRET", err)
	if err != nil {
		return "", fmt.Errorf("failed to get AZURE_CLIENT_SECRET: %w", err)
	}
	if clientSecret == "" {
		return "", fmt.Errorf("AZURE_CLIENT_SECRET not found or empty")
	}
	
	tenantID, err := secretProvider.GetString("AZURE_TENANT_ID", err)
	if err != nil {
		return "", fmt.Errorf("failed to get AZURE_TENANT_ID: %w", err)
	}
	if tenantID == "" {
		return "", fmt.Errorf("AZURE_TENANT_ID not found or empty")
	}

	tokenURL := fmt.Sprintf("https://login.microsoftonline.com/%s/oauth2/v2.0/token", tenantID)

	data := url.Values{}
	data.Set("grant_type", "password")
	data.Set("client_id", clientID)
	data.Set("client_secret", clientSecret)
	data.Set("username", username)
	data.Set("password", password)
	data.Set("scope", "https://graph.microsoft.com/.default")

	req, err := http.NewRequest("POST", tokenURL, strings.NewReader(data.Encode()))
	if err != nil {
		return "", fmt.Errorf("failed to create request: %w", err)
	}

	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")

	client := &http.Client{
		Timeout: 30 * time.Second,
		Transport: &http.Transport{
			TLSClientConfig: &tls.Config{InsecureSkipVerify: false},
		},
	}

	resp, err := client.Do(req)
	if err != nil {
		return "", fmt.Errorf("request failed: %w", err)
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", fmt.Errorf("failed to read response: %w", err)
	}

	if resp.StatusCode != http.StatusOK {
		return "", fmt.Errorf("authentication failed: %s", string(body))
	}

	var tokenResponse EntraAuthResponse
	if err := json.Unmarshal(body, &tokenResponse); err != nil {
		return "", fmt.Errorf("failed to parse response: %w", err)
	}

	return tokenResponse.AccessToken, nil
}

// authenticateWithHypr performs HYPR MFA authentication by forcing the authentication flow
func authenticateWithHypr(api orchestrator.Orchestrator, username string) error {
	logger := api.Logger()
	logger.Debug("se", "authenticating with HYPR MFA", "username", username)

	// Get HYPR Identity Provider
	hyprIDP, err := api.IdentityProvider("hypr")
	if err != nil {
		logger.Error("se", "failed to retrieve HYPR IDP", "error", err.Error())
		return fmt.Errorf("failed to retrieve HYPR IDP: %w", err)
	}

	// Create a temporary HTTP request for HYPR authentication
	// This is needed because HYPR IDP expects an HTTP request/response context
	req, err := http.NewRequest("POST", "/mfa", nil)
	if err != nil {
		logger.Error("se", "failed to create HYPR request", "error", err.Error())
		return fmt.Errorf("failed to create HYPR request: %w", err)
	}

	// Add username to request context
	req.Header.Set("X-Username", username)

	// Create a response recorder to capture HYPR response
	rw := &responseRecorder{
		statusCode: 200,
		headers:    make(http.Header),
		body:       make([]byte, 0),
	}

	// Trigger HYPR authentication flow
	// This will initiate the HYPR MFA challenge (push notification, biometric, etc.)
	hyprIDP.Login(rw, req)

	// Check if HYPR authentication was successful
	if rw.statusCode != http.StatusOK && rw.statusCode != http.StatusFound {
		logger.Error("se", "HYPR MFA authentication failed", "username", username, "status", rw.statusCode)
		return fmt.Errorf("HYPR MFA authentication failed with status %d", rw.statusCode)
	}

	logger.Debug("se", "HYPR MFA authentication successful", "username", username)
	return nil
}

// responseRecorder is a simple HTTP response recorder for capturing HYPR IDP responses
type responseRecorder struct {
	statusCode int
	headers    http.Header
	body       []byte
}

func (r *responseRecorder) Header() http.Header {
	return r.headers
}

func (r *responseRecorder) Write(data []byte) (int, error) {
	r.body = append(r.body, data...)
	return len(data), nil
}

func (r *responseRecorder) WriteHeader(statusCode int) {
	r.statusCode = statusCode
}

// generateSessionID creates a unique session identifier
func generateSessionID() string {
	return fmt.Sprintf("entra_hypr_sess_%d", time.Now().UnixNano())
}

// respondWithJSON sends a JSON response
func respondWithJSON(w http.ResponseWriter, statusCode int, response interface{}) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(statusCode)
	json.NewEncoder(w).Encode(response)
}

// LoadAttributes loads user attributes from both Microsoft Entra and HYPR and stores them in session
func LoadAttributes(api orchestrator.Orchestrator, _ http.ResponseWriter, _ *http.Request) error {
	logger := api.Logger()
	logger.Debug("se", "loading attributes from Microsoft Entra and HYPR")

	session, err := api.Session()
	if err != nil {
		return fmt.Errorf("unable to retrieve session: %w", err)
	}

	username, err := session.GetString("entra.username")
	if err != nil {
		return fmt.Errorf("unable to retrieve username from session: %w", err)
	}
	accessToken, err := session.GetString("entra.access_token")
	if err != nil {
		return fmt.Errorf("unable to retrieve access token from session: %w", err)
	}

	if username == "" || accessToken == "" {
		return fmt.Errorf("missing authentication data in session")
	}

	// Store additional attributes in session
	err = session.SetString("entra.email", username)
	if err != nil {
		logger.Error("se", "unable to set email", "error", err.Error())
	}
	err = session.SetString("entra.provider", "microsoft-entra")
	if err != nil {
		logger.Error("se", "unable to set entra provider", "error", err.Error())
	}
	err = session.SetString("hypr.provider", "hypr-mfa")
	if err != nil {
		logger.Error("se", "unable to set hypr provider", "error", err.Error())
	}
	err = session.SetString("auth.method", "entra-hypr-mfa")
	if err != nil {
		logger.Error("se", "unable to set auth method", "error", err.Error())
	}
	err = session.SetString("entra.tenant_id", "3ef4def4-c2c7-4c38-8bea-b9324ddf9241")
	if err != nil {
		logger.Error("se", "unable to set tenant id", "error", err.Error())
	}

	if err := session.Save(); err != nil {
		return fmt.Errorf("unable to save session: %w", err)
	}

	logger.Debug("se", "attributes loaded successfully", "username", username)
	return nil
}

// BuildAccessTokenClaims creates claims for access tokens
func BuildAccessTokenClaims(api orchestrator.Orchestrator, _ *http.Request) (map[string]any, error) {
	logger := api.Logger()
	logger.Debug("se", "building access token claims")

	session, err := api.Session()
	if err != nil {
		return nil, fmt.Errorf("unable to retrieve session: %w", err)
	}

	username, err := session.GetString("entra.username")
	if err != nil {
		return nil, fmt.Errorf("unable to retrieve username from session: %w", err)
	}
	email, err := session.GetString("entra.email")
	if err != nil {
		return nil, fmt.Errorf("unable to retrieve email from session: %w", err)
	}

	return map[string]any{
		"sub":         username,
		"email":       email,
		"iss":         "strata-entra-hypr-auth",
		"aud":         "application",
		"auth_method": "entra-hypr-mfa",
		"mfa":         true,
	}, nil
}

// BuildIDTokenClaims creates claims for ID tokens
func BuildIDTokenClaims(api orchestrator.Orchestrator, _ *http.Request) (map[string]any, error) {
	logger := api.Logger()
	logger.Debug("se", "building ID token claims")

	session, err := api.Session()
	if err != nil {
		return nil, fmt.Errorf("unable to retrieve session: %w", err)
	}

	username, err := session.GetString("entra.username")
	if err != nil {
		return nil, fmt.Errorf("unable to retrieve username from session: %w", err)
	}
	email, err := session.GetString("entra.email")
	if err != nil {
		return nil, fmt.Errorf("unable to retrieve email from session: %w", err)
	}
	authMethod, err := session.GetString("auth.method")
	if err != nil {
		return nil, fmt.Errorf("unable to retrieve auth method from session: %w", err)
	}

	return map[string]any{
		"sub":         username,
		"email":       email,
		"auth_method": authMethod,
		"iss":         "strata-entra-hypr-auth",
		"aud":         "application",
		"mfa":         true,
	}, nil
}