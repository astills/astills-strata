package main

import (
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"

	"github.com/strata-io/service-extension/orchestrator"
)

// Token response structures
type TokenResponse struct {
	AccessToken  string `json:"access_token"`
	TokenType    string `json:"token_type"`
	ExpiresIn    int    `json:"expires_in"`
	RefreshToken string `json:"refresh_token,omitempty"`
	IDToken      string `json:"id_token,omitempty"`
	Scope        string `json:"scope,omitempty"`
}

// ID Token claims structure
type IDTokenClaims struct {
	Sub               string `json:"sub"`
	Name              string `json:"name"`
	PreferredUsername string `json:"preferred_username"`
	Email             string `json:"email"`
	EmailVerified     bool   `json:"email_verified"`
}

// PKCE challenge structure
type PKCEChallenge struct {
	Verifier  string `json:"verifier"`
	Challenge string `json:"challenge"`
	Method    string `json:"method"`
}

// Error response structure
type ErrorResponse struct {
	Error            string `json:"error"`
	ErrorDescription string `json:"error_description"`
	ErrorCodes       []int  `json:"error_codes,omitempty"`
	Timestamp        string `json:"timestamp,omitempty"`
	TraceID          string `json:"trace_id,omitempty"`
	CorrelationID    string `json:"correlation_id,omitempty"`
}

// SessionResponse for /session endpoint
type SessionResponse struct {
	Valid     bool   `json:"valid"`
	Username  string `json:"username,omitempty"`
	SessionID string `json:"sessionId,omitempty"`
	LoginTime string `json:"loginTime,omitempty"`
}

// AuthResponse for /auth endpoint
type AuthResponse struct {
	Success   bool   `json:"success"`
	Username  string `json:"username,omitempty"`
	SessionID string `json:"session_id,omitempty"`
	LoginTime string `json:"login_time,omitempty"`
	Message   string `json:"message,omitempty"`
	Error     string `json:"error,omitempty"`
}

// Login page HTML with the provided form
const loginPageHTML = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Microsoft Entra Login</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f0f2f5;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .container {
            background: white;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
        }

        .login-form {
            display: block;
        }

        .dashboard {
            display: none;
            text-align: center;
        }

        h1 {
            color: #333;
            margin-bottom: 1.5rem;
            text-align: center;
        }

        .form-group {
            margin-bottom: 1rem;
        }

        label {
            display: block;
            margin-bottom: 0.5rem;
            color: #555;
            font-weight: bold;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 0.75rem;
            border: 2px solid #ddd;
            border-radius: 4px;
            font-size: 1rem;
        }

        input[type="text"]:focus,
        input[type="password"]:focus {
            outline: none;
            border-color: #4CAF50;
        }

        .btn {
            width: 100%;
            padding: 0.75rem;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 1rem;
            cursor: pointer;
            margin-top: 1rem;
        }

        .btn:hover {
            background-color: #45a049;
        }

        .btn-logout {
            background-color: #f44336;
            width: auto;
            padding: 0.5rem 1rem;
            margin-top: 1rem;
        }

        .btn-logout:hover {
            background-color: #da190b;
        }

        .error {
            color: #f44336;
            margin-top: 0.5rem;
            font-size: 0.9rem;
        }

        .success {
            color: #4CAF50;
            margin-top: 0.5rem;
            font-size: 0.9rem;
        }

        .demo-info {
            background-color: #e7f3ff;
            padding: 1rem;
            border-radius: 4px;
            margin-bottom: 1rem;
            font-size: 0.9rem;
            color: #333;
        }

        .welcome-message {
            color: #4CAF50;
            font-size: 1.2rem;
            margin-bottom: 1rem;
        }

        .dashboard-content {
            margin: 2rem 0;
        }

        .feature-box {
            background-color: #f9f9f9;
            padding: 1rem;
            margin: 1rem 0;
            border-radius: 4px;
            text-align: left;
        }

        .feature-box h3 {
            color: #333;
            margin-bottom: 0.5rem;
        }

        .user-info {
            background-color: #e8f5e8;
            padding: 1rem;
            border-radius: 4px;
            margin-bottom: 1rem;
        }

        .current-time {
            font-size: 0.9rem;
            color: #666;
            margin-top: 1rem;
        }

        .loading {
            display: none;
            text-align: center;
            margin-top: 1rem;
        }

        .spinner {
            border: 4px solid #f3f3f3;
            border-top: 4px solid #4CAF50;
            border-radius: 50%;
            width: 30px;
            height: 30px;
            animation: spin 1s linear infinite;
            margin: 0 auto;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Login Form -->
        <div id="loginForm" class="login-form">
            <h1>Microsoft Entra Login</h1>
            
            <div class="demo-info">
                <strong>Microsoft Entra Authentication:</strong><br>
                Click the button below to authenticate with your Microsoft account.<br>
                This service is integrated with Strata Identity.
            </div>

            <form id="loginFormElement">
                <button type="button" onclick="window.location.href='/login'" class="btn">Login with Microsoft Entra</button>
                
                <div id="errorMessage" class="error"></div>
                <div id="successMessage" class="success"></div>
            </form>
        </div>

        <!-- Dashboard (Hidden initially) -->
        <div id="dashboard" class="dashboard">
            <h1>Strata Identity Dashboard</h1>
            
            <div class="welcome-message">
                Welcome back, <span id="welcomeUser"></span>!
            </div>

            <div class="user-info">
                <strong>User Information:</strong><br>
                Username: <span id="userInfoName"></span><br>
                Login Time: <span id="loginTime"></span><br>
                Session ID: <span id="sessionId"></span><br>
                Authentication: Microsoft Entra
            </div>

            <div class="dashboard-content">
                <div class="feature-box">
                    <h3>🔐 Identity Management</h3>
                    <p>Manage your identity and access controls through Strata Identity.</p>
                </div>

                <div class="feature-box">
                    <h3>📊 Analytics</h3>
                    <p>View your application analytics and access reports.</p>
                </div>

                <div class="feature-box">
                    <h3>⚙️ Settings</h3>
                    <p>Manage your account settings and preferences.</p>
                </div>

                <div class="feature-box">
                    <h3>🔒 Security</h3>
                    <p>Review security settings and access logs.</p>
                </div>
            </div>

            <div class="current-time">
                Current Time: <span id="currentTime"></span>
            </div>

            <button id="logoutBtn" class="btn btn-logout">Logout</button>
        </div>
    </div>

    <script>
        // DOM elements
        const loginForm = document.getElementById('loginForm');
        const dashboard = document.getElementById('dashboard');
        const welcomeUser = document.getElementById('welcomeUser');
        const userInfoName = document.getElementById('userInfoName');
        const loginTime = document.getElementById('loginTime');
        const sessionId = document.getElementById('sessionId');
        const currentTime = document.getElementById('currentTime');
        const logoutBtn = document.getElementById('logoutBtn');

        // Current user session
        let currentUser = null;
        let currentSessionId = null;

        // Check if user is already logged in (from server session)
        async function checkExistingSession() {
            try {
                const response = await fetch('/session', {
                    method: 'GET',
                    credentials: 'include'
                });
                
                const data = await response.json();
                
                if (data.valid) {
                    currentUser = data.username;
                    currentSessionId = data.sessionId;
                    showDashboard(data.username, data.sessionId, data.loginTime);
                }
            } catch (error) {
                console.log('No existing session found');
            }
        }

        // Show dashboard
        function showDashboard(username, sessionIdValue, loginTimeValue) {
            loginForm.style.display = 'none';
            dashboard.style.display = 'block';
            
            welcomeUser.textContent = username;
            userInfoName.textContent = username;
            loginTime.textContent = loginTimeValue;
            sessionId.textContent = sessionIdValue;
            
            updateCurrentTime();
            // Update time every second
            setInterval(updateCurrentTime, 1000);
        }

        // Show login form
        function showLoginForm() {
            loginForm.style.display = 'block';
            dashboard.style.display = 'none';
        }

        // Update current time display
        function updateCurrentTime() {
            const now = new Date();
            currentTime.textContent = now.toLocaleString();
        }

        // Handle logout
        logoutBtn.addEventListener('click', async function() {
            try {
                const response = await fetch('/logout', {
                    method: 'POST',
                    credentials: 'include'
                });
                
                await response.json();
                
                currentUser = null;
                currentSessionId = null;
                showLoginForm();
            } catch (error) {
                console.error('Logout error:', error);
                // Still show login form even if logout fails
                currentUser = null;
                currentSessionId = null;
                showLoginForm();
            }
        });

        // Check for existing session on page load
        checkExistingSession();

        // Add some interactivity to feature boxes
        document.addEventListener('click', function(e) {
            if (e.target.closest('.feature-box')) {
                const featureBox = e.target.closest('.feature-box');
                const title = featureBox.querySelector('h3').textContent;
                alert('You clicked on: ' + title + '\n\nThis would normally navigate to that feature in Strata Identity.');
            }
        });
    </script>
</body>
</html>`

// IsAuthenticated checks if the current session is marked as authenticated
func IsAuthenticated(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) bool {
	logger := api.Logger()
	logger.Debug("se", "determining if user is authenticated via Microsoft Entra")

	session, err := api.Session()
	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		return false
	}

	isEntraAuth := session.GetString("entra.authenticated")
	username := session.GetString("entra.username")

	if isEntraAuth == "true" && username != "" {
		// For root paths, we want to handle the response ourselves to inject localStorage
		if req.URL.Path == "/" || req.URL.Path == "/index.html" {
			logger.Debug("se", "authenticated user accessing root, will inject credentials")
			// Return false so that Authenticate gets called to inject the credentials
			return false
		}
		
		// Ensure required attributes are set for Maverics
		smUser := session.GetString("SM_USER")
		if smUser == "" {
			// Load attributes if not already set
			sub := session.GetString("entra.sub")
			email := session.GetString("entra.email")
			name := session.GetString("entra.name")
			
			if email == "" {
				email = username
			}
			
			smUser = sub
			if smUser == "" {
				smUser = email
			}
			
			// Set the attributes Maverics needs
			session.SetString("SM_USER", smUser)
			session.SetString("email", email)
			session.SetString("sub", sub)
			session.SetString("mail", email)
			session.SetString("displayName", name)
			session.SetString("name", name)
			session.SetString("MSFT-EEID.SM_USER", smUser)
			session.SetString("MSFT-EEID.email", email)
			session.SetString("MSFT-EEID.sub", sub)
			session.Save()
			
			logger.Debug("se", "set missing attributes", "SM_USER", smUser, "email", email)
		}
		
		logger.Debug("se", "user is authenticated via Microsoft Entra", "username", username)
		return true
	}

	logger.Debug("se", "user is not authenticated via Microsoft Entra")
	return false
}

// Authenticate handles all authentication endpoints and serves the login page
func Authenticate(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()

	// Check if user is already authenticated
	session, err := api.Session()
	if err == nil {
		isEntraAuth := session.GetString("entra.authenticated")
		username := session.GetString("entra.username")
		sessionID := session.GetString("entra.session_id")
		loginTime := session.GetString("entra.login_time")
		
		// If authenticated and accessing main pages, inject localStorage credentials
		if isEntraAuth == "true" && username != "" && 
		   (req.URL.Path == "/" || req.URL.Path == "/index.html") {
			logger.Debug("se", "authenticated user accessing app, injecting localStorage credentials")
			
			// Generate session data if missing
			if sessionID == "" {
				sessionID = generateSessionID()
				session.SetString("entra.session_id", sessionID)
			}
			if loginTime == "" {
				loginTime = time.Now().Format("1/2/2006, 3:04:05 PM")
				session.SetString("entra.login_time", loginTime)
			}
			session.Save()
			
			// Inject the credentials into the page
			injectAuthenticatedPage(rw, username, sessionID, loginTime)
			return
		}
	}

	// Route to different handlers based on path
	switch req.URL.Path {
	case "/session":
		handleSessionCheck(api, rw, req)
		return
	case "/login":
		handleLogin(api, rw, req)
		return
	case "/auth/callback":
		handleOAuthCallback(api, rw, req)
		return
	case "/logout":
		handleLogout(api, rw, req)
		return
	default:
		// Check for OAuth callback parameters
		if req.URL.Query().Get("code") != "" || req.URL.Query().Get("error") != "" {
			handleOAuthCallback(api, rw, req)
			return
		}

		// Serve the login page
		serveLoginPage(api, rw, req)
	}
}

// serveLoginPage serves the HTML login form
func serveLoginPage(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	logger.Debug("se", "serving login page")
	
	rw.Header().Set("Content-Type", "text/html; charset=utf-8")
	rw.WriteHeader(http.StatusOK)
	rw.Write([]byte(loginPageHTML))
}

// serveOriginalApp serves the original application HTML without modification
func serveOriginalApp(rw http.ResponseWriter) {
	// This is the original index.html content from your application
	originalHTML := `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simple Login App</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f0f2f5;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .container {
            background: white;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
        }

        .login-form {
            display: block;
        }

        .dashboard {
            display: none;
            text-align: center;
        }

        h1 {
            color: #333;
            margin-bottom: 1.5rem;
            text-align: center;
        }

        .form-group {
            margin-bottom: 1rem;
        }

        label {
            display: block;
            margin-bottom: 0.5rem;
            color: #555;
            font-weight: bold;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 0.75rem;
            border: 2px solid #ddd;
            border-radius: 4px;
            font-size: 1rem;
        }

        input[type="text"]:focus,
        input[type="password"]:focus {
            outline: none;
            border-color: #4CAF50;
        }

        .btn {
            width: 100%;
            padding: 0.75rem;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 1rem;
            cursor: pointer;
            margin-top: 1rem;
        }

        .btn:hover {
            background-color: #45a049;
        }

        .btn-logout {
            background-color: #f44336;
            width: auto;
            padding: 0.5rem 1rem;
            margin-top: 1rem;
        }

        .btn-logout:hover {
            background-color: #da190b;
        }

        .error {
            color: #f44336;
            margin-top: 0.5rem;
            font-size: 0.9rem;
        }

        .success {
            color: #4CAF50;
            margin-top: 0.5rem;
            font-size: 0.9rem;
        }

        .demo-info {
            background-color: #e7f3ff;
            padding: 1rem;
            border-radius: 4px;
            margin-bottom: 1rem;
            font-size: 0.9rem;
            color: #333;
        }

        .welcome-message {
            color: #4CAF50;
            font-size: 1.2rem;
            margin-bottom: 1rem;
        }

        .dashboard-content {
            margin: 2rem 0;
        }

        .feature-box {
            background-color: #f9f9f9;
            padding: 1rem;
            margin: 1rem 0;
            border-radius: 4px;
            text-align: left;
        }

        .feature-box h3 {
            color: #333;
            margin-bottom: 0.5rem;
        }

        .user-info {
            background-color: #e8f5e8;
            padding: 1rem;
            border-radius: 4px;
            margin-bottom: 1rem;
        }

        .current-time {
            font-size: 0.9rem;
            color: #666;
            margin-top: 1rem;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Login Form -->
        <div id="loginForm" class="login-form">
            <h1>Login</h1>
            
            <div class="demo-info">
                <strong>Demo Credentials:</strong><br>
                Username: admin<br>
                Password: password
            </div>

            <form id="loginFormElement">
                <div class="form-group">
                    <label for="username">Username:</label>
                    <input type="text" id="username" name="username" required>
                </div>

                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" id="password" name="password" required>
                </div>

                <button type="submit" class="btn">Login</button>
                
                <div id="errorMessage" class="error"></div>
                <div id="successMessage" class="success"></div>
            </form>
        </div>

        <!-- Dashboard (Hidden initially) -->
        <div id="dashboard" class="dashboard">
            <h1>Dashboard</h1>
            
            <div class="welcome-message">
                Welcome back, <span id="welcomeUser"></span>!
            </div>

            <div class="user-info">
                <strong>User Information:</strong><br>
                Username: <span id="userInfoName"></span><br>
                Login Time: <span id="loginTime"></span><br>
                Session ID: <span id="sessionId"></span>
            </div>

            <div class="dashboard-content">
                <div class="feature-box">
                    <h3>📊 Analytics</h3>
                    <p>View your application analytics and reports here.</p>
                </div>

                <div class="feature-box">
                    <h3>⚙️ Settings</h3>
                    <p>Manage your account settings and preferences.</p>
                </div>

                <div class="feature-box">
                    <h3>📨 Messages</h3>
                    <p>Check your messages and notifications.</p>
                </div>

                <div class="feature-box">
                    <h3>👥 Users</h3>
                    <p>Manage users and permissions in your system.</p>
                </div>
            </div>

            <div class="current-time">
                Current Time: <span id="currentTime"></span>
            </div>

            <button id="logoutBtn" class="btn btn-logout">Logout</button>
        </div>
    </div>

    <script>
        // Demo user credentials
        const validUsers = {
            'admin': 'password',
            'user': '123456',
            'demo': 'demo'
        };

        // DOM elements
        const loginForm = document.getElementById('loginForm');
        const dashboard = document.getElementById('dashboard');
        const loginFormElement = document.getElementById('loginFormElement');
        const usernameInput = document.getElementById('username');
        const passwordInput = document.getElementById('password');
        const errorMessage = document.getElementById('errorMessage');
        const successMessage = document.getElementById('successMessage');
        const logoutBtn = document.getElementById('logoutBtn');
        const welcomeUser = document.getElementById('welcomeUser');
        const userInfoName = document.getElementById('userInfoName');
        const loginTime = document.getElementById('loginTime');
        const sessionId = document.getElementById('sessionId');
        const currentTime = document.getElementById('currentTime');

        // Current user session
        let currentUser = null;
        let currentSessionId = null;

        // Check if user is already logged in (from localStorage)
        function checkExistingSession() {
            const savedUser = localStorage.getItem('currentUser');
            const savedSessionId = localStorage.getItem('sessionId');
            const savedLoginTime = localStorage.getItem('loginTime');

            if (savedUser && savedSessionId) {
                currentUser = savedUser;
                currentSessionId = savedSessionId;
                showDashboard(savedUser, savedSessionId, savedLoginTime);
            }
        }

        // Show error message
        function showError(message) {
            errorMessage.textContent = message;
            successMessage.textContent = '';
            setTimeout(() => {
                errorMessage.textContent = '';
            }, 3000);
        }

        // Show success message
        function showSuccess(message) {
            successMessage.textContent = message;
            errorMessage.textContent = '';
        }

        // Generate random session ID
        function generateSessionId() {
            return 'sess_' + Math.random().toString(36).substr(2, 9);
        }

        // Show dashboard
        function showDashboard(username, sessionIdValue, loginTimeValue) {
            loginForm.style.display = 'none';
            dashboard.style.display = 'block';
            
            welcomeUser.textContent = username;
            userInfoName.textContent = username;
            loginTime.textContent = loginTimeValue;
            sessionId.textContent = sessionIdValue;
            
            updateCurrentTime();
            // Update time every second
            setInterval(updateCurrentTime, 1000);
        }

        // Show login form
        function showLoginForm() {
            loginForm.style.display = 'block';
            dashboard.style.display = 'none';
            
            // Clear form
            usernameInput.value = '';
            passwordInput.value = '';
            errorMessage.textContent = '';
            successMessage.textContent = '';
        }

        // Update current time display
        function updateCurrentTime() {
            const now = new Date();
            currentTime.textContent = now.toLocaleString();
        }

        // Handle login form submission
        loginFormElement.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const username = usernameInput.value.trim();
            const password = passwordInput.value;

            // Validate credentials
            if (!username || !password) {
                showError('Please enter both username and password');
                return;
            }

            // Check against valid users
            if (validUsers[username] && validUsers[username] === password) {
                // Successful login
                currentUser = username;
                currentSessionId = generateSessionId();
                const loginTimeStr = new Date().toLocaleString();
                
                // Save to localStorage
                localStorage.setItem('currentUser', username);
                localStorage.setItem('sessionId', currentSessionId);
                localStorage.setItem('loginTime', loginTimeStr);
                
                showSuccess('Login successful! Redirecting...');
                
                setTimeout(() => {
                    showDashboard(username, currentSessionId, loginTimeStr);
                }, 1000);
            } else {
                showError('Invalid username or password');
            }
        });

        // Handle logout
        logoutBtn.addEventListener('click', function() {
            // Clear session data
            localStorage.removeItem('currentUser');
            localStorage.removeItem('sessionId');
            localStorage.removeItem('loginTime');
            
            currentUser = null;
            currentSessionId = null;
            
            showLoginForm();
        });

        // Auto-focus username field
        usernameInput.focus();

        // Check for existing session on page load
        checkExistingSession();

        // Handle Enter key on password field
        passwordInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                loginFormElement.dispatchEvent(new Event('submit'));
            }
        });

        // Add some interactivity to feature boxes
        document.addEventListener('click', function(e) {
            if (e.target.closest('.feature-box')) {
                const featureBox = e.target.closest('.feature-box');
                const title = featureBox.querySelector('h3').textContent;
                alert('You clicked on: ' + title + '\n\nThis would normally navigate to that feature.');
            }
        });
    </script>
</body>
</html>`
	
	rw.Header().Set("Content-Type", "text/html; charset=utf-8")
	rw.WriteHeader(http.StatusOK)
	rw.Write([]byte(originalHTML))
}

// serveAuthenticatedApp serves the app with localStorage values injected
func serveAuthenticatedApp(rw http.ResponseWriter, username, sessionID, loginTime string) {
	// Extract just the username part from email if needed
	displayName := extractUsernameFromEmail(username)
	
	// Inject a script at the very beginning to set localStorage before the app loads
	injectionScript := fmt.Sprintf(`
    <script>
        // Inject authentication from Microsoft Entra
        (function() {
            localStorage.setItem('currentUser', '%s');
            localStorage.setItem('sessionId', '%s');
            localStorage.setItem('loginTime', '%s');
            console.log('Injected auth for user: %s');
        })();
    </script>`, displayName, sessionID, loginTime, displayName)
	
	// Get the original HTML and inject our script right after <head>
	originalHTML := `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simple Login App</title>` + injectionScript + `
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f0f2f5;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .container {
            background: white;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
        }

        .login-form {
            display: block;
        }

        .dashboard {
            display: none;
            text-align: center;
        }

        h1 {
            color: #333;
            margin-bottom: 1.5rem;
            text-align: center;
        }

        .form-group {
            margin-bottom: 1rem;
        }

        label {
            display: block;
            margin-bottom: 0.5rem;
            color: #555;
            font-weight: bold;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 0.75rem;
            border: 2px solid #ddd;
            border-radius: 4px;
            font-size: 1rem;
        }

        input[type="text"]:focus,
        input[type="password"]:focus {
            outline: none;
            border-color: #4CAF50;
        }

        .btn {
            width: 100%;
            padding: 0.75rem;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 1rem;
            cursor: pointer;
            margin-top: 1rem;
        }

        .btn:hover {
            background-color: #45a049;
        }

        .btn-logout {
            background-color: #f44336;
            width: auto;
            padding: 0.5rem 1rem;
            margin-top: 1rem;
        }

        .btn-logout:hover {
            background-color: #da190b;
        }

        .error {
            color: #f44336;
            margin-top: 0.5rem;
            font-size: 0.9rem;
        }

        .success {
            color: #4CAF50;
            margin-top: 0.5rem;
            font-size: 0.9rem;
        }

        .demo-info {
            background-color: #e7f3ff;
            padding: 1rem;
            border-radius: 4px;
            margin-bottom: 1rem;
            font-size: 0.9rem;
            color: #333;
        }

        .welcome-message {
            color: #4CAF50;
            font-size: 1.2rem;
            margin-bottom: 1rem;
        }

        .dashboard-content {
            margin: 2rem 0;
        }

        .feature-box {
            background-color: #f9f9f9;
            padding: 1rem;
            margin: 1rem 0;
            border-radius: 4px;
            text-align: left;
        }

        .feature-box h3 {
            color: #333;
            margin-bottom: 0.5rem;
        }

        .user-info {
            background-color: #e8f5e8;
            padding: 1rem;
            border-radius: 4px;
            margin-bottom: 1rem;
        }

        .current-time {
            font-size: 0.9rem;
            color: #666;
            margin-top: 1rem;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Login Form -->
        <div id="loginForm" class="login-form">
            <h1>Login</h1>
            
            <div class="demo-info">
                <strong>Demo Credentials:</strong><br>
                Username: admin<br>
                Password: password
            </div>

            <form id="loginFormElement">
                <div class="form-group">
                    <label for="username">Username:</label>
                    <input type="text" id="username" name="username" required>
                </div>

                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" id="password" name="password" required>
                </div>

                <button type="submit" class="btn">Login</button>
                
                <div id="errorMessage" class="error"></div>
                <div id="successMessage" class="success"></div>
            </form>
        </div>

        <!-- Dashboard (Hidden initially) -->
        <div id="dashboard" class="dashboard">
            <h1>Dashboard</h1>
            
            <div class="welcome-message">
                Welcome back, <span id="welcomeUser"></span>!
            </div>

            <div class="user-info">
                <strong>User Information:</strong><br>
                Username: <span id="userInfoName"></span><br>
                Login Time: <span id="loginTime"></span><br>
                Session ID: <span id="sessionId"></span>
            </div>

            <div class="dashboard-content">
                <div class="feature-box">
                    <h3>📊 Analytics</h3>
                    <p>View your application analytics and reports here.</p>
                </div>

                <div class="feature-box">
                    <h3>⚙️ Settings</h3>
                    <p>Manage your account settings and preferences.</p>
                </div>

                <div class="feature-box">
                    <h3>📨 Messages</h3>
                    <p>Check your messages and notifications.</p>
                </div>

                <div class="feature-box">
                    <h3>👥 Users</h3>
                    <p>Manage users and permissions in your system.</p>
                </div>
            </div>

            <div class="current-time">
                Current Time: <span id="currentTime"></span>
            </div>

            <button id="logoutBtn" class="btn btn-logout">Logout</button>
        </div>
    </div>

    <script>
        // Demo user credentials
        const validUsers = {
            'admin': 'password',
            'user': '123456',
            'demo': 'demo'
        };

        // DOM elements
        const loginForm = document.getElementById('loginForm');
        const dashboard = document.getElementById('dashboard');
        const loginFormElement = document.getElementById('loginFormElement');
        const usernameInput = document.getElementById('username');
        const passwordInput = document.getElementById('password');
        const errorMessage = document.getElementById('errorMessage');
        const successMessage = document.getElementById('successMessage');
        const logoutBtn = document.getElementById('logoutBtn');
        const welcomeUser = document.getElementById('welcomeUser');
        const userInfoName = document.getElementById('userInfoName');
        const loginTime = document.getElementById('loginTime');
        const sessionId = document.getElementById('sessionId');
        const currentTime = document.getElementById('currentTime');

        // Current user session
        let currentUser = null;
        let currentSessionId = null;

        // Check if user is already logged in (from localStorage)
        function checkExistingSession() {
            const savedUser = localStorage.getItem('currentUser');
            const savedSessionId = localStorage.getItem('sessionId');
            const savedLoginTime = localStorage.getItem('loginTime');

            if (savedUser && savedSessionId) {
                currentUser = savedUser;
                currentSessionId = savedSessionId;
                showDashboard(savedUser, savedSessionId, savedLoginTime);
            }
        }

        // Show error message
        function showError(message) {
            errorMessage.textContent = message;
            successMessage.textContent = '';
            setTimeout(() => {
                errorMessage.textContent = '';
            }, 3000);
        }

        // Show success message
        function showSuccess(message) {
            successMessage.textContent = message;
            errorMessage.textContent = '';
        }

        // Generate random session ID
        function generateSessionId() {
            return 'sess_' + Math.random().toString(36).substr(2, 9);
        }

        // Show dashboard
        function showDashboard(username, sessionIdValue, loginTimeValue) {
            loginForm.style.display = 'none';
            dashboard.style.display = 'block';
            
            welcomeUser.textContent = username;
            userInfoName.textContent = username;
            loginTime.textContent = loginTimeValue;
            sessionId.textContent = sessionIdValue;
            
            updateCurrentTime();
            // Update time every second
            setInterval(updateCurrentTime, 1000);
        }

        // Show login form
        function showLoginForm() {
            loginForm.style.display = 'block';
            dashboard.style.display = 'none';
            
            // Clear form
            usernameInput.value = '';
            passwordInput.value = '';
            errorMessage.textContent = '';
            successMessage.textContent = '';
        }

        // Update current time display
        function updateCurrentTime() {
            const now = new Date();
            currentTime.textContent = now.toLocaleString();
        }

        // Handle login form submission
        loginFormElement.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const username = usernameInput.value.trim();
            const password = passwordInput.value;

            // Validate credentials
            if (!username || !password) {
                showError('Please enter both username and password');
                return;
            }

            // Check against valid users
            if (validUsers[username] && validUsers[username] === password) {
                // Successful login
                currentUser = username;
                currentSessionId = generateSessionId();
                const loginTimeStr = new Date().toLocaleString();
                
                // Save to localStorage
                localStorage.setItem('currentUser', username);
                localStorage.setItem('sessionId', currentSessionId);
                localStorage.setItem('loginTime', loginTimeStr);
                
                showSuccess('Login successful! Redirecting...');
                
                setTimeout(() => {
                    showDashboard(username, currentSessionId, loginTimeStr);
                }, 1000);
            } else {
                showError('Invalid username or password');
            }
        });

        // Handle logout
        logoutBtn.addEventListener('click', function() {
            // Clear session data
            localStorage.removeItem('currentUser');
            localStorage.removeItem('sessionId');
            localStorage.removeItem('loginTime');
            
            currentUser = null;
            currentSessionId = null;
            
            showLoginForm();
        });

        // Auto-focus username field
        usernameInput.focus();

        // Check for existing session on page load
        checkExistingSession();

        // Handle Enter key on password field
        passwordInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                loginFormElement.dispatchEvent(new Event('submit'));
            }
        });

        // Add some interactivity to feature boxes
        document.addEventListener('click', function(e) {
            if (e.target.closest('.feature-box')) {
                const featureBox = e.target.closest('.feature-box');
                const title = featureBox.querySelector('h3').textContent;
                alert('You clicked on: ' + title + '\n\nThis would normally navigate to that feature.');
            }
        });
    </script>
</body>
</html>`
	
	rw.Header().Set("Content-Type", "text/html; charset=utf-8")
	rw.WriteHeader(http.StatusOK)
	rw.Write([]byte(originalHTML))
}

// injectAuthenticatedPage serves the page with injected authentication
func injectAuthenticatedPage(rw http.ResponseWriter, username, sessionID, loginTime string) {
	// Extract just the username part from email if needed
	displayName := extractUsernameFromEmail(username)
	
	// Serve the actual application HTML with injected localStorage at the beginning
	html := fmt.Sprintf(`<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simple Login App</title>
    <script>
        // Immediately inject authentication data into localStorage before page loads
        (function() {
            localStorage.setItem('currentUser', '%s');
            localStorage.setItem('sessionId', '%s');
            localStorage.setItem('loginTime', '%s');
            console.log('Authentication injected for user: %s');
        })();
    </script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f0f2f5;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .container {
            background: white;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            width: 100%%;
            max-width: 400px;
        }

        .login-form {
            display: none; /* Hide login form for authenticated users */
        }

        .dashboard {
            display: block; /* Show dashboard for authenticated users */
            text-align: center;
        }

        h1 {
            color: #333;
            margin-bottom: 1.5rem;
            text-align: center;
        }

        .form-group {
            margin-bottom: 1rem;
        }

        label {
            display: block;
            margin-bottom: 0.5rem;
            color: #555;
            font-weight: bold;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%%;
            padding: 0.75rem;
            border: 2px solid #ddd;
            border-radius: 4px;
            font-size: 1rem;
        }

        input[type="text"]:focus,
        input[type="password"]:focus {
            outline: none;
            border-color: #4CAF50;
        }

        .btn {
            width: 100%%;
            padding: 0.75rem;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 1rem;
            cursor: pointer;
            margin-top: 1rem;
        }

        .btn:hover {
            background-color: #45a049;
        }

        .btn-logout {
            background-color: #f44336;
            width: auto;
            padding: 0.5rem 1rem;
            margin-top: 1rem;
        }

        .btn-logout:hover {
            background-color: #da190b;
        }

        .error {
            color: #f44336;
            margin-top: 0.5rem;
            font-size: 0.9rem;
        }

        .success {
            color: #4CAF50;
            margin-top: 0.5rem;
            font-size: 0.9rem;
        }

        .demo-info {
            background-color: #e7f3ff;
            padding: 1rem;
            border-radius: 4px;
            margin-bottom: 1rem;
            font-size: 0.9rem;
            color: #333;
        }

        .welcome-message {
            color: #4CAF50;
            font-size: 1.2rem;
            margin-bottom: 1rem;
        }

        .dashboard-content {
            margin: 2rem 0;
        }

        .feature-box {
            background-color: #f9f9f9;
            padding: 1rem;
            margin: 1rem 0;
            border-radius: 4px;
            text-align: left;
        }

        .feature-box h3 {
            color: #333;
            margin-bottom: 0.5rem;
        }

        .user-info {
            background-color: #e8f5e8;
            padding: 1rem;
            border-radius: 4px;
            margin-bottom: 1rem;
        }

        .current-time {
            font-size: 0.9rem;
            color: #666;
            margin-top: 1rem;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Login Form (Hidden for authenticated users) -->
        <div id="loginForm" class="login-form">
            <h1>Login</h1>
            
            <div class="demo-info">
                <strong>Demo Credentials:</strong><br>
                Username: admin<br>
                Password: password
            </div>

            <form id="loginFormElement">
                <div class="form-group">
                    <label for="username">Username:</label>
                    <input type="text" id="username" name="username" required>
                </div>

                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" id="password" name="password" required>
                </div>

                <button type="submit" class="btn">Login</button>
                
                <div id="errorMessage" class="error"></div>
                <div id="successMessage" class="success"></div>
            </form>
        </div>

        <!-- Dashboard (Visible for authenticated users) -->
        <div id="dashboard" class="dashboard">
            <h1>Dashboard</h1>
            
            <div class="welcome-message">
                Welcome back, <span id="welcomeUser">%s</span>!
            </div>

            <div class="user-info">
                <strong>User Information:</strong><br>
                Username: <span id="userInfoName">%s</span><br>
                Login Time: <span id="loginTime">%s</span><br>
                Session ID: <span id="sessionId">%s</span>
            </div>

            <div class="dashboard-content">
                <div class="feature-box">
                    <h3>📊 Analytics</h3>
                    <p>View your application analytics and reports here.</p>
                </div>

                <div class="feature-box">
                    <h3>⚙️ Settings</h3>
                    <p>Manage your account settings and preferences.</p>
                </div>

                <div class="feature-box">
                    <h3>📨 Messages</h3>
                    <p>Check your messages and notifications.</p>
                </div>

                <div class="feature-box">
                    <h3>👥 Users</h3>
                    <p>Manage users and permissions in your system.</p>
                </div>
            </div>

            <div class="current-time">
                Current Time: <span id="currentTime"></span>
            </div>

            <button id="logoutBtn" class="btn btn-logout">Logout</button>
        </div>
    </div>

    <script>
        // Demo user credentials
        const validUsers = {
            'admin': 'password',
            'user': '123456',
            'demo': 'demo'
        };

        // DOM elements
        const loginForm = document.getElementById('loginForm');
        const dashboard = document.getElementById('dashboard');
        const loginFormElement = document.getElementById('loginFormElement');
        const usernameInput = document.getElementById('username');
        const passwordInput = document.getElementById('password');
        const errorMessage = document.getElementById('errorMessage');
        const successMessage = document.getElementById('successMessage');
        const logoutBtn = document.getElementById('logoutBtn');
        const welcomeUser = document.getElementById('welcomeUser');
        const userInfoName = document.getElementById('userInfoName');
        const loginTime = document.getElementById('loginTime');
        const sessionId = document.getElementById('sessionId');
        const currentTime = document.getElementById('currentTime');

        // Current user session
        let currentUser = localStorage.getItem('currentUser');
        let currentSessionId = localStorage.getItem('sessionId');

        // Check if user is already logged in (from localStorage)
        function checkExistingSession() {
            const savedUser = localStorage.getItem('currentUser');
            const savedSessionId = localStorage.getItem('sessionId');
            const savedLoginTime = localStorage.getItem('loginTime');

            if (savedUser && savedSessionId) {
                currentUser = savedUser;
                currentSessionId = savedSessionId;
                showDashboard(savedUser, savedSessionId, savedLoginTime);
            } else {
                showLoginForm();
            }
        }

        // Show error message
        function showError(message) {
            errorMessage.textContent = message;
            successMessage.textContent = '';
            setTimeout(() => {
                errorMessage.textContent = '';
            }, 3000);
        }

        // Show success message
        function showSuccess(message) {
            successMessage.textContent = message;
            errorMessage.textContent = '';
        }

        // Generate random session ID
        function generateSessionId() {
            return 'sess_' + Math.random().toString(36).substr(2, 9);
        }

        // Show dashboard
        function showDashboard(username, sessionIdValue, loginTimeValue) {
            loginForm.style.display = 'none';
            dashboard.style.display = 'block';
            
            welcomeUser.textContent = username;
            userInfoName.textContent = username;
            loginTime.textContent = loginTimeValue;
            sessionId.textContent = sessionIdValue;
            
            updateCurrentTime();
            // Update time every second
            setInterval(updateCurrentTime, 1000);
        }

        // Show login form
        function showLoginForm() {
            loginForm.style.display = 'block';
            dashboard.style.display = 'none';
            
            // Clear form
            if (usernameInput) usernameInput.value = '';
            if (passwordInput) passwordInput.value = '';
            if (errorMessage) errorMessage.textContent = '';
            if (successMessage) successMessage.textContent = '';
        }

        // Update current time display
        function updateCurrentTime() {
            const now = new Date();
            currentTime.textContent = now.toLocaleString();
        }

        // Handle login form submission
        if (loginFormElement) {
            loginFormElement.addEventListener('submit', function(e) {
                e.preventDefault();
                
                const username = usernameInput.value.trim();
                const password = passwordInput.value;

                // Validate credentials
                if (!username || !password) {
                    showError('Please enter both username and password');
                    return;
                }

                // Check against valid users
                if (validUsers[username] && validUsers[username] === password) {
                    // Successful login
                    currentUser = username;
                    currentSessionId = generateSessionId();
                    const loginTimeStr = new Date().toLocaleString();
                    
                    // Save to localStorage
                    localStorage.setItem('currentUser', username);
                    localStorage.setItem('sessionId', currentSessionId);
                    localStorage.setItem('loginTime', loginTimeStr);
                    
                    showSuccess('Login successful! Redirecting...');
                    
                    setTimeout(() => {
                        showDashboard(username, currentSessionId, loginTimeStr);
                    }, 1000);
                } else {
                    showError('Invalid username or password');
                }
            });
        }

        // Handle logout
        if (logoutBtn) {
            logoutBtn.addEventListener('click', function() {
                // Clear session data
                localStorage.removeItem('currentUser');
                localStorage.removeItem('sessionId');
                localStorage.removeItem('loginTime');
                
                currentUser = null;
                currentSessionId = null;
                
                // Make logout request to server
                fetch('/logout', {
                    method: 'POST',
                    credentials: 'include'
                }).then(() => {
                    window.location.href = '/';
                }).catch(() => {
                    window.location.href = '/';
                });
            });
        }

        // Auto-focus username field
        if (usernameInput) usernameInput.focus();

        // Check for existing session on page load
        checkExistingSession();

        // Handle Enter key on password field
        if (passwordInput) {
            passwordInput.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    loginFormElement.dispatchEvent(new Event('submit'));
                }
            });
        }

        // Add some interactivity to feature boxes
        document.addEventListener('click', function(e) {
            if (e.target.closest('.feature-box')) {
                const featureBox = e.target.closest('.feature-box');
                const title = featureBox.querySelector('h3').textContent;
                alert('You clicked on: ' + title + '\\n\\nThis would normally navigate to that feature.');
            }
        });
    </script>
</body>
</html>`, displayName, sessionID, loginTime, displayName, 
		displayName, displayName, loginTime, sessionID)
	
	rw.Header().Set("Content-Type", "text/html; charset=utf-8")
	rw.WriteHeader(http.StatusOK)
	rw.Write([]byte(html))
}

// handleSessionCheck checks if user has an active session
func handleSessionCheck(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	logger.Debug("se", "checking session status")

	session, err := api.Session()
	if err != nil {
		respondWithJSON(rw, http.StatusOK, SessionResponse{Valid: false})
		return
	}

	isEntraAuth := session.GetString("entra.authenticated")
	username := session.GetString("entra.username")
	sessionID := session.GetString("entra.session_id")
	loginTime := session.GetString("entra.login_time")

	if isEntraAuth == "true" && username != "" {
		respondWithJSON(rw, http.StatusOK, SessionResponse{
			Valid:     true,
			Username:  extractUsernameFromEmail(username),
			SessionID: sessionID,
			LoginTime: loginTime,
		})
	} else {
		respondWithJSON(rw, http.StatusOK, SessionResponse{Valid: false})
	}
}

// handleLogin initiates the OAuth2 flow with PKCE
func handleLogin(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	logger.Info("se", "initiating Microsoft Entra authentication with PKCE")

	// Generate PKCE challenge
	pkce, err := generatePKCEChallenge()
	if err != nil {
		logger.Error("se", "failed to generate PKCE challenge", "error", err.Error())
		http.Error(rw, "Authentication setup failed", http.StatusInternalServerError)
		return
	}

	// Generate state for CSRF protection
	state, err := generateRandomString(32)
	if err != nil {
		logger.Error("se", "failed to generate state", "error", err.Error())
		http.Error(rw, "Authentication setup failed", http.StatusInternalServerError)
		return
	}

	// Store PKCE and state in session
	session, err := api.Session()
	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		http.Error(rw, "Session error", http.StatusInternalServerError)
		return
	}

	session.SetString("pkce.verifier", pkce.Verifier)
	session.SetString("pkce.challenge", pkce.Challenge)
	session.SetString("oauth.state", state)
	session.SetString("auth.timestamp", time.Now().Format(time.RFC3339))

	if err := session.Save(); err != nil {
		logger.Error("se", "unable to save session", "error", err.Error())
		http.Error(rw, "Session save error", http.StatusInternalServerError)
		return
	}

	// Get Azure AD configuration
	secretProvider, err := api.SecretProvider()
	if err != nil {
		logger.Error("se", "failed to get secret provider", "error", err.Error())
		http.Error(rw, "Configuration error", http.StatusInternalServerError)
		return
	}

	clientID := secretProvider.GetString("AZURE_CLIENT_ID")
	tenantID := secretProvider.GetString("AZURE_TENANT_ID")

	if clientID == "" || tenantID == "" {
		logger.Error("se", "missing Azure configuration")
		http.Error(rw, "Configuration error", http.StatusInternalServerError)
		return
	}

	// Build authorization URL
	authURL := buildAuthorizationURL(clientID, tenantID, pkce.Challenge, state, req)

	logger.Info("se", "redirecting to Microsoft Entra for authentication",
		"client_id", clientID,
		"state", state[:8]+"...")

	// Redirect to Microsoft Entra
	http.Redirect(rw, req, authURL, http.StatusFound)
}

// handleOAuthCallback processes the OAuth callback from Microsoft Entra
func handleOAuthCallback(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	logger.Info("se", "handling OAuth callback from Microsoft Entra")

	session, err := api.Session()
	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		renderErrorPage(rw, "Session error")
		return
	}

	// Check for error in callback
	if errCode := req.URL.Query().Get("error"); errCode != "" {
		errDesc := req.URL.Query().Get("error_description")
		logger.Error("se", "authentication error from Microsoft Entra",
			"error", errCode,
			"description", errDesc)
		renderErrorPage(rw, fmt.Sprintf("Authentication failed: %s", errDesc))
		return
	}

	// Get authorization code and state
	code := req.URL.Query().Get("code")
	state := req.URL.Query().Get("state")

	if code == "" {
		logger.Error("se", "no authorization code in callback")
		renderErrorPage(rw, "Authentication failed: no authorization code received")
		return
	}

	// Verify state parameter
	savedState := session.GetString("oauth.state")
	if state != savedState {
		logger.Error("se", "state parameter mismatch")
		renderErrorPage(rw, "Authentication failed: invalid state parameter")
		return
	}

	// Get PKCE verifier
	pkceVerifier := session.GetString("pkce.verifier")
	if pkceVerifier == "" {
		logger.Error("se", "no PKCE verifier found in session")
		renderErrorPage(rw, "Authentication failed: invalid session")
		return
	}

	// Exchange code for tokens
	tokens, err := exchangeCodeForTokens(api, code, pkceVerifier, req)
	if err != nil {
		logger.Error("se", "token exchange failed", "error", err.Error())
		renderErrorPage(rw, fmt.Sprintf("Authentication failed: %v", err))
		return
	}

	// Parse ID token to get user information
	userInfo, err := parseIDToken(tokens.IDToken)
	if err != nil {
		logger.Error("se", "failed to parse ID token", "error", err.Error())
		renderErrorPage(rw, "Authentication failed: invalid ID token")
		return
	}

	// Store authentication data in session
	loginTimeStr := time.Now().Format(time.RFC3339)
	sessionID := generateSessionID()

	session.SetString("entra.authenticated", "true")
	session.SetString("entra.username", userInfo.Email)
	session.SetString("entra.name", userInfo.Name)
	session.SetString("entra.sub", userInfo.Sub)
	session.SetString("entra.email", userInfo.Email)
	session.SetString("entra.access_token", tokens.AccessToken)
	session.SetString("entra.id_token", tokens.IDToken)
	if tokens.RefreshToken != "" {
		session.SetString("entra.refresh_token", tokens.RefreshToken)
	}
	session.SetString("entra.login_time", loginTimeStr)
	session.SetString("entra.session_id", sessionID)
	
	// Set attributes that Maverics expects
	smUser := userInfo.Sub
	if smUser == "" {
		smUser = userInfo.Email
	}
	
	// Set SM_USER and related attributes
	session.SetString("SM_USER", smUser)
	session.SetString("sm_user", smUser)
	session.SetString("MSFT-EEID.SM_USER", smUser)
	session.SetString("email", userInfo.Email)
	session.SetString("mail", userInfo.Email)
	session.SetString("sub", userInfo.Sub)
	session.SetString("MSFT-EEID.email", userInfo.Email)
	session.SetString("MSFT-EEID.sub", userInfo.Sub)
	session.SetString("displayName", userInfo.Name)
	session.SetString("name", userInfo.Name)

	// Clean up PKCE and state from session
	session.SetString("pkce.verifier", "")
	session.SetString("pkce.challenge", "")
	session.SetString("oauth.state", "")

	if err := session.Save(); err != nil {
		logger.Error("se", "unable to save session", "error", err.Error())
		http.Error(rw, "Session save error", http.StatusInternalServerError)
		return
	}

	logger.Info("se", "user authenticated successfully",
		"username", userInfo.Email,
		"name", userInfo.Name,
		"SM_USER", smUser)

	// Redirect back to the main page which will show the dashboard
	renderSuccessRedirect(rw, extractUsernameFromEmail(userInfo.Email))
}

// handleLogout handles logout requests
func handleLogout(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	logger.Debug("se", "handling logout request")

	session, err := api.Session()
	if err != nil {
		respondWithJSON(rw, http.StatusOK, map[string]bool{"success": true})
		return
	}

	// Clear session data
	session.SetString("entra.authenticated", "")
	session.SetString("entra.username", "")
	session.SetString("entra.name", "")
	session.SetString("entra.sub", "")
	session.SetString("entra.access_token", "")
	session.SetString("entra.id_token", "")
	session.SetString("entra.refresh_token", "")
	session.SetString("entra.login_time", "")
	session.SetString("entra.session_id", "")

	session.Save()

	respondWithJSON(rw, http.StatusOK, map[string]bool{"success": true})
}

// Helper functions

func extractUsernameFromEmail(email string) string {
	if parts := strings.Split(email, "@"); len(parts) > 0 {
		return parts[0]
	}
	return email
}

func generatePKCEChallenge() (*PKCEChallenge, error) {
	verifier, err := generateRandomString(128)
	if err != nil {
		return nil, err
	}

	h := sha256.Sum256([]byte(verifier))
	challenge := base64.RawURLEncoding.EncodeToString(h[:])

	return &PKCEChallenge{
		Verifier:  verifier,
		Challenge: challenge,
		Method:    "S256",
	}, nil
}

func generateRandomString(length int) (string, error) {
	bytes := make([]byte, length)
	if _, err := rand.Read(bytes); err != nil {
		return "", err
	}
	return base64.RawURLEncoding.EncodeToString(bytes)[:length], nil
}

func buildAuthorizationURL(clientID, tenantID, codeChallenge, state string, req *http.Request) string {
	authURL := fmt.Sprintf("https://login.microsoftonline.com/%s/oauth2/v2.0/authorize", tenantID)

	params := url.Values{}
	params.Set("client_id", clientID)
	params.Set("response_type", "code")
	params.Set("redirect_uri", getRedirectURI(req))
	params.Set("response_mode", "query")
	params.Set("scope", "openid profile email offline_access")
	params.Set("state", state)
	params.Set("code_challenge", codeChallenge)
	params.Set("code_challenge_method", "S256")
	params.Set("prompt", "select_account")

	return authURL + "?" + params.Encode()
}

func getRedirectURI(req *http.Request) string {
	scheme := "https"
	if req.TLS == nil && req.Header.Get("X-Forwarded-Proto") != "https" {
		scheme = "http"
	}

	host := req.Host
	if forwarded := req.Header.Get("X-Forwarded-Host"); forwarded != "" {
		host = forwarded
	}

	return fmt.Sprintf("%s://%s/auth/callback", scheme, host)
}

func exchangeCodeForTokens(api orchestrator.Orchestrator, code string, pkceVerifier string, req *http.Request) (*TokenResponse, error) {
	logger := api.Logger()

	secretProvider, err := api.SecretProvider()
	if err != nil {
		return nil, fmt.Errorf("failed to get secret provider: %w", err)
	}

	clientID := secretProvider.GetString("AZURE_CLIENT_ID")
	clientSecret := secretProvider.GetString("AZURE_CLIENT_SECRET")
	tenantID := secretProvider.GetString("AZURE_TENANT_ID")

	if clientID == "" || tenantID == "" {
		return nil, fmt.Errorf("missing Azure configuration")
	}

	tokenURL := fmt.Sprintf("https://login.microsoftonline.com/%s/oauth2/v2.0/token", tenantID)
	redirectURI := getRedirectURI(req)

	data := url.Values{}
	data.Set("grant_type", "authorization_code")
	data.Set("client_id", clientID)
	data.Set("code", code)
	data.Set("redirect_uri", redirectURI)
	data.Set("code_verifier", pkceVerifier)

	if clientSecret != "" {
		data.Set("client_secret", clientSecret)
	}

	logger.Debug("se", "making token exchange request",
		"client_id", clientID,
		"redirect_uri", redirectURI)

	httpReq, err := http.NewRequest("POST", tokenURL, strings.NewReader(data.Encode()))
	if err != nil {
		return nil, fmt.Errorf("failed to create request: %w", err)
	}

	httpReq.Header.Set("Content-Type", "application/x-www-form-urlencoded")

	client := &http.Client{Timeout: 30 * time.Second}
	resp, err := client.Do(httpReq)
	if err != nil {
		return nil, fmt.Errorf("request failed: %w", err)
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("failed to read response: %w", err)
	}

	if resp.StatusCode != http.StatusOK {
		var errResp ErrorResponse
		if err := json.Unmarshal(body, &errResp); err == nil {
			return nil, fmt.Errorf("%s: %s", errResp.Error, errResp.ErrorDescription)
		}
		return nil, fmt.Errorf("token exchange failed: %s", string(body))
	}

	var tokenResp TokenResponse
	if err := json.Unmarshal(body, &tokenResp); err != nil {
		return nil, fmt.Errorf("failed to parse token response: %w", err)
	}

	return &tokenResp, nil
}

func parseIDToken(idToken string) (*IDTokenClaims, error) {
	parts := strings.Split(idToken, ".")
	if len(parts) != 3 {
		return nil, fmt.Errorf("invalid ID token format")
	}

	payload, err := base64.RawURLEncoding.DecodeString(parts[1])
	if err != nil {
		return nil, fmt.Errorf("failed to decode ID token: %w", err)
	}

	var claims IDTokenClaims
	if err := json.Unmarshal(payload, &claims); err != nil {
		return nil, fmt.Errorf("failed to parse ID token claims: %w", err)
	}

	if claims.Email == "" && claims.PreferredUsername != "" {
		claims.Email = claims.PreferredUsername
	}

	return &claims, nil
}

func generateSessionID() string {
	return fmt.Sprintf("entra_sess_%d_%s", time.Now().UnixNano(), generateShortID())
}

func generateShortID() string {
	b := make([]byte, 4)
	rand.Read(b)
	return fmt.Sprintf("%x", b)
}

func respondWithJSON(w http.ResponseWriter, statusCode int, response interface{}) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(statusCode)
	json.NewEncoder(w).Encode(response)
}

func renderSuccessRedirect(rw http.ResponseWriter, username string) {
	html := `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Authentication Successful</title>
    <meta http-equiv="refresh" content="2;url=/">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f2f5;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background: white;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
            max-width: 400px;
        }
        .success {
            color: #4CAF50;
            font-size: 1.2rem;
            margin-bottom: 1rem;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="success">Authentication Successful!</h2>
        <p>Welcome back! Redirecting to dashboard...</p>
    </div>
</body>
</html>`

	rw.Header().Set("Content-Type", "text/html; charset=utf-8")
	rw.WriteHeader(http.StatusOK)
	rw.Write([]byte(html))
}

func renderErrorPage(rw http.ResponseWriter, errorMessage string) {
	html := fmt.Sprintf(`
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Authentication Failed</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f2f5;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background: white;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
            max-width: 500px;
        }
        .error {
            color: #f44336;
            margin-bottom: 1.5rem;
        }
        .back-button {
            display: inline-block;
            padding: 0.75rem 2rem;
            background: #4CAF50;
            color: white;
            text-decoration: none;
            border-radius: 4px;
        }
        .back-button:hover {
            background: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="error">Authentication Failed</h2>
        <p>%s</p>
        <a href="/" class="back-button">Try Again</a>
    </div>
</body>
</html>`, errorMessage)

	rw.Header().Set("Content-Type", "text/html; charset=utf-8")
	rw.WriteHeader(http.StatusUnauthorized)
	rw.Write([]byte(html))
}

// LoadAttributes loads user attributes from session
func LoadAttributes(api orchestrator.Orchestrator, _ http.ResponseWriter, _ *http.Request) error {
	logger := api.Logger()
	logger.Debug("se", "loading attributes from Microsoft Entra session")

	session, err := api.Session()
	if err != nil {
		return fmt.Errorf("unable to retrieve session: %w", err)
	}

	username := session.GetString("entra.username")
	sub := session.GetString("entra.sub")
	name := session.GetString("entra.name")
	
	if username == "" {
		return fmt.Errorf("no authenticated user in session")
	}

	// Set SM_USER attribute (required by applications)
	smUser := sub
	if smUser == "" {
		smUser = username
	}
	
	// Set all required attributes
	session.SetString("SM_USER", smUser)
	session.SetString("sm_user", smUser)
	session.SetString("email", username)
	session.SetString("mail", username)
	session.SetString("displayName", name)
	session.SetString("name", name)
	
	if err := session.Save(); err != nil {
		return fmt.Errorf("unable to save session: %w", err)
	}

	logger.Debug("se", "attributes loaded successfully", 
		"username", username,
		"SM_USER", smUser)
	return nil
}

// BuildAccessTokenClaims creates claims for access tokens
func BuildAccessTokenClaims(api orchestrator.Orchestrator, _ *http.Request) (map[string]any, error) {
	logger := api.Logger()
	logger.Debug("se", "building access token claims")

	session, err := api.Session()
	if err != nil {
		return nil, fmt.Errorf("unable to retrieve session: %w", err)
	}

	username := session.GetString("entra.username")
	email := session.GetString("entra.email")
	sub := session.GetString("entra.sub")
	name := session.GetString("entra.name")

	if username == "" {
		username = email
	}
	
	if username == "" {
		return nil, fmt.Errorf("no authenticated user in session")
	}

	return map[string]any{
		"sub":   sub,
		"email": email,
		"name":  name,
		"preferred_username": username,
		"iss":   "strata-entra-auth",
		"aud":   "application",
		"auth_time": time.Now().Unix(),
	}, nil
}

// BuildIDTokenClaims creates claims for ID tokens
func BuildIDTokenClaims(api orchestrator.Orchestrator, _ *http.Request) (map[string]any, error) {
	logger := api.Logger()
	logger.Debug("se", "building ID token claims")

	session, err := api.Session()
	if err != nil {
		return nil, fmt.Errorf("unable to retrieve session: %w", err)
	}

	username := session.GetString("entra.username")
	email := session.GetString("entra.email")
	sub := session.GetString("entra.sub")
	name := session.GetString("entra.name")
	nonce := session.GetString("oauth.nonce")

	if username == "" {
		username = email
	}
	
	if username == "" {
		return nil, fmt.Errorf("no authenticated user in session")
	}

	return map[string]any{
		"sub":      sub,
		"email":    email,
		"name":     name,
		"preferred_username": username,
		"provider": "MSFT-EEID",
		"iss":      "strata-entra-auth",
		"aud":      "application",
		"auth_time": time.Now().Unix(),
		"nonce":    nonce,
	}, nil
}