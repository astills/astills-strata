package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"strings"
	"time"

	"github.com/strata-io/service-extension/orchestrator"
)

// IdPConfig represents configuration for an Identity Provider
type IdPConfig struct {
	ID          string            `json:"id"`
	Name        string            `json:"name"`
	Domains     []string          `json:"domains"`
	ClaimMaps   map[string]string `json:"claim_maps"`
	Priority    int               `json:"priority"`
}

// HeaderMapping defines how session claims map to HTTP headers
type HeaderMapping struct {
	SessionKey string `json:"session_key"`
	HeaderName string `json:"header_name"`
	Format     string `json:"format"` // "string", "json", "comma-separated"
	Required   bool   `json:"required"`
}

// AppHeaderConfig defines header requirements for specific applications
type AppHeaderConfig struct {
	AppID           string          `json:"app_id"`
	PathPattern     string          `json:"path_pattern"`
	HeaderMappings  []HeaderMapping `json:"header_mappings"`
	InjectAllClaims bool            `json:"inject_all_claims"`
	HeaderPrefix    string          `json:"header_prefix"`
}

// UniversalSession represents the universal session structure
type UniversalSession struct {
	UserID            string            `json:"user_id"`
	Email             string            `json:"email"`
	FirstName         string            `json:"first_name"`
	LastName          string            `json:"last_name"`
	DisplayName       string            `json:"display_name"`
	Groups            []string          `json:"groups"`
	Roles             []string          `json:"roles"`
	Department        string            `json:"department"`
	Organization      string            `json:"organization"`
	AuthenticatedIdPs []string          `json:"authenticated_idps"`
	SessionStart      time.Time         `json:"session_start"`
	LastActivity      time.Time         `json:"last_activity"`
	CustomClaims      map[string]string `json:"custom_claims"`
}

// Strata IdP configurations for your environment
var defaultIdPConfigs = []IdPConfig{
	{
		ID:       "Mav5",
		Name:     "Mav5 Identity Provider",
		Domains:  []string{"@strata.io"},
		Priority: 1,
		ClaimMaps: map[string]string{
			"sub":                "user_id",
			"given_name":         "first_name",
			"family_name":        "last_name",
			"email":              "email",
			"name":               "display_name",
			"preferred_username": "username",
			"groups":             "groups",
			"department":         "department",
			"organization":       "organization",
			"realm_access.roles": "roles",
		},
	},
	{
		ID:       "MSFT-EEID",
		Name:     "Microsoft Enterprise External ID",
		Domains:  []string{"@canaryretail.onmicrosoft.com"},
		Priority: 2,
		ClaimMaps: map[string]string{
			"sub":                "user_id",
			"email":              "email",
			"name":               "display_name",
			"given_name":         "first_name",
			"family_name":        "last_name",
			"preferred_username": "username",
			"groups":             "groups",
			"department":         "department",
			"organization":       "organization",
			"realm_access.roles": "roles",
		},
	},
	{
		ID:       "Strata-Eval-io",
		Name:     "Strata Evaluation Identity",
		Domains:  []string{"@strata-eval.io", "@gmail.com"},
		Priority: 3,
		ClaimMaps: map[string]string{
			"sub":                "user_id",
			"given_name":         "first_name",
			"family_name":        "last_name",
			"email":              "email",
			"name":               "display_name",
			"preferred_username": "username",
			"groups":             "groups",
			"department":         "department",
			"organization":       "organization",
			"realm_access.roles": "roles",
		},
	},
}

// Default header configurations for common application types
var defaultAppHeaderConfigs = []AppHeaderConfig{
	{
		AppID:       "siteminder-apps",
		PathPattern: "/sm/*",
		HeaderMappings: []HeaderMapping{
			{SessionKey: "user_id", HeaderName: "SM_USER", Format: "string", Required: true},
			{SessionKey: "email", HeaderName: "SM_USEREMAIL", Format: "string", Required: true},
			{SessionKey: "first_name", HeaderName: "SM_FIRSTNAME", Format: "string", Required: false},
			{SessionKey: "last_name", HeaderName: "SM_LASTNAME", Format: "string", Required: false},
			{SessionKey: "display_name", HeaderName: "SM_USERDISPLAYNAME", Format: "string", Required: false},
			{SessionKey: "groups", HeaderName: "SM_USERGROUPS", Format: "comma-separated", Required: false},
			{SessionKey: "roles", HeaderName: "SM_USERROLES", Format: "comma-separated", Required: false},
			{SessionKey: "department", HeaderName: "SM_USERDEPARTMENT", Format: "string", Required: false},
			{SessionKey: "organization", HeaderName: "SM_USERORGANIZATION", Format: "string", Required: false},
		},
		InjectAllClaims: false,
	},
	{
		AppID:       "api-gateway",
		PathPattern: "/api/*",
		HeaderMappings: []HeaderMapping{
			{SessionKey: "user_id", HeaderName: "X-User-Id", Format: "string", Required: true},
			{SessionKey: "email", HeaderName: "X-User-Email", Format: "string", Required: true},
			{SessionKey: "display_name", HeaderName: "X-User-Name", Format: "string", Required: false},
			{SessionKey: "groups", HeaderName: "X-User-Groups", Format: "json", Required: false},
			{SessionKey: "roles", HeaderName: "X-User-Roles", Format: "json", Required: false},
			{SessionKey: "authenticated_idps", HeaderName: "X-Auth-Source", Format: "comma-separated", Required: false},
		},
		InjectAllClaims: true,
		HeaderPrefix:    "X-User-Claim-",
	},
	{
		AppID       : "web-apps",
		PathPattern: "/app/*", 
		HeaderMappings: []HeaderMapping{
			{SessionKey: "user_id", HeaderName: "X-Remote-User", Format: "string", Required: true},
			{SessionKey: "email", HeaderName: "X-Remote-Email", Format: "string", Required: true},
			{SessionKey: "email", HeaderName: "X-Forwarded-User", Format: "string", Required: true},
			{SessionKey: "email", HeaderName: "X-Auth-Request-Email", Format: "string", Required: true},
			{SessionKey: "display_name", HeaderName: "X-Remote-Name", Format: "string", Required: false},
			{SessionKey: "groups", HeaderName: "X-Remote-Groups", Format: "comma-separated", Required: false},
			{SessionKey: "roles", HeaderName: "X-Remote-Roles", Format: "comma-separated", Required: false},
		},
		InjectAllClaims: false,
	},
	{
		AppID:       "default",
		PathPattern: "/*",
		HeaderMappings: []HeaderMapping{
			{SessionKey: "user_id", HeaderName: "Remote-User", Format: "string", Required: true},
			{SessionKey: "email", HeaderName: "Remote-Email", Format: "string", Required: true},
			{SessionKey: "email", HeaderName: "X-Forwarded-User", Format: "string", Required: true},
			{SessionKey: "email", HeaderName: "X-Auth-Request-Email", Format: "string", Required: true},
			{SessionKey: "user_id", HeaderName: "X-Auth-Request-User", Format: "string", Required: true},
			{SessionKey: "display_name", HeaderName: "Remote-Name", Format: "string", Required: false},
			{SessionKey: "groups", HeaderName: "Remote-Groups", Format: "comma-separated", Required: false},
			{SessionKey: "roles", HeaderName: "Remote-Roles", Format: "comma-separated", Required: false},
		},
		InjectAllClaims: false,
	},
}

const (
	universalSessionKey = "universal.session"
	sessionInitialized  = "universal.initialized"
	genericPrefix       = "generic."
)

// Main entry point - this should be called by Strata Orchestrator
func Main(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	
	logger.Info("msg", "processing request", "path", req.URL.Path, "method", req.Method, "host", req.Host)
	
	// Special endpoints
	switch req.URL.Path {
	case "/diagnose-idps":
		DiagnoseIdPs(api, rw, req)
		return
	case "/user-info":
		GetUserInfo(api, rw, req)
		return
	case "/logout":
		LogoutFromAllSessions(api)
		http.Redirect(rw, req, "/", http.StatusFound)
		return
	}
	
	// Check if user is authenticated
	if !IsAuthenticated(api, rw, req) {
		logger.Info("msg", "user not authenticated, starting auth flow")
		Authenticate(api, rw, req)
		return
	}
	
	logger.Info("msg", "user authenticated, preparing request for backend", "path", req.URL.Path)
	PreProxy(api, rw, req)
	logger.Info("msg", "request ready for backend proxy", "headers_set", true)
}

// IsAuthenticated determines if the user has a valid universal session
func IsAuthenticated(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) bool {
	authenticated := checkUniversalAuthentication(api)
	if authenticated {
		InjectHeaders(api, rw, req)
	}
	return authenticated
}

// checkUniversalAuthentication checks for valid universal session
func checkUniversalAuthentication(api orchestrator.Orchestrator) bool {
	logger := api.Logger()
	sess, _ := api.Session()
	
	logger.Debug("msg", "checking universal authentication status")
	
	sessionData, err := sess.GetString(universalSessionKey)
	if err != nil || sessionData == "" {
		logger.Debug("msg", "no universal session found")
		return checkLegacyAuthentication(api)
	}
	
	var universalSession UniversalSession
	if err := json.Unmarshal([]byte(sessionData), &universalSession); err != nil {
		logger.Error("msg", "failed to parse universal session", "error", err)
		return checkLegacyAuthentication(api)
	}
	
	sessionTimeout := 8 * time.Hour
	if time.Since(universalSession.LastActivity) > sessionTimeout {
		logger.Info("msg", "universal session timed out", "user_id", universalSession.UserID)
		LogoutFromAllSessions(api)
		return false
	}
	
	universalSession.LastActivity = time.Now()
	updatedSessionData, _ := json.Marshal(universalSession)
	_ = sess.SetString(universalSessionKey, string(updatedSessionData))
	sess.Save()
	
	setGenericClaims(api, &universalSession)
	
	logger.Debug("msg", "user authenticated via universal session", "user_id", universalSession.UserID, "email", universalSession.Email)
	return true
}

// checkLegacyAuthentication checks for existing IdP sessions
func checkLegacyAuthentication(api orchestrator.Orchestrator) bool {
	logger := api.Logger()
	sess, _ := api.Session()
	
	logger.Debug("msg", "checking legacy authentication methods")
	
	for _, config := range defaultIdPConfigs {
		authenticated, err := sess.GetString(fmt.Sprintf("%s.authenticated", config.ID))
		if err == nil && authenticated == "true" {
			logger.Debug("msg", "found legacy authentication", "idp", config.ID)
			if migrateToUniversalSession(api, &config) {
				return true
			}
		}
	}
	
	return false
}

// Authenticate handles the authentication flow with intelligent IdP routing
func Authenticate(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	logger.Info("msg", "starting universal authentication flow")
	
	sess, _ := api.Session()
	if initialized, _ := sess.GetString("idp.mappings.initialized"); initialized != "true" {
		InitializeIdPMappings(api)
		_ = sess.SetString("idp.mappings.initialized", "true")
		sess.Save()
	}
	
	if checkUniversalAuthentication(api) {
		logger.Debug("msg", "user already authenticated")
		InjectHeaders(api, rw, req)
		return
	}
	
	email := req.FormValue("email")
	if email == "" && req.Method != http.MethodPost {
		logger.Debug("msg", "rendering email selection form")
		renderEmailForm(rw, req)
		return
	}
	
	if req.Method != http.MethodPost {
		http.Error(rw, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	
	if err := req.ParseForm(); err != nil {
		http.Error(rw, "Failed to parse form", http.StatusBadRequest)
		logger.Error("msg", "failed to parse form", "error", err)
		return
	}
	
	email = req.Form.Get("email")
	if email == "" {
		http.Error(rw, "Email is required", http.StatusBadRequest)
		return
	}
	
	domain := extractDomain(email)
	idpConfig := findIdPForDomain(domain)
	
	if idpConfig == nil {
		InitializeIdPMappings(api)
		idpConfig = findIdPForDomain(domain)
		
		if idpConfig == nil {
			errorMsg := fmt.Sprintf("No identity provider configured for domain %s", domain)
			http.Error(rw, errorMsg, http.StatusBadRequest)
			logger.Error("msg", "no IdP found for domain", "email", email, "domain", domain)
			return
		}
	}
	
	logger.Info("msg", "routing to identity provider", "email", email, "domain", domain, "idp", idpConfig.ID, "idp_name", idpConfig.Name)
	
	provider, err := api.IdentityProvider(idpConfig.ID)
	if err != nil {
		logger.Debug("msg", "IdP not found, attempting re-discovery", "idp", idpConfig.ID)
		InitializeIdPMappings(api)
		
		provider, err = api.IdentityProvider(idpConfig.ID)
		if err != nil {
			availableIdPs := DiscoverIdentityProviders(api)
			errorMsg := fmt.Sprintf("Identity provider '%s' not found. Available IdPs: %v", idpConfig.ID, availableIdPs)
			logger.Error("msg", "failed to get identity provider after retry", "idp", idpConfig.ID, "available", availableIdPs, "error", err)
			http.Error(rw, errorMsg, http.StatusInternalServerError)
			return
		}
	}
	
	_ = sess.SetString("pending.idp", idpConfig.ID)
	_ = sess.SetString("pending.email", email)
	sess.Save()
	
	logger.Info("msg", "initiating login with identity provider", "idp", idpConfig.ID)
	provider.Login(rw, req)
}

// PostAuthenticate handles post-authentication processing
func PostAuthenticate(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	sess, _ := api.Session()
	
	pendingIdP, err1 := sess.GetString("pending.idp")
	pendingEmail, _ := sess.GetString("pending.email")
	
	if err1 != nil || pendingIdP == "" {
		logger.Error("msg", "no pending IdP found in session")
		http.Error(rw, "Authentication state error", http.StatusInternalServerError)
		return
	}
	
	logger.Info("msg", "processing post-authentication", "idp", pendingIdP, "email", pendingEmail)
	
	var idpConfig *IdPConfig
	for _, config := range defaultIdPConfigs {
		if config.ID == pendingIdP {
			idpConfig = &config
			break
		}
	}
	
	if idpConfig == nil {
		logger.Error("msg", "IdP configuration not found", "idp", pendingIdP)
		http.Error(rw, "Configuration error", http.StatusInternalServerError)
		return
	}
	
	if createUniversalSession(api, idpConfig, pendingEmail) {
		_ = sess.SetString("pending.idp", "")
		_ = sess.SetString("pending.email", "")
		sess.Save()
		logger.Info("msg", "universal session established successfully")
		InjectHeaders(api, rw, req)
	} else {
		logger.Error("msg", "failed to create universal session")
		http.Error(rw, "Session creation failed", http.StatusInternalServerError)
	}
}

// InjectHeaders injects authentication headers into the request
func InjectHeaders(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	sess, _ := api.Session()
	
	sessionData, err := sess.GetString(universalSessionKey)
	if err != nil || sessionData == "" {
		logger.Debug("msg", "no universal session found for header injection")
		return
	}
	
	var universalSession UniversalSession
	if err := json.Unmarshal([]byte(sessionData), &universalSession); err != nil {
		logger.Error("msg", "failed to parse universal session for header injection", "error", err)
		return
	}
	
	appConfig := findAppHeaderConfig(req.URL.Path)
	if appConfig == nil {
		logger.Debug("msg", "no header configuration found for path", "path", req.URL.Path)
		return
	}
	
	logger.Debug("msg", "injecting headers for application", "app_id", appConfig.AppID, "path", req.URL.Path)
	
	for _, mapping := range appConfig.HeaderMappings {
		value := getSessionValue(&universalSession, mapping.SessionKey)
		if value == "" && mapping.Required {
			logger.Debug("msg", "required header value missing", "session_key", mapping.SessionKey, "header_name", mapping.HeaderName)
			continue
		}
		
		if value != "" {
			formattedValue := formatHeaderValue(value, mapping.Format)
			req.Header.Set(mapping.HeaderName, formattedValue)
			logger.Debug("msg", "injected header", "header", mapping.HeaderName, "value_length", len(formattedValue))
		}
	}
	
	if appConfig.InjectAllClaims && appConfig.HeaderPrefix != "" {
		for key, value := range universalSession.CustomClaims {
			headerName := appConfig.HeaderPrefix + key
			req.Header.Set(headerName, value)
			logger.Debug("msg", "injected custom claim header", "header", headerName)
		}
	}
	
	req.Header.Set("X-Auth-Timestamp", universalSession.LastActivity.Format(time.RFC3339))
	req.Header.Set("X-Auth-Session-Start", universalSession.SessionStart.Format(time.RFC3339))
	
	logger.Info("msg", "successfully injected headers for backend application", "user_id", universalSession.UserID, "app_id", appConfig.AppID)
}

// PreProxy prepares headers before proxying to backend
func PreProxy(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	sess, _ := api.Session()
	
	sessionData, err := sess.GetString(universalSessionKey)
	if err != nil || sessionData == "" {
		logger.Debug("msg", "no universal session found for pre-proxy")
		return
	}
	
	var universalSession UniversalSession
	if err := json.Unmarshal([]byte(sessionData), &universalSession); err != nil {
		logger.Error("msg", "failed to parse universal session for pre-proxy", "error", err)
		return
	}
	
	appConfig := findAppHeaderConfig(req.URL.Path)
	if appConfig == nil {
		appConfig = &AppHeaderConfig{
			AppID:       "default",
			PathPattern: "/*",
			HeaderMappings: []HeaderMapping{
				{SessionKey: "user_id", HeaderName: "X-Remote-User", Format: "string", Required: true},
				{SessionKey: "email", HeaderName: "X-Remote-Email", Format: "string", Required: true},
				{SessionKey: "display_name", HeaderName: "X-Remote-Name", Format: "string", Required: false},
				{SessionKey: "groups", HeaderName: "X-Remote-Groups", Format: "comma-separated", Required: false},
			},
		}
	}
	
	logger.Info("msg", "pre-proxy header injection", "app_id", appConfig.AppID, "path", req.URL.Path, "user", universalSession.Email)
	
	clearAuthHeaders(req)
	
	for _, mapping := range appConfig.HeaderMappings {
		value := getSessionValue(&universalSession, mapping.SessionKey)
		if value == "" && mapping.Required {
			logger.Debug("msg", "required header value missing in pre-proxy", "session_key", mapping.SessionKey, "header_name", mapping.HeaderName)
			continue
		}
		
		if value != "" {
			formattedValue := formatHeaderValue(value, mapping.Format)
			req.Header.Set(mapping.HeaderName, formattedValue)
			logger.Debug("msg", "injected header in pre-proxy", "header", mapping.HeaderName, "value_length", len(formattedValue))
		}
	}
	
	req.Header.Set("X-Forwarded-User", universalSession.Email)
	req.Header.Set("X-Forwarded-Email", universalSession.Email)
	req.Header.Set("X-Auth-Request-User", universalSession.UserID)
	req.Header.Set("X-Auth-Request-Email", universalSession.Email)
	req.Header.Set("X-Auth-Timestamp", universalSession.LastActivity.Format(time.RFC3339))
	req.Header.Set("X-Auth-Session-Start", universalSession.SessionStart.Format(time.RFC3339))
	req.Header.Set("X-Auth-Method", "strata-universal")
}

// Helper functions

func extractDomain(email string) string {
	parts := strings.Split(email, "@")
	if len(parts) != 2 {
		return ""
	}
	return "@" + parts[1]
}

func findIdPForDomain(domain string) *IdPConfig {
	for _, config := range defaultIdPConfigs {
		for _, configDomain := range config.Domains {
			if strings.EqualFold(domain, configDomain) {
				return &config
			}
		}
	}
	return nil
}

func findAppHeaderConfig(path string) *AppHeaderConfig {
	for _, config := range defaultAppHeaderConfigs {
		if config.AppID != "default" && matchPath(path, config.PathPattern) {
			return &config
		}
	}
	
	for _, config := range defaultAppHeaderConfigs {
		if config.AppID == "default" {
			return &config
		}
	}
	
	return nil
}

func matchPath(path, pattern string) bool {
	if strings.HasSuffix(pattern, "*") {
		prefix := strings.TrimSuffix(pattern, "*")
		return strings.HasPrefix(path, prefix)
	}
	return path == pattern
}

func getSessionValue(session *UniversalSession, key string) string {
	switch key {
	case "user_id":
		return session.UserID
	case "email":
		return session.Email
	case "first_name":
		return session.FirstName
	case "last_name":
		return session.LastName
	case "display_name":
		return session.DisplayName
	case "department":
		return session.Department
	case "organization":
		return session.Organization
	case "groups":
		if len(session.Groups) > 0 {
			return strings.Join(session.Groups, ",")
		}
		return ""
	case "roles":
		if len(session.Roles) > 0 {
			return strings.Join(session.Roles, ",")
		}
		return ""
	case "authenticated_idps":
		if len(session.AuthenticatedIdPs) > 0 {
			return strings.Join(session.AuthenticatedIdPs, ",")
		}
		return ""
	default:
		if val, ok := session.CustomClaims[key]; ok {
			return val
		}
		return ""
	}
}

func formatHeaderValue(value, format string) string {
	switch format {
	case "json":
		if strings.Contains(value, ",") {
			parts := strings.Split(value, ",")
			jsonBytes, _ := json.Marshal(parts)
			return string(jsonBytes)
		}
		jsonBytes, _ := json.Marshal(value)
		return string(jsonBytes)
	case "comma-separated":
		return value
	default:
		return value
	}
}

func clearAuthHeaders(req *http.Request) {
	headersToCheck := []string{
		"Authorization",
		"X-Remote-User",
		"X-Remote-Email",
		"X-Forwarded-User",
		"X-Auth-Request-User",
		"Remote-User",
		"SM_USER",
		"SM_USEREMAIL",
	}
	
	for _, header := range headersToCheck {
		req.Header.Del(header)
	}
}

func parseGroups(groupsStr string) []string {
	if groupsStr == "" {
		return nil
	}
	
	var groups []string
	if err := json.Unmarshal([]byte(groupsStr), &groups); err == nil {
		return groups
	}
	
	parts := strings.Split(groupsStr, ",")
	groups = make([]string, 0, len(parts))
	for _, part := range parts {
		if trimmed := strings.TrimSpace(part); trimmed != "" {
			groups = append(groups, trimmed)
		}
	}
	
	return groups
}

func setGenericClaims(api orchestrator.Orchestrator, session *UniversalSession) {
	sess, _ := api.Session()
	
	_ = sess.SetString(genericPrefix+"SM_USER", session.UserID)
	_ = sess.SetString(genericPrefix+"email", session.Email)
	_ = sess.SetString(genericPrefix+"firstname", session.FirstName)
	_ = sess.SetString(genericPrefix+"lastname", session.LastName)
	_ = sess.SetString(genericPrefix+"displayname", session.DisplayName)
	_ = sess.SetString(genericPrefix+"department", session.Department)
	_ = sess.SetString(genericPrefix+"organization", session.Organization)
	
	if len(session.Groups) > 0 {
		groupsJson, _ := json.Marshal(session.Groups)
		_ = sess.SetString(genericPrefix+"groups", string(groupsJson))
	}
	
	if len(session.Roles) > 0 {
		rolesJson, _ := json.Marshal(session.Roles)
		_ = sess.SetString(genericPrefix+"roles", string(rolesJson))
	}
	
	for key, value := range session.CustomClaims {
		_ = sess.SetString(genericPrefix+key, value)
	}
	
	sess.Save()
}

func migrateToUniversalSession(api orchestrator.Orchestrator, config *IdPConfig) bool {
	logger := api.Logger()
	sess, _ := api.Session()
	
	logger.Info("msg", "migrating legacy session to universal session", "idp", config.ID)
	
	universalSession := UniversalSession{
		AuthenticatedIdPs: []string{config.ID},
		SessionStart:      time.Now(),
		LastActivity:      time.Now(),
		CustomClaims:      make(map[string]string),
	}
	
	for oldClaim, newField := range config.ClaimMaps {
		claimKey := fmt.Sprintf("%s.%s", config.ID, oldClaim)
		claimValue, err := sess.GetString(claimKey)
		if err != nil || claimValue == "" {
			continue
		}
		
		switch newField {
		case "user_id":
			universalSession.UserID = claimValue
		case "email":
			universalSession.Email = claimValue
		case "first_name":
			universalSession.FirstName = claimValue
		case "last_name":
			universalSession.LastName = claimValue
		case "display_name":
			universalSession.DisplayName = claimValue
		case "department":
			universalSession.Department = claimValue
		case "organization":
			universalSession.Organization = claimValue
		case "groups":
			if groups := parseGroups(claimValue); groups != nil {
				universalSession.Groups = groups
			}
		case "roles":
			if roles := parseGroups(claimValue); roles != nil {
				universalSession.Roles = roles
			}
		default:
			universalSession.CustomClaims[newField] = claimValue
		}
	}
	
	if universalSession.UserID == "" {
		universalSession.UserID = universalSession.Email
	}
	if universalSession.DisplayName == "" {
		universalSession.DisplayName = fmt.Sprintf("%s %s", universalSession.FirstName, universalSession.LastName)
	}
	
	sessionData, err := json.Marshal(universalSession)
	if err != nil {
		logger.Error("msg", "failed to marshal universal session", "error", err)
		return false
	}
	
	_ = sess.SetString(universalSessionKey, string(sessionData))
	_ = sess.SetString(sessionInitialized, "true")
	sess.Save()
	
	setGenericClaims(api, &universalSession)
	
	logger.Info("msg", "successfully migrated to universal session", "user_id", universalSession.UserID, "email", universalSession.Email)
	return true
}

func createUniversalSession(api orchestrator.Orchestrator, config *IdPConfig, email string) bool {
	logger := api.Logger()
	sess, _ := api.Session()
	
	authenticated, err := sess.GetString(fmt.Sprintf("%s.authenticated", config.ID))
	if err != nil || authenticated != "true" {
		logger.Error("msg", "IdP authentication not confirmed", "idp", config.ID)
		return false
	}
	
	return migrateToUniversalSession(api, config)
}

// Discovery and diagnostic functions

func DiscoverIdentityProviders(api orchestrator.Orchestrator) []string {
	logger := api.Logger()
	availableIdPs := []string{}
	
	commonPatterns := []string{
		"Mav5", "MSFT-EEID", "Strata-Eval-io",
		"mav5", "msft-eeid", "strata-eval-io",
		"Mav-5", "MSFT_EEID", "Strata_Eval_io",
		"microsoft", "strata",
	}
	
	for _, pattern := range commonPatterns {
		if _, err := api.IdentityProvider(pattern); err == nil {
			availableIdPs = append(availableIdPs, pattern)
			logger.Info("msg", "discovered identity provider", "id", pattern)
		}
	}
	
	return availableIdPs
}

func InitializeIdPMappings(api orchestrator.Orchestrator) {
	logger := api.Logger()
	availableIdPs := DiscoverIdentityProviders(api)
	
	if len(availableIdPs) == 0 {
		logger.Error("msg", "no identity providers found in Strata environment")
		return
	}
	
	logger.Info("msg", "found identity providers", "count", len(availableIdPs), "idps", availableIdPs)
	
	for i := range defaultIdPConfigs {
		config := &defaultIdPConfigs[i]
		originalID := config.ID
		
		for _, discoveredID := range availableIdPs {
			lowerDiscovered := strings.ToLower(discoveredID)
			lowerConfigID := strings.ToLower(config.ID)
			
			if lowerDiscovered == lowerConfigID {
				config.ID = discoveredID
				logger.Info("msg", "mapped IdP configuration", "original", originalID, "actual", discoveredID)
				break
			}
			
			if strings.Contains(lowerDiscovered, "mav") && strings.Contains(lowerConfigID, "mav") {
				config.ID = discoveredID
				logger.Info("msg", "mapped IdP configuration", "original", originalID, "actual", discoveredID)
				break
			} else if strings.Contains(lowerDiscovered, "msft") && strings.Contains(lowerConfigID, "msft") {
				config.ID = discoveredID
				logger.Info("msg", "mapped IdP configuration", "original", originalID, "actual", discoveredID)
				break
			} else if strings.Contains(lowerDiscovered, "strata") && strings.Contains(lowerDiscovered, "eval") &&
				strings.Contains(lowerConfigID, "strata") && strings.Contains(lowerConfigID, "eval") {
				config.ID = discoveredID
				logger.Info("msg", "mapped IdP configuration", "original", originalID, "actual", discoveredID)
				break
			}
		}
	}
	
	if len(availableIdPs) == 1 {
		logger.Debug("msg", "only one IdP found, using it for all domains", "idp", availableIdPs[0])
		for i := range defaultIdPConfigs {
			defaultIdPConfigs[i].ID = availableIdPs[0]
		}
	}
}

func GetUserInfo(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	sess, _ := api.Session()
	
	sessionData, err := sess.GetString(universalSessionKey)
	if err != nil || sessionData == "" {
		http.Error(rw, "Not authenticated", http.StatusUnauthorized)
		return
	}
	
	var universalSession UniversalSession
	if err := json.Unmarshal([]byte(sessionData), &universalSession); err != nil {
		http.Error(rw, "Session error", http.StatusInternalServerError)
		return
	}
	
	userInfo := map[string]interface{}{
		"user_id":            universalSession.UserID,
		"email":              universalSession.Email,
		"display_name":       universalSession.DisplayName,
		"first_name":         universalSession.FirstName,
		"last_name":          universalSession.LastName,
		"groups":             universalSession.Groups,
		"roles":              universalSession.Roles,
		"department":         universalSession.Department,
		"organization":       universalSession.Organization,
		"authenticated_with": universalSession.AuthenticatedIdPs,
		"session_start":      universalSession.SessionStart,
		"last_activity":      universalSession.LastActivity,
	}
	
	rw.Header().Set("Content-Type", "application/json")
	json.NewEncoder(rw).Encode(userInfo)
}

func DiagnoseIdPs(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	availableIdPs := DiscoverIdentityProviders(api)
	
	diagnostics := map[string]interface{}{
		"discovered_idps": availableIdPs,
		"configured_idps": []map[string]interface{}{},
		"recommendations": []string{},
	}
	
	for _, config := range defaultIdPConfigs {
		configInfo := map[string]interface{}{
			"id":       config.ID,
			"name":     config.Name,
			"domains":  config.Domains,
			"priority": config.Priority,
		}
		
		if _, err := api.IdentityProvider(config.ID); err != nil {
			configInfo["status"] = "NOT AVAILABLE"
			configInfo["error"] = err.Error()
		} else {
			configInfo["status"] = "AVAILABLE"
		}
		
		diagnostics["configured_idps"] = append(diagnostics["configured_idps"].([]map[string]interface{}), configInfo)
	}
	
	recommendations := diagnostics["recommendations"].([]string)
	
	if len(availableIdPs) == 0 {
		recommendations = append(recommendations, "No IdPs found. Check Strata Orchestrator configuration.")
	} else if len(availableIdPs) == 1 {
		recommendations = append(recommendations, fmt.Sprintf("Only one IdP found (%s). Will use for all domains.", availableIdPs[0]))
	}
	
	for _, config := range defaultIdPConfigs {
		found := false
		for _, available := range availableIdPs {
			if config.ID == available {
				found = true
				break
			}
		}
		if !found {
			recommendations = append(recommendations, fmt.Sprintf("IdP '%s' not found. Update configuration or use one of: %v", config.ID, availableIdPs))
		}
	}
	
	diagnostics["recommendations"] = recommendations
	
	rw.Header().Set("Content-Type", "application/json")
	json.NewEncoder(rw).Encode(diagnostics)
}

func LogoutFromAllSessions(api orchestrator.Orchestrator) {
	logger := api.Logger()
	sess, _ := api.Session()
	
	logger.Info("msg", "logging out user from all sessions")
	
	_ = sess.SetString(universalSessionKey, "")
	_ = sess.SetString(sessionInitialized, "false")
	_ = sess.SetString(genericPrefix+"email", "")
	_ = sess.SetString(genericPrefix+"firstname", "")
	_ = sess.SetString(genericPrefix+"lastname", "")
	_ = sess.SetString(genericPrefix+"SM_USER", "")
	_ = sess.SetString(genericPrefix+"displayname", "")
	_ = sess.SetString(genericPrefix+"department", "")
	_ = sess.SetString(genericPrefix+"organization", "")
	_ = sess.SetString(genericPrefix+"groups", "")
	_ = sess.SetString(genericPrefix+"roles", "")
	
	for _, config := range defaultIdPConfigs {
		_ = sess.SetString(fmt.Sprintf("%s.authenticated", config.ID), "false")
	}
	
	sess.Save()
	logger.Info("msg", "user logged out from all sessions")
}

func renderEmailForm(rw http.ResponseWriter, req *http.Request) {
//	samlRequest := req.FormValue("SAMLRequest")
//	relayState := req.FormValue("RelayState")
	
	html := `<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Strata Identity Hub</title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #f5f5f5; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; }
        .container { background: white; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); padding: 40px; width: 100%; max-width: 400px; }
        h1 { color: #333; font-size: 24px; margin-bottom: 8px; text-align: center; }
        p { color: #666; text-align: center; margin-bottom: 30px; }
        label { display: block; color: #555; font-size: 14px; margin-bottom: 8px; }
        input[type="email"] { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 4px; font-size: 16px; box-sizing: border-box; }
        input[type="email"]:focus { outline: none; border-color: #0066cc; }
        button { width: 100%; padding: 12px; background: #0066cc; color: white; border: none; border-radius: 4px; font-size: 16px; cursor: pointer; margin-top: 20px; }
        button:hover { background: #0052a3; }
        button:disabled { background: #ccc; cursor: not-allowed; }
        .hint { font-size: 12px; color: #666; margin-top: 8px; }
        .error { color: #d32f2f; }
        .success { color: #388e3c; }
        .domains { background: #f9f9f9; border-radius: 4px; padding: 15px; margin-top: 20px; }
        .domains h3 { font-size: 14px; margin: 0 0 10px 0; color: #555; }
        .domains p { font-size: 12px; margin: 5px 0; text-align: left; color: #777; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Strata Identity</h1>
        <p>Sign in with your email address</p>
        <form method="POST">
            <label for="email">Email Address</label>
            <input type="email" id="email" name="email" required placeholder="user@example.com">
            <div id="hint" class="hint"></div>
            <button type="submit" id="submit">Continue</button>
        </form>
        <div class="domains">
            <h3>Supported Domains</h3>
            <p><strong>Strata:</strong> @strata.io</p>
            <p><strong>Microsoft:</strong> @canaryretail.onmicrosoft.com</p>
            <p><strong>Evaluation:</strong> @strata-eval.io, @gmail.com</p>
        </div>
    </div>
    <script>
        const email = document.getElementById('email');
        const hint = document.getElementById('hint');
        const submit = document.getElementById('submit');
        const domains = {
            '@strata.io': 'Mav5 Identity Provider',
            '@canaryretail.onmicrosoft.com': 'Microsoft Enterprise External ID',
            '@strata-eval.io': 'Strata Evaluation Identity',
            '@gmail.com': 'Strata Evaluation Identity'
        };
        email.addEventListener('input', function() {
            const value = this.value.toLowerCase();
            const domain = value.includes('@') ? '@' + value.split('@')[1] : '';
            if (domain && domains[domain]) {
                hint.className = 'hint success';
                hint.textContent = 'Will authenticate with: ' + domains[domain];
                submit.disabled = false;
            } else if (domain && value.includes('@')) {
                hint.className = 'hint error';
                hint.textContent = 'Domain not recognized';
                submit.disabled = true;
            } else {
                hint.className = 'hint';
                hint.textContent = '';
                submit.disabled = false;
            }
        });
    </script>
</body>
</html>`
	
	rw.Header().Set("Content-Type", "text/html")
	rw.Write([]byte(html))
}