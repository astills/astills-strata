package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"strings"
	"time"

	"github.com/strata-io/service-extension/orchestrator"
)

// IdPConfig represents configuration for an Identity Provider
type IdPConfig struct {
	ID          string            `json:"id"`
	Name        string            `json:"name"`
	Domains     []string          `json:"domains"`
	ClaimMaps   map[string]string `json:"claim_maps"`
	Priority    int               `json:"priority"`
}

// HeaderMapping defines how session claims map to HTTP headers
type HeaderMapping struct {
	SessionKey  string `json:"session_key"`
	HeaderName  string `json:"header_name"`
	Format      string `json:"format"` // "string", "json", "comma-separated"
	Required    bool   `json:"required"`
}

// AppHeaderConfig defines header requirements for specific applications
type AppHeaderConfig struct {
	AppID           string          `json:"app_id"`
	PathPattern     string          `json:"path_pattern"`
	HeaderMappings  []HeaderMapping `json:"header_mappings"`
	InjectAllClaims bool            `json:"inject_all_claims"`
	HeaderPrefix    string          `json:"header_prefix"`
}

// UniversalSession represents the universal session structure
type UniversalSession struct {
	UserID            string            `json:"user_id"`
	Email             string            `json:"email"`
	FirstName         string            `json:"first_name"`
	LastName          string            `json:"last_name"`
	DisplayName       string            `json:"display_name"`
	Groups            []string          `json:"groups"`
	Roles             []string          `json:"roles"`
	Department        string            `json:"department"`
	Organization      string            `json:"organization"`
	AuthenticatedIdPs []string          `json:"authenticated_idps"`
	SessionStart      time.Time         `json:"session_start"`
	LastActivity      time.Time         `json:"last_activity"`
	CustomClaims      map[string]string `json:"custom_claims"`
}

// Xylem IdP configurations matching your Strata setup
var defaultIdPConfigs = []IdPConfig{
	{
		ID:       "Keycloak-1-XIAM",
		Name:     "Xylem Identity Access Management",
		Domains:  []string{"@xylem-na.com", "@xylem1.com", "@na.xylem.com", "@wipro1.com"},
		Priority: 1,
		ClaimMaps: map[string]string{
			"sub":                "user_id",
			"given_name":         "first_name",
			"family_name":        "last_name",
			"email":              "email",
			"name":               "display_name",
			"preferred_username": "username",
			"groups":             "groups",
			"department":         "department",
			"organization":       "organization",
			"realm_access.roles": "roles",
		},
	},
	{
		ID:       "Keycloak-2-Xylem-Vue",
		Name:     "Xylem Vue Portal Identity",
		Domains:  []string{"@xylem-eu.com", "@xylem.com", "@eu.xylem.com", "@europe.xylem.com", "@wipro.com"},
		Priority: 2,
		ClaimMaps: map[string]string{
			"sub":                "user_id",
			"email":              "email",
			"name":               "display_name",
			"given_name":         "first_name",
			"family_name":        "last_name",
			"preferred_username": "username",
			"groups":             "groups",
			"department":         "department",
			"organization":       "organization",
			"realm_access.roles": "roles",
		},
	},
	{
		ID:       "Keycloak-3-XCloud",
		Name:     "Xylem XCloud Identity",
		Domains:  []string{"@xylem-apac.com", "@gmail.com", "@apac.xylem.com", "@asia.xylem.com"},
		Priority: 3,
		ClaimMaps: map[string]string{
			"sub":                "user_id",
			"given_name":         "first_name",
			"family_name":        "last_name",
			"email":              "email",
			"name":               "display_name",
			"preferred_username": "username",
			"groups":             "groups",
			"department":         "department",
			"organization":       "organization",
			"realm_access.roles": "roles",
		},
	},
}

// Default header configurations for common application types
var defaultAppHeaderConfigs = []AppHeaderConfig{
	{
		// SiteMinder compatible headers
		AppID:       "siteminder-apps",
		PathPattern: "/sm/*",
		HeaderMappings: []HeaderMapping{
			{SessionKey: "user_id", HeaderName: "SM_USER", Format: "string", Required: true},
			{SessionKey: "email", HeaderName: "SM_USEREMAIL", Format: "string", Required: true},
			{SessionKey: "first_name", HeaderName: "SM_FIRSTNAME", Format: "string", Required: false},
			{SessionKey: "last_name", HeaderName: "SM_LASTNAME", Format: "string", Required: false},
			{SessionKey: "display_name", HeaderName: "SM_USERDISPLAYNAME", Format: "string", Required: false},
			{SessionKey: "groups", HeaderName: "SM_USERGROUPS", Format: "comma-separated", Required: false},
			{SessionKey: "roles", HeaderName: "SM_USERROLES", Format: "comma-separated", Required: false},
			{SessionKey: "department", HeaderName: "SM_USERDEPARTMENT", Format: "string", Required: false},
			{SessionKey: "organization", HeaderName: "SM_USERORGANIZATION", Format: "string", Required: false},
		},
		InjectAllClaims: false,
	},
	{
		// Modern API Gateway headers
		AppID:       "api-gateway",
		PathPattern: "/api/*",
		HeaderMappings: []HeaderMapping{
			{SessionKey: "user_id", HeaderName: "X-User-Id", Format: "string", Required: true},
			{SessionKey: "email", HeaderName: "X-User-Email", Format: "string", Required: true},
			{SessionKey: "display_name", HeaderName: "X-User-Name", Format: "string", Required: false},
			{SessionKey: "groups", HeaderName: "X-User-Groups", Format: "json", Required: false},
			{SessionKey: "roles", HeaderName: "X-User-Roles", Format: "json", Required: false},
			{SessionKey: "authenticated_idps", HeaderName: "X-Auth-Source", Format: "comma-separated", Required: false},
		},
		InjectAllClaims: true,
		HeaderPrefix:    "X-User-Claim-",
	},
	{
		// Generic header injection for all other apps
		AppID:       "default",
		PathPattern: "/*",
		HeaderMappings: []HeaderMapping{
			{SessionKey: "user_id", HeaderName: "Remote-User", Format: "string", Required: true},
			{SessionKey: "email", HeaderName: "Remote-Email", Format: "string", Required: true},
			{SessionKey: "display_name", HeaderName: "Remote-Name", Format: "string", Required: false},
			{SessionKey: "groups", HeaderName: "Remote-Groups", Format: "comma-separated", Required: false},
			{SessionKey: "roles", HeaderName: "Remote-Roles", Format: "comma-separated", Required: false},
		},
		InjectAllClaims: false,
	},
}

const (
	// Session keys
	universalSessionKey = "universal.session"
	sessionInitialized  = "universal.initialized"
	
	// Common claim prefixes
	genericPrefix = "generic."
)

// extractDomain extracts the domain part from an email address
func extractDomain(email string) string {
	parts := strings.Split(email, "@")
	if len(parts) != 2 {
		return ""
	}
	return "@" + parts[1]
}

// findIdPForDomain finds the appropriate IdP configuration for a given domain
func findIdPForDomain(domain string) *IdPConfig {
	for _, config := range defaultIdPConfigs {
		for _, configDomain := range config.Domains {
			if strings.EqualFold(domain, configDomain) {
				return &config
			}
		}
	}
	return nil
}

// findAppHeaderConfig finds the appropriate header configuration for a request path
func findAppHeaderConfig(path string) *AppHeaderConfig {
	// Check specific patterns first
	for _, config := range defaultAppHeaderConfigs {
		if config.AppID != "default" && matchPath(path, config.PathPattern) {
			return &config
		}
	}
	
	// Fall back to default
	for _, config := range defaultAppHeaderConfigs {
		if config.AppID == "default" {
			return &config
		}
	}
	
	return nil
}

// matchPath checks if a path matches a pattern (simple glob matching)
func matchPath(path, pattern string) bool {
	// Simple pattern matching - can be enhanced with more sophisticated matching
	if strings.HasSuffix(pattern, "*") {
		prefix := strings.TrimSuffix(pattern, "*")
		return strings.HasPrefix(path, prefix)
	}
	return path == pattern
}

// InjectHeaders injects authentication headers into the request for backend applications
func InjectHeaders(
	api orchestrator.Orchestrator,
	rw http.ResponseWriter,
	req *http.Request,
) {
	logger := api.Logger()
	sess, _ := api.Session()
	
	// Get universal session
	sessionData, err := sess.GetString(universalSessionKey)
	if err != nil || sessionData == "" {
		logger.Debug("msg", "no universal session found for header injection")
		return
	}
	
	var universalSession UniversalSession
	if err := json.Unmarshal([]byte(sessionData), &universalSession); err != nil {
		logger.Error("msg", "failed to parse universal session for header injection", "error", err)
		return
	}
	
	// Find appropriate header configuration for this request
	appConfig := findAppHeaderConfig(req.URL.Path)
	if appConfig == nil {
		logger.Debug("msg", "no header configuration found for path", "path", req.URL.Path)
		return
	}
	
	logger.Debug("msg", "injecting headers for application", 
		"app_id", appConfig.AppID,
		"path", req.URL.Path)
	
	// Process configured header mappings
	for _, mapping := range appConfig.HeaderMappings {
		value := getSessionValue(&universalSession, mapping.SessionKey)
		if value == "" && mapping.Required {
			logger.Warn("msg", "required header value missing", 
				"session_key", mapping.SessionKey,
				"header_name", mapping.HeaderName)
			continue
		}
		
		if value != "" {
			formattedValue := formatHeaderValue(value, mapping.Format)
			req.Header.Set(mapping.HeaderName, formattedValue)
			logger.Debug("msg", "injected header", 
				"header", mapping.HeaderName,
				"value_length", len(formattedValue))
		}
	}
	
	// Inject all custom claims if configured
	if appConfig.InjectAllClaims && appConfig.HeaderPrefix != "" {
		for key, value := range universalSession.CustomClaims {
			headerName := appConfig.HeaderPrefix + key
			req.Header.Set(headerName, value)
			logger.Debug("msg", "injected custom claim header", 
				"header", headerName)
		}
	}
	
	// Add authentication timestamp and source
	req.Header.Set("X-Auth-Timestamp", universalSession.LastActivity.Format(time.RFC3339))
	req.Header.Set("X-Auth-Session-Start", universalSession.SessionStart.Format(time.RFC3339))
	
	logger.Info("msg", "successfully injected headers for backend application",
		"user_id", universalSession.UserID,
		"app_id", appConfig.AppID,
		"headers_count", len(appConfig.HeaderMappings))
}

// getSessionValue retrieves a value from the universal session by key
func getSessionValue(session *UniversalSession, key string) string {
	switch key {
	case "user_id":
		return session.UserID
	case "email":
		return session.Email
	case "first_name":
		return session.FirstName
	case "last_name":
		return session.LastName
	case "display_name":
		return session.DisplayName
	case "department":
		return session.Department
	case "organization":
		return session.Organization
	case "groups":
		if len(session.Groups) > 0 {
			return strings.Join(session.Groups, ",")
		}
		return ""
	case "roles":
		if len(session.Roles) > 0 {
			return strings.Join(session.Roles, ",")
		}
		return ""
	case "authenticated_idps":
		if len(session.AuthenticatedIdPs) > 0 {
			return strings.Join(session.AuthenticatedIdPs, ",")
		}
		return ""
	default:
		// Check custom claims
		if val, ok := session.CustomClaims[key]; ok {
			return val
		}
		return ""
	}
}

// formatHeaderValue formats a value according to the specified format
func formatHeaderValue(value, format string) string {
	switch format {
	case "json":
		// If it's already a comma-separated list, convert to JSON array
		if strings.Contains(value, ",") {
			parts := strings.Split(value, ",")
			jsonBytes, _ := json.Marshal(parts)
			return string(jsonBytes)
		}
		// Single value as JSON string
		jsonBytes, _ := json.Marshal(value)
		return string(jsonBytes)
	case "comma-separated":
		return value // Already in this format
	default:
		return value // Default is string format
	}
}

// IsAuthenticated determines if the user has a valid universal session
func IsAuthenticated(
	api orchestrator.Orchestrator,
	rw http.ResponseWriter,
	req *http.Request,
) bool {
	authenticated := checkUniversalAuthentication(api)
	
	// If authenticated, inject headers for backend applications
	if authenticated {
		InjectHeaders(api, rw, req)
	}
	
	return authenticated
}

func checkUniversalAuthentication(api orchestrator.Orchestrator) bool {
	logger := api.Logger()
	sess, _ := api.Session()
	
	logger.Debug("msg", "checking universal authentication status")
	
	// Check if universal session exists and is valid
	sessionData, err := sess.GetString(universalSessionKey)
	if err != nil || sessionData == "" {
		logger.Debug("msg", "no universal session found")
		return checkLegacyAuthentication(api)
	}
	
	var universalSession UniversalSession
	if err := json.Unmarshal([]byte(sessionData), &universalSession); err != nil {
		logger.Error("msg", "failed to parse universal session", "error", err)
		return checkLegacyAuthentication(api)
	}
	
	// Check session timeout (optional - configure as needed)
	sessionTimeout := 8 * time.Hour
	if time.Since(universalSession.LastActivity) > sessionTimeout {
		logger.Info("msg", "universal session timed out", 
			"user_id", universalSession.UserID,
			"last_activity", universalSession.LastActivity)
		LogoutFromAllSessions(api)
		return false
	}
	
	// Update last activity
	universalSession.LastActivity = time.Now()
	updatedSessionData, _ := json.Marshal(universalSession)
	_ = sess.SetString(universalSessionKey, string(updatedSessionData))
	sess.Save()
	
	// Set generic claims for backward compatibility
	setGenericClaims(api, &universalSession)
	
	logger.Debug("msg", "user authenticated via universal session", 
		"user_id", universalSession.UserID,
		"email", universalSession.Email)
	
	return true
}

func checkLegacyAuthentication(api orchestrator.Orchestrator) bool {
	logger := api.Logger()
	sess, _ := api.Session()
	
	logger.Debug("msg", "checking legacy authentication methods")
	
	// Check each configured IdP for existing authentication
	for _, config := range defaultIdPConfigs {
		authenticated, err := sess.GetString(fmt.Sprintf("%s.authenticated", config.ID))
		if err == nil && authenticated == "true" {
			logger.Debug("msg", "found legacy authentication", "idp", config.ID)
			
			// Migrate to universal session
			if migrateToUniversalSession(api, &config) {
				return true
			}
		}
	}
	
	return false
}

func migrateToUniversalSession(api orchestrator.Orchestrator, config *IdPConfig) bool {
	logger := api.Logger()
	sess, _ := api.Session()
	
	logger.Info("msg", "migrating legacy session to universal session", "idp", config.ID)
	
	universalSession := UniversalSession{
		AuthenticatedIdPs: []string{config.ID},
		SessionStart:      time.Now(),
		LastActivity:      time.Now(),
		CustomClaims:      make(map[string]string),
	}
	
	// Map claims from the legacy session
	for oldClaim, newField := range config.ClaimMaps {
		claimKey := fmt.Sprintf("%s.%s", config.ID, oldClaim)
		claimValue, err := sess.GetString(claimKey)
		if err != nil || claimValue == "" {
			continue
		}
		
		switch newField {
		case "user_id":
			universalSession.UserID = claimValue
		case "email":
			universalSession.Email = claimValue
		case "first_name":
			universalSession.FirstName = claimValue
		case "last_name":
			universalSession.LastName = claimValue
		case "display_name":
			universalSession.DisplayName = claimValue
		case "department":
			universalSession.Department = claimValue
		case "organization":
			universalSession.Organization = claimValue
		case "groups":
			// Handle groups (might be comma-separated or JSON array)
			if groups := parseGroups(claimValue); groups != nil {
				universalSession.Groups = groups
			}
		case "roles":
			// Handle roles (might be comma-separated or JSON array)
			if roles := parseGroups(claimValue); roles != nil {
				universalSession.Roles = roles
			}
		default:
			// Store as custom claim
			universalSession.CustomClaims[newField] = claimValue
		}
	}
	
	// Ensure we have essential fields
	if universalSession.UserID == "" {
		universalSession.UserID = universalSession.Email
	}
	if universalSession.DisplayName == "" {
		universalSession.DisplayName = fmt.Sprintf("%s %s", 
			universalSession.FirstName, universalSession.LastName)
	}
	
	// Store the universal session
	sessionData, err := json.Marshal(universalSession)
	if err != nil {
		logger.Error("msg", "failed to marshal universal session", "error", err)
		return false
	}
	
	_ = sess.SetString(universalSessionKey, string(sessionData))
	_ = sess.SetString(sessionInitialized, "true")
	sess.Save()
	
	// Set generic claims for immediate use
	setGenericClaims(api, &universalSession)
	
	logger.Info("msg", "successfully migrated to universal session", 
		"user_id", universalSession.UserID,
		"email", universalSession.Email)
	
	return true
}

func parseGroups(groupsStr string) []string {
	if groupsStr == "" {
		return nil
	}
	
	// Try to parse as JSON array first
	var groups []string
	if err := json.Unmarshal([]byte(groupsStr), &groups); err == nil {
		return groups
	}
	
	// Fall back to comma-separated values
	parts := strings.Split(groupsStr, ",")
	groups = make([]string, 0, len(parts))
	for _, part := range parts {
		if trimmed := strings.TrimSpace(part); trimmed != "" {
			groups = append(groups, trimmed)
		}
	}
	
	return groups
}

func setGenericClaims(api orchestrator.Orchestrator, session *UniversalSession) {
	sess, _ := api.Session()
	
	// Set standard generic claims
	_ = sess.SetString(genericPrefix+"SM_USER", session.UserID)
	_ = sess.SetString(genericPrefix+"email", session.Email)
	_ = sess.SetString(genericPrefix+"firstname", session.FirstName)
	_ = sess.SetString(genericPrefix+"lastname", session.LastName)
	_ = sess.SetString(genericPrefix+"displayname", session.DisplayName)
	_ = sess.SetString(genericPrefix+"department", session.Department)
	_ = sess.SetString(genericPrefix+"organization", session.Organization)
	
	// Set groups as JSON array
	if len(session.Groups) > 0 {
		groupsJson, _ := json.Marshal(session.Groups)
		_ = sess.SetString(genericPrefix+"groups", string(groupsJson))
	}
	
	// Set roles as JSON array
	if len(session.Roles) > 0 {
		rolesJson, _ := json.Marshal(session.Roles)
		_ = sess.SetString(genericPrefix+"roles", string(rolesJson))
	}
	
	// Set custom claims
	for key, value := range session.CustomClaims {
		_ = sess.SetString(genericPrefix+key, value)
	}
	
	sess.Save()
}

// Authenticate handles the authentication flow with intelligent IdP routing
func Authenticate(
	api orchestrator.Orchestrator,
	rw http.ResponseWriter,
	req *http.Request,
) {
	logger := api.Logger()
	logger.Info("msg", "starting universal authentication flow")
	
	// Check if already authenticated
	if checkUniversalAuthentication(api) {
		logger.Debug("msg", "user already authenticated")
		// Inject headers for any subsequent requests
		InjectHeaders(api, rw, req)
		return
	}
	
	// Check if email has been provided
	email := req.FormValue("email")
	if email == "" && req.Method != http.MethodPost {
		logger.Debug("msg", "rendering email selection form")
		renderEmailForm(rw, req)
		return
	}
	
	if req.Method != http.MethodPost {
		http.Error(rw, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}
	
	// Parse form data
	if err := req.ParseForm(); err != nil {
		http.Error(rw, "Failed to parse form", http.StatusBadRequest)
		logger.Error("msg", "failed to parse form", "error", err)
		return
	}
	
	email = req.Form.Get("email")
	if email == "" {
		http.Error(rw, "Email is required", http.StatusBadRequest)
		return
	}
	
	// Extract domain and find appropriate IdP
	domain := extractDomain(email)
	idpConfig := findIdPForDomain(domain)
	
	if idpConfig == nil {
		http.Error(rw, "No identity provider configured for this email domain", 
			http.StatusBadRequest)
		logger.Error("msg", "no IdP found for domain", 
			"email", email, "domain", domain)
		return
	}
	
	logger.Info("msg", "routing to identity provider", 
		"email", email,
		"domain", domain,
		"idp", idpConfig.ID,
		"idp_name", idpConfig.Name)
	
	// Get the identity provider and initiate login
	provider, err := api.IdentityProvider(idpConfig.ID)
	if err != nil {
		http.Error(rw, "Identity provider not available", http.StatusInternalServerError)
		logger.Error("msg", "failed to get identity provider", 
			"idp", idpConfig.ID, "error", err)
		return
	}
	
	// Store the target IdP in session for post-auth processing
	sess, _ := api.Session()
	_ = sess.SetString("pending.idp", idpConfig.ID)
	_ = sess.SetString("pending.email", email)
	sess.Save()
	
	logger.Info("msg", "initiating login with identity provider", "idp", idpConfig.ID)
	provider.Login(rw, req)
}

// PostAuthenticate should be called after successful IdP authentication
// to establish the universal session
func PostAuthenticate(
	api orchestrator.Orchestrator,
	rw http.ResponseWriter,
	req *http.Request,
) {
	logger := api.Logger()
	sess, _ := api.Session()
	
	pendingIdP, err1 := sess.GetString("pending.idp")
	pendingEmail, err2 := sess.GetString("pending.email")
	
	if err1 != nil || pendingIdP == "" {
		logger.Error("msg", "no pending IdP found in session")
		http.Error(rw, "Authentication state error", http.StatusInternalServerError)
		return
	}
	
	logger.Info("msg", "processing post-authentication", 
		"idp", pendingIdP, "email", pendingEmail)
	
	// Find the IdP configuration
	var idpConfig *IdPConfig
	for _, config := range defaultIdPConfigs {
		if config.ID == pendingIdP {
			idpConfig = &config
			break
		}
	}
	
	if idpConfig == nil {
		logger.Error("msg", "IdP configuration not found", "idp", pendingIdP)
		http.Error(rw, "Configuration error", http.StatusInternalServerError)
		return
	}
	
	// Create universal session from the authenticated claims
	if createUniversalSession(api, idpConfig, pendingEmail) {
		// Clean up pending state
		_ = sess.SetString("pending.idp", "")
		_ = sess.SetString("pending.email", "")
		sess.Save()
		
		logger.Info("msg", "universal session established successfully")
		
		// Inject headers for the authenticated request
		InjectHeaders(api, rw, req)
	} else {
		logger.Error("msg", "failed to create universal session")
		http.Error(rw, "Session creation failed", http.StatusInternalServerError)
	}
}

func createUniversalSession(api orchestrator.Orchestrator, config *IdPConfig, email string) bool {
	logger := api.Logger()
	sess, _ := api.Session()
	
	// Check if the IdP authentication was successful
	authenticated, err := sess.GetString(fmt.Sprintf("%s.authenticated", config.ID))
	if err != nil || authenticated != "true" {
		logger.Error("msg", "IdP authentication not confirmed", "idp", config.ID)
		return false
	}
	
	return migrateToUniversalSession(api, config)
}

// RefreshHeaders refreshes/reinjects headers for the current request
// Useful for long-running connections or when headers need to be updated
func RefreshHeaders(
	api orchestrator.Orchestrator,
	rw http.ResponseWriter,
	req *http.Request,
) {
	logger := api.Logger()
	
	if checkUniversalAuthentication(api) {
		InjectHeaders(api, rw, req)
		logger.Debug("msg", "headers refreshed successfully")
	} else {
		logger.Warn("msg", "cannot refresh headers - user not authenticated")
		http.Error(rw, "Authentication required", http.StatusUnauthorized)
	}
}

// GetUserInfo returns current user information as JSON
// Useful for debugging and user profile displays
func GetUserInfo(
	api orchestrator.Orchestrator,
	rw http.ResponseWriter,
	req *http.Request,
) {
	sess, _ := api.Session()
	
	sessionData, err := sess.GetString(universalSessionKey)
	if err != nil || sessionData == "" {
		http.Error(rw, "Not authenticated", http.StatusUnauthorized)
		return
	}
	
	var universalSession UniversalSession
	if err := json.Unmarshal([]byte(sessionData), &universalSession); err != nil {
		http.Error(rw, "Session error", http.StatusInternalServerError)
		return
	}
	
	// Prepare safe user info (no sensitive internal data)
	userInfo := map[string]interface{}{
		"user_id":            universalSession.UserID,
		"email":              universalSession.Email,
		"display_name":       universalSession.DisplayName,
		"first_name":         universalSession.FirstName,
		"last_name":          universalSession.LastName,
		"groups":             universalSession.Groups,
		"roles":              universalSession.Roles,
		"department":         universalSession.Department,
		"organization":       universalSession.Organization,
		"authenticated_with": universalSession.AuthenticatedIdPs,
		"session_start":      universalSession.SessionStart,
		"last_activity":      universalSession.LastActivity,
	}
	
	rw.Header().Set("Content-Type", "application/json")
	json.NewEncoder(rw).Encode(userInfo)
}

// DiagnoseIdPs provides diagnostic information about available IdPs
// Useful endpoint for troubleshooting IdP configuration issues
func DiagnoseIdPs(
	api orchestrator.Orchestrator,
	rw http.ResponseWriter,
	req *http.Request,
) {
	logger := api.Logger()
	
	// Discover available IdPs
	availableIdPs := DiscoverIdentityProviders(api)
	
	// Get current configuration
	diagnostics := map[string]interface{}{
		"discovered_idps": availableIdPs,
		"configured_idps": []map[string]interface{}{},
		"recommendations": []string{},
	}
	
	// Add configured IdPs
	for _, config := range defaultIdPConfigs {
		configInfo := map[string]interface{}{
			"id":       config.ID,
			"name":     config.Name,
			"domains":  config.Domains,
			"priority": config.Priority,
		}
		
		// Check if this IdP is available
		if _, err := api.IdentityProvider(config.ID); err != nil {
			configInfo["status"] = "NOT AVAILABLE"
			configInfo["error"] = err.Error()
		} else {
			configInfo["status"] = "AVAILABLE"
		}
		
		diagnostics["configured_idps"] = append(
			diagnostics["configured_idps"].([]map[string]interface{}), 
			configInfo,
		)
	}
	
	// Add recommendations
	recommendations := diagnostics["recommendations"].([]string)
	
	if len(availableIdPs) == 0 {
		recommendations = append(recommendations, 
			"No IdPs found. Check Strata Orchestrator configuration.")
	} else if len(availableIdPs) == 1 {
		recommendations = append(recommendations, 
			fmt.Sprintf("Only one IdP found (%s). Will use for all domains.", availableIdPs[0]))
	}
	
	// Check for mismatched IDs
	for _, config := range defaultIdPConfigs {
		found := false
		for _, available := range availableIdPs {
			if config.ID == available {
				found = true
				break
			}
		}
		if !found {
			recommendations = append(recommendations,
				fmt.Sprintf("IdP '%s' not found. Update configuration or use one of: %v", 
					config.ID, availableIdPs))
		}
	}
	
	diagnostics["recommendations"] = recommendations
	
	// Log the diagnostics
	logger.Info("msg", "IdP diagnostics", "diagnostics", diagnostics)
	
	// Return as JSON
	rw.Header().Set("Content-Type", "application/json")
	json.NewEncoder(rw).Encode(diagnostics)
}

func renderEmailForm(rw http.ResponseWriter, req *http.Request) {
	samlRequest := req.FormValue("SAMLRequest")
	relayState := req.FormValue("RelayState")
	
	// Build HTML form using string concatenation to avoid template literal issues
	formHTML := buildEmailForm(samlRequest, relayState)
	rw.Header().Set("Content-Type", "text/html")
	_, _ = rw.Write([]byte(formHTML))
}

// buildEmailForm constructs the HTML form for email input
func buildEmailForm(samlRequest, relayState string) string {
	return `<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Strata Identity Hub - Universal Access</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .domain-hint {
            font-size: 0.875rem;
            color: #6B7280;
            margin-top: 0.25rem;
        }
        .strata-blue {
            color: #0066CC;
        }
        .strata-blue-bg {
            background-color: #0066CC;
        }
        .strata-blue-bg:hover {
            background-color: #004C99;
        }
        .strata-gray-bg {
            background-color: #F5F7FA;
        }
    </style>
</head>
<body class="strata-gray-bg min-h-screen flex flex-col gap-y-6 items-center justify-center">
    <div class="w-full max-w-md">
        <div class="text-center mb-8">
            <h1 class="text-3xl font-bold strata-blue mb-2">Strata Identity</h1>
            <p class="text-gray-600">Universal Authentication Hub</p>
        </div>
        
        <div class="bg-white rounded-xl shadow-lg p-8">
            <h2 class="text-2xl font-bold text-center mb-2 strata-blue">Sign In</h2>
            <p class="text-gray-600 text-center mb-6">Enter your email to continue to your identity provider</p>
            
            <form method="POST" class="space-y-4" id="authForm">
                <input type="hidden" name="SAMLRequest" value="` + samlRequest + `">
                <input type="hidden" name="RelayState" value="` + relayState + `">
                
                <div class="space-y-2">
                    <label for="email" class="block text-sm font-medium text-gray-700">Email Address</label>
                    <input type="email" 
                           name="email" 
                           id="email" 
                           required 
                           placeholder="Enter your email address"
                           class="w-full px-4 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent">
                    <div id="domainHint" class="domain-hint"></div>
                </div>
                
                <button type="submit" 
                        id="submitBtn"
                        class="w-full strata-blue-bg text-white font-semibold py-3 px-4 rounded-md transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed">
                    Continue to Identity Provider
                </button>
            </form>
            
            <div class="mt-6 strata-gray-bg p-4 rounded-md">
                <h3 class="text-sm font-medium text-gray-700 mb-2">Supported Domains:</h3>
                <div class="text-xs text-gray-600 space-y-1">
                    <p>• <strong>Strata.io:</strong> @strata.io - Mav5</p>
                    <p>• <strong>Microsoft:</strong> @canaryretail.onmicrosoft.com - MSFT-EEID</p>
                    <p>• <strong>Evaluation:</strong> @strata-eval.io, @gmail.com - Strata-Eval-io</p>
                </div>
            </div>
            
            <div class="mt-6 text-center">
                <p class="text-xs text-gray-500">
                    Powered by Strata Identity Orchestrator
                </p>
            </div>
        </div>
    </div>

    <script>
        const emailInput = document.getElementById('email');
        const domainHint = document.getElementById('domainHint');
        const submitBtn = document.getElementById('submitBtn');
        
        const domainMappings = {
            '@strata.io': 'Mav5 Identity Provider',
            '@canaryretail.onmicrosoft.com': 'Microsoft Enterprise External ID',
            '@strata-eval.io': 'Strata Evaluation Identity',
            '@gmail.com': 'Strata Evaluation Identity'
        };
        
        emailInput.addEventListener('input', function() {
            const email = this.value.toLowerCase();
            const domain = email.includes('@') ? '@' + email.split('@')[1] : '';
            
            if (domain && domainMappings[domain]) {
                domainHint.innerHTML = 'Will authenticate with: <strong>' + domainMappings[domain] + '</strong>';
                domainHint.style.color = '#059669';
                submitBtn.disabled = false;
            } else if (domain && email.includes('@')) {
                domainHint.innerHTML = 'Domain not recognized. Supported: @strata.io, @canaryretail.onmicrosoft.com, @strata-eval.io, @gmail.com';
                domainHint.style.color = '#DC2626';
                submitBtn.disabled = true;
            } else {
                domainHint.innerHTML = '';
                submitBtn.disabled = false;
            }
        });
    </script>
</body>
</html>`
}

// LogoutFromAllSessions logs out user from universal session and all IDP sessions
func LogoutFromAllSessions(api orchestrator.Orchestrator) {
	logger := api.Logger()
	sess, _ := api.Session()
	
	logger.Info("msg", "logging out user from all sessions")
	
	// Clear universal session
	_ = sess.SetString(universalSessionKey, "")
	_ = sess.SetString(sessionInitialized, "false")
	
	// Clear generic claims
	_ = sess.SetString(genericPrefix+"email", "")
	_ = sess.SetString(genericPrefix+"firstname", "")
	_ = sess.SetString(genericPrefix+"lastname", "")
	_ = sess.SetString(genericPrefix+"SM_USER", "")
	_ = sess.SetString(genericPrefix+"displayname", "")
	_ = sess.SetString(genericPrefix+"department", "")
	_ = sess.SetString(genericPrefix+"organization", "")
	_ = sess.SetString(genericPrefix+"groups", "")
	_ = sess.SetString(genericPrefix+"roles", "")
	
	// Clear IDP-specific sessions
	for _, config := range defaultIdPConfigs {
		_ = sess.SetString(fmt.Sprintf("%s.authenticated", config.ID), "false")
	}
	
	sess.Save()
	logger.Info("msg", "user logged out from all sessions")
}

// LogoutFromAllSessions logs out user from universal session and all IDP sessions
func LogoutFromAllSessions(api orchestrator.Orchestrator) {
	logger := api.Logger()
	sess, _ := api.Session()
	
	logger.Info("msg", "logging out user from all sessions")
	
	// Clear universal session
	_ = sess.SetString(universalSessionKey, "")
	_ = sess.SetString(sessionInitialized, "false")
	
	// Clear generic claims
	_ = sess.SetString(genericPrefix+"email", "")
	_ = sess.SetString(genericPrefix+"firstname", "")
	_ = sess.SetString(genericPrefix+"lastname", "")
	_ = sess.SetString(genericPrefix+"SM_USER", "")
	_ = sess.SetString(genericPrefix+"displayname", "")
	_ = sess.SetString(genericPrefix+"department", "")
	_ = sess.SetString(genericPrefix+"organization", "")
	_ = sess.SetString(genericPrefix+"groups", "")
	_ = sess.SetString(genericPrefix+"roles", "")
	
	// Clear IDP-specific sessions
	for _, config := range defaultIdPConfigs {
		_ = sess.SetString(fmt.Sprintf("%s.authenticated", config.ID), "false")
	}
	
	sess.Save()
	logger.Info("msg", "user logged out from all sessions")
}

// LogoutFromAllSessions logs out user from universal session and all IDP sessions
func LogoutFromAllSessions(api orchestrator.Orchestrator) {
	logger := api.Logger()
	sess, _ := api.Session()
	
	logger.Info("msg", "logging out user from all sessions")
	
	// Clear universal session
	_ = sess.SetString(universalSessionKey, "")
	_ = sess.SetString(sessionInitialized, "false")
	
	// Clear generic claims
	_ = sess.SetString(genericPrefix+"email", "")
	_ = sess.SetString(genericPrefix+"firstname", "")
	_ = sess.SetString(genericPrefix+"lastname", "")
	_ = sess.SetString(genericPrefix+"SM_USER", "")
	_ = sess.SetString(genericPrefix+"displayname", "")
	_ = sess.SetString(genericPrefix+"department", "")
	_ = sess.SetString(genericPrefix+"organization", "")
	_ = sess.SetString(genericPrefix+"groups", "")
	_ = sess.SetString(genericPrefix+"roles", "")
	
	// Clear IDP-specific sessions
	for _, config := range defaultIdPConfigs {
		_ = sess.SetString(fmt.Sprintf("%s.authenticated", config.ID), "false")
	}
	
	sess.Save()
	logger.Info("msg", "user logged out from all sessions")
}
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Strata Identity Hub - Universal Access</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        :root {
            --strata-blue: #0066CC;
            --strata-dark-blue: #004C99;
            --strata-light-gray: #F5F7FA;
            --strata-green: #00A651;
        }
        .domain-hint {
            font-size: 0.875rem;
            color: #6B7280;
            margin-top: 0.25rem;
        }
    </style>
</head>
<body class="bg-[#F5F7FA] min-h-screen flex flex-col gap-y-6 items-center justify-center">
    <div class="w-full max-w-md">
        <div class="text-center mb-8">
            <h1 class="text-3xl font-bold text-[#0066CC] mb-2">Strata Identity</h1>
            <p class="text-gray-600">Universal Authentication Hub</p>
        </div>
        
        <div class="bg-white rounded-xl shadow-lg p-8">
            <h2 class="text-2xl font-bold text-center mb-2 text-[#0066CC]">Sign In</h2>
            <p class="text-gray-600 text-center mb-6">Enter your email to continue to your identity provider</p>
            
            <form method="POST" class="space-y-4" id="authForm">
                <input type="hidden" name="SAMLRequest" value="%s">
                <input type="hidden" name="RelayState" value="%s">
                
                <div class="space-y-2">
                    <label for="email" class="block text-sm font-medium text-gray-700">Email Address</label>
                    <input type="email" 
                           name="email" 
                           id="email" 
                           required 
                           placeholder="Enter your email address"
                           class="w-full px-4 py-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#0066CC] focus:border-transparent">
                    <div id="domainHint" class="domain-hint"></div>
                </div>
                
                <button type="submit" 
                        id="submitBtn"
                        class="w-full bg-[#0066CC] hover:bg-[#004C99] text-white font-semibold py-3 px-4 rounded-md transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed">
                    Continue to Identity Provider
                </button>
            </form>
            
            <div class="mt-6 bg-[#F5F7FA] p-4 rounded-md">
                <h3 class="text-sm font-medium text-gray-700 mb-2">Supported Domains:</h3>
                <div class="text-xs text-gray-600 space-y-1">
                    <p>• <strong>Strata.io:</strong> @strata.io → Mav5</p>
                    <p>• <strong>Microsoft:</strong> @canaryretail.onmicrosoft.com → MSFT-EEID</p>
                    <p>• <strong>Evaluation:</strong> @strata-eval.io, @gmail.com → Strata-Eval-io</p>
                </div>
            </div>
            
            <div class="mt-6 text-center">
                <p class="text-xs text-gray-500">
                    Powered by Strata Identity Orchestrator
                </p>
            </div>
        </div>
    </div>

    <script>
        const emailInput = document.getElementById('email');
        const domainHint = document.getElementById('domainHint');
        const submitBtn = document.getElementById('submitBtn');
        
        const domainMappings = {
            '@strata.io': 'Mav5 Identity Provider',
            '@canaryretail.onmicrosoft.com': 'Microsoft Enterprise External ID',
            '@strata-eval.io': 'Strata Evaluation Identity',
            '@gmail.com': 'Strata Evaluation Identity'
        };
        
        emailInput.addEventListener('input', function() {
            const email = this.value.toLowerCase();
            const domain = email.includes('@') ? '@' + email.split('@')[1] : '';
            
            if (domain && domainMappings[domain]) {
                domainHint.innerHTML = '✓ Will authenticate with: <strong>' + domainMappings[domain] + '</strong>';
                domainHint.style.color = '#059669';
                submitBtn.disabled = false;
            } else if (domain && email.includes('@')) {
                domainHint.innerHTML = '⚠ Domain not recognized. Supported: @strata.io, @canaryretail.onmicrosoft.com, @strata-eval.io, @gmail.com';
                domainHint.style.color = '#DC2626';
                submitBtn.disabled = true;
            } else {
                domainHint.innerHTML = '';
                submitBtn.disabled = false;
            }
        });
    </script>
</body>
</html>
`