package main

import (
	"encoding/json"
	"fmt"
	"io"
	"net/http"
    "strings"
	"github.com/strata-io/service-extension/orchestrator"
)

type Company struct {
	Name        string `json:"name"`
	CatchPhrase string `json:"catchPhrase"`
	Bs          string `json:"bs"`
}

type User struct {
	ID      int     `json:"id"`
	Email   string  `json:"email"`
	Phone   string  `json:"phone"`
	Company Company `json:"company"`
}
func authenticate(r *http.Request,api orchestrator.Orchestrator) bool {
    var(
        metadata = api.Metadata()
     //   secrets = api.SecretProvider()
    )
        authHeader := r.Header.Get("Authorization")
        
        if authHeader == "" {
                return false
        }

        //For client cred auth instead of bearer token, get the "Basic" section of the auth header instead of "Bearer". 
        //Allowed clientIDs can be stored in SE metadata, but client secrets should only be stored in the secret provider
        parts := strings.Split(authHeader, " ")
        if len(parts) != 2 || parts[0] != "Bearer" {
                return false
        }
        /**********************************************************
         * Stub for Client Credentials check
         **********************************************************
        //TO DO: Base64 decode the auth token, split into client id + client secret, then match the clientsecret to the list of allowed client ids+secrets 
        // token := secrets.GetString("clientSecret-"+clientID)
        // if len(token) == 0 
        //      return false
        **********************************************************/
        
        //If allowed bearer tokens are stored in the secret provider, then use:
       // bearerToken := secrets.GetString("bearerToken")
       
        /************************************************************************************************
         * BEARER TOKENS SHOULD NOT BE STORED IN METADATA FOR ANYTHING OTHER THAN PRODUCT DEMONSTRATIONS*
         ************************************************************************************************/
        bearerToken := metadata["bearerToken"]
        return parts[1] == bearerToken
}

func GetUser(api orchestrator.Orchestrator) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
        if !authenticate(r,api) {
                http.Error(w, "Unauthorized", http.StatusUnauthorized)
                return
        }
		client := &http.Client{}

		url := fmt.Sprintf("https://my-json-server.typicode.com/astills/IDapi/employees/%d",2)

		resp, err := client.Get(url)

		if err != nil {
			http.Error(w, "Failed to make HTTP(S) call: "+err.Error(), http.StatusInternalServerError)
			return
		}

		defer resp.Body.Close()

		body, err := io.ReadAll(resp.Body)

		if err != nil {
			http.Error(w, "Failed to read response body: "+err.Error(), http.StatusInternalServerError)
			return
		}

		var user User

		if err := json.Unmarshal(body, &user); err != nil {
			http.Error(w, "Failed to unmarshall identity data: "+err.Error(), http.StatusInternalServerError)
			return
		}

        // Encode user
        
		encodeJson(w, user)
	}
}


func Serve(api orchestrator.Orchestrator) error {

	var (
		logger = api.Logger()
		router = api.Router()
	)

	logger.Info("se", "exposing Identity API")

	err := router.HandleFunc("/identity", GetUser(api))

	if err != nil {
		return fmt.Errorf("failed to handle route: %w", err)
	}

	return nil
}

func encodeJson(w http.ResponseWriter, data interface{}) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(data)
}
